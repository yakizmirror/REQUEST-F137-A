<?php
/* API authentication + CSRF guard. */
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/security.php';

ascb_start_session();
ascb_send_security_headers();
header('Content-Type: application/json; charset=utf-8');

if (empty($_SESSION['ascb_user'])) {
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'Hindi naka-login. Mag-login muli.'));
    exit;
}

$ascbUser = $_SESSION['ascb_user'];

/* Re-check the account on every API request. A deactivated or
   deleted account must not keep working through an old session. */
require_once __DIR__ . '/../config/db.php';
$stmt = $pdo->prepare("SELECT u.id, u.username, u.display_name, u.role, u.department_id, d.name AS department_name, u.prepared_by_code, u.is_active FROM users u LEFT JOIN departments d ON d.id=u.department_id WHERE u.id = ?");
$stmt->execute(array((int) ascb_get($ascbUser, 'id', 0)));
$freshUser = $stmt->fetch();
if (!$freshUser || !(int) $freshUser['is_active']) {
    $_SESSION = array();
    session_destroy();
    http_response_code(401);
    echo json_encode(array('ok' => false, 'error' => 'Inactive o expired ang account session. Mag-login muli.'));
    exit;
}
$_SESSION['ascb_user'] = array(
    'id' => (int) $freshUser['id'],
    'username' => $freshUser['username'],
    'displayName' => $freshUser['display_name'],
    'role' => $freshUser['role'],
    'departmentId' => isset($freshUser['department_id']) ? (int)$freshUser['department_id'] : null,
    'departmentName' => isset($freshUser['department_name']) ? $freshUser['department_name'] : null,
    'preparedBy' => $freshUser['prepared_by_code'],
);
$ascbUser = $_SESSION['ascb_user'];
ascb_require_api_csrf();
