<?php
/* =========================================================
   HELPER: DASHBOARD STATS (Enrollment Overview)
   ---------------------------------------------------------
   Iisang function na ginagamit ng api/dashboard_stats.php
   (JSON, para sa cards/breakdown sa Dashboard) AT ng
   api/dashboard_stats_export.php (Excel report) — para hindi
   dalawang beses isulat ang parehong counting logic at laging
   magkatugma ang nakikita sa screen at ang na-e-export.

   ascb_dashboard_stats($pdo, $trimester):
       $trimester — opsyonal, hal. "1st Trimester". Blangko
                    ("") = lahat ng trimester.

   Ibinabalik: array na may totalEnrolled, male, female,
   byCourse (parehong laman/behavior gaya ng dati sa
   dashboard_stats.php — isang beses lang bawat estudyante,
   short program_code ang "course" kung meron).
   ========================================================= */

require_once __DIR__ . '/helpers.php';

if (!function_exists('ascb_dashboard_stats')) {
    function ascb_dashboard_stats($pdo, $trimester = '', $departmentId = null) {

        $trimester = trim((string) $trimester);
        $params = array();
        $trimesterClause = '';
        $departmentClause = '';
        if ($departmentId) { $departmentClause = " AND EXISTS (SELECT 1 FROM programs dp WHERE dp.code = program_code AND dp.department_id = ?)"; }
        if ($trimester !== '') {
            $trimesterClause = ' AND trimester = ?';
            $params[] = $trimester;
        }
        if ($departmentId) $params[] = (int)$departmentId;

        /* Pinipili ang PINAKA-BAGONG (pinakamataas na id) na ACTIVE
           record ng bawat estudyante (student_id) sa loob ng napiling
           trimester (o lahat, kung blangko) — para hindi paulit-ulit
           mabilang ang parehong estudyante. */
        $sql = "
            SELECT e.program_code, e.course, e.sex, COUNT(*) AS cnt
            FROM enrollees e
            INNER JOIN (
                SELECT
                    COALESCE(NULLIF(TRIM(student_id), ''), CONCAT('_row_', id)) AS student_key,
                    MAX(id) AS max_id
                FROM enrollees
                WHERE archived_at IS NULL AND status != 'rejected'" . $trimesterClause . $departmentClause . "
                GROUP BY student_key
            ) latest ON latest.max_id = e.id
            GROUP BY e.program_code, e.course, e.sex
        ";

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        $total       = 0;
        $maleTotal   = 0;
        $femaleTotal = 0;
        $courses     = array(); // course label => ['course'=>, 'male'=>, 'female'=>, 'total'=>]

        foreach ($rows as $row) {
            $programCode = trim((string) ascb_get($row, 'program_code', ''));
            $course      = trim((string) ascb_get($row, 'course', ''));
            if ($programCode !== '') {
                $courseLabel = $programCode;
            } elseif ($course !== '') {
                $courseLabel = $course;
            } else {
                $courseLabel = 'Unspecified';
            }
            $sex = ascb_get($row, 'sex', '');
            $cnt = (int) ascb_get($row, 'cnt', 0);

            $total += $cnt;

            if ($sex === 'Male') {
                $maleTotal += $cnt;
            } elseif ($sex === 'Female') {
                $femaleTotal += $cnt;
            }

            if (!isset($courses[$courseLabel])) {
                $courses[$courseLabel] = array('course' => $courseLabel, 'male' => 0, 'female' => 0, 'total' => 0);
            }
            if ($sex === 'Male') {
                $courses[$courseLabel]['male'] += $cnt;
            } elseif ($sex === 'Female') {
                $courses[$courseLabel]['female'] += $cnt;
            }
            $courses[$courseLabel]['total'] += $cnt;
        }

        $courseList = array_values($courses);
        usort($courseList, function ($a, $b) {
            if ($a['total'] === $b['total']) {
                return strcasecmp($a['course'], $b['course']);
            }
            return ($a['total'] > $b['total']) ? -1 : 1;
        });

        return array(
            'totalEnrolled' => $total,
            'male'          => $maleTotal,
            'female'        => $femaleTotal,
            'byCourse'      => $courseList,
        );
    }
}
