<?php
/* =========================================================
   ROLE PERMISSIONS — ADMIN MODULE
   ---------------------------------------------------------
   Lahat ng naka-login (kahit anong role) ay may access sa
   Admin panel — pero magkaiba ang kayang gawin ng bawat isa
   dito. Dito lang nakadepende ang lahat ng permission checks
   (parehong ginagamit sa PHP/API side at pinapadala sa
   frontend para sa pag-hide/disable ng mga button).

   PERMISSIONS:
     manage_users      - add / edit / deactivate / delete
                          user accounts (sensitive — UNIT HEAD
                          lang, ito ang pinakamataas na role).
     delete_lookups    - pwedeng mag-DELETE ng schools/courses
                          (ang pag-ADD ay bukas pa rin sa lahat,
                          tulad ng dati, dahil ginagamit ito
                          habang pumupuno ng Form 137-A).
     view_activity_log - makikita ang History/Activity Log ng
                          buong system.
     approve_enrollment - pwedeng mag-Approve/Reject ng mga
                          enrollment record na "pending" (mga
                          na-input ng ADMIN STAFF) — UNIT HEAD
                          lang.
     update_enrollment  - pwedeng mag-Update/edit ng existing
                          enrollment record (student/term/subject assignment only — grades are managed
                          separately in Grade Management) —
                          UNIT HEAD lang. Ang ADMIN STAFF ay
                          pwede pa ring mag-enroll ng BAGONG
                          estudyante (create) at mag-New Term,
                          hindi lang siya pwedeng mag-edit ng
                          existing record.

   Baguhin lang dito kung sino ang dapat may access — sentralisado
   ito para hindi na kailangang hanapin sa maraming files.
   ========================================================= */

if (!function_exists('ascb_can')) {
    function ascb_can($role, $permission) {
        $matrix = array(
            'manage_users'       => array('UNIT HEAD'),
            'delete_lookups'     => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'view_activity_log'  => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'approve_enrollment' => array('UNIT HEAD'),
            'update_enrollment'  => array('UNIT HEAD'),
            'manage_grades'      => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'manage_departments' => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
            'export_department'  => array('UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN'),
            'full_backup'        => array('UNIT HEAD', 'SCHOOL REGISTRAR'),
        );

        if (!isset($matrix[$permission])) {
            return false;
        }

        return in_array($role, $matrix[$permission], true);
    }
}

/* Kailangan ang lahat ng permission keys na ito (bilang booleans)
   para ma-expose sa JS bilang ASCB_PERMISSIONS — ginagamit ng
   frontend para i-hide/disable ang mga bagay na hindi pwede sa
   kasalukuyang naka-login na user. HINDI ito ang tunay na
   security boundary (ang mga api/*.php files pa rin ang
   nagpapatupad ng tunay na check) — UI convenience lang ito. */
if (!function_exists('ascb_permissions_for')) {
    function ascb_permissions_for($role) {
        return array(
            'manageUsers'       => ascb_can($role, 'manage_users'),
            'deleteLookups'     => ascb_can($role, 'delete_lookups'),
            'viewActivityLog'   => ascb_can($role, 'view_activity_log'),
            'approveEnrollment' => ascb_can($role, 'approve_enrollment'),
            'updateEnrollment'  => ascb_can($role, 'update_enrollment'),
            'manageGrades'      => ascb_can($role, 'manage_grades'),
            'manageDepartments' => ascb_can($role, 'manage_departments'),
            'exportDepartment'  => ascb_can($role, 'export_department'),
            'fullBackup'        => ascb_can($role, 'full_backup'),
        );
    }
}
