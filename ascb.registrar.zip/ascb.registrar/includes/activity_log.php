<?php
/* =========================================================
   ACTIVITY LOG HELPER
   ---------------------------------------------------------
   Isang function na tinatawag saanman may gustong i-log na
   pangyayari (login/logout, pagdagdag/pagbura ng user account,
   school, course, atbp). Isinusulat sa `activity_log` table
   (tingnan sa database/migrate_admin_module.php).

   Sadyang naka-try/catch ito: kung sakaling mabigo ang pag-
   log (hal. hindi pa na-run ang migration script), hindi dapat
   ito ang dahilan para mabigo ang buong request na tinatawag
   nito (hal. login, pag-add ng school, atbp).
   ========================================================= */

require_once __DIR__ . '/helpers.php';

if (!function_exists('ascb_log_activity')) {
    function ascb_log_activity($pdo, $ascbUser, $action, $entityType = null, $entityLabel = null, $details = null) {
        try {
            $stmt = $pdo->prepare(
                "INSERT INTO activity_log (user_id, display_name, role, action, entity_type, entity_label, details)
                 VALUES (?, ?, ?, ?, ?, ?, ?)"
            );
            $stmt->execute(array(
                ascb_get($ascbUser, 'id', null),
                ascb_get($ascbUser, 'displayName', ascb_get($ascbUser, 'display_name', null)),
                ascb_get($ascbUser, 'role', null),
                $action,
                $entityType,
                $entityLabel,
                $details,
            ));
        } catch (Exception $e) {
            // Sinasadyang hindi ipasa ang error — huwag hayaang
            // pabagsakin ng logging failure ang totoong request.
        }
    }
}
