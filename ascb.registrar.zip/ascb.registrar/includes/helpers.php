<?php
/* =========================================================
   SMALL HELPER — PHP 5.6 COMPATIBLE
   ---------------------------------------------------------
   Ginagamit sa halip na ang `??` (null coalescing) operator,
   dahil hindi ito suportado bago PHP 7.0 (kasama ang PHP na
   bundled sa mas lumang XAMPP releases).
   ========================================================= */

if (!function_exists('ascb_get')) {
    function ascb_get($array, $key, $default = null) {
        return (is_array($array) && isset($array[$key])) ? $array[$key] : $default;
    }
}


if (!function_exists('ascb_first_initial')) {
    function ascb_first_initial($value) {
        $value = trim((string) $value);
        if ($value === '') return '?';
        if (function_exists('mb_substr') && function_exists('mb_strtoupper')) {
            return mb_strtoupper(mb_substr($value, 0, 1, 'UTF-8'), 'UTF-8');
        }
        return strtoupper(substr($value, 0, 1));
    }
}

if (!function_exists('ascb_text_too_long')) {
    function ascb_text_too_long($value, $max) {
        $value = (string) $value;
        $len = function_exists('mb_strlen') ? mb_strlen($value, 'UTF-8') : strlen($value);
        return $len > (int) $max;
    }
}
