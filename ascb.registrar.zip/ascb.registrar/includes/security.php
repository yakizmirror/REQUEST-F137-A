<?php
/* =========================================================
   SESSION / REQUEST SECURITY HELPERS
   ========================================================= */
require_once __DIR__ . '/../config/app.php';

if (!function_exists('ascb_is_https')) {
    function ascb_is_https() {
        if (!empty($_SERVER['HTTPS']) && strtolower($_SERVER['HTTPS']) !== 'off') return true;
        if (isset($_SERVER['SERVER_PORT']) && (int) $_SERVER['SERVER_PORT'] === 443) return true;
        /* Honor a reverse proxy only when it explicitly reports HTTPS. */
        if (!empty($_SERVER['HTTP_X_FORWARDED_PROTO']) && strtolower(trim(explode(',', $_SERVER['HTTP_X_FORWARDED_PROTO'])[0])) === 'https') return true;
        return false;
    }
}

if (!function_exists('ascb_send_security_headers')) {
    function ascb_send_security_headers() {
        if (headers_sent()) return;
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: same-origin');
        header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
        header("Content-Security-Policy: frame-ancestors 'none'; base-uri 'self'; object-src 'none'");
        header('Cache-Control: no-store, private');
    }
}

if (!function_exists('ascb_start_session')) {
    function ascb_start_session() {
        if (session_status() !== PHP_SESSION_NONE) return;

        ini_set('session.use_only_cookies', '1');
        ini_set('session.use_strict_mode', '1');
        ini_set('session.cookie_httponly', '1');
        ini_set('session.gc_maxlifetime', (string) (60 * 60 * 24 * 30));
        /* Supported by modern PHP; harmless when unavailable. */
        @ini_set('session.cookie_samesite', 'Lax');
        if (ascb_is_https()) {
            ini_set('session.cookie_secure', '1');
        }

        session_start();

        $now = time();
        $ttl = !empty($_SESSION['ascb_remember']) ? 60 * 60 * 24 * 30 : 60 * 60 * 8;
        if (!empty($_SESSION['ascb_last_activity']) && ($now - (int) $_SESSION['ascb_last_activity']) > $ttl) {
            $_SESSION = array();
            if (ini_get('session.use_cookies')) {
                $p = session_get_cookie_params();
                setcookie(session_name(), '', $now - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
            }
            session_destroy();
            session_start();
        }
        $_SESSION['ascb_last_activity'] = $now;
    }
}

if (!function_exists('ascb_random_token')) {
    function ascb_random_token($bytes) {
        if (function_exists('random_bytes')) {
            return bin2hex(random_bytes($bytes));
        }
        if (function_exists('openssl_random_pseudo_bytes')) {
            $strong = false;
            $raw = openssl_random_pseudo_bytes($bytes, $strong);
            if ($raw !== false) return bin2hex($raw);
        }
        return hash('sha256', uniqid('', true) . mt_rand() . microtime(true));
    }
}

if (!function_exists('ascb_csrf_token')) {
    function ascb_csrf_token() {
        if (empty($_SESSION['ascb_csrf'])) {
            $_SESSION['ascb_csrf'] = ascb_random_token(32);
        }
        return $_SESSION['ascb_csrf'];
    }
}

if (!function_exists('ascb_verify_csrf')) {
    function ascb_verify_csrf($token) {
        $expected = isset($_SESSION['ascb_csrf']) ? $_SESSION['ascb_csrf'] : '';
        if ($expected === '' || !is_string($token) || $token === '') return false;
        return function_exists('hash_equals') ? hash_equals($expected, $token) : ($expected === $token);
    }
}

if (!function_exists('ascb_require_api_csrf')) {
    function ascb_require_api_csrf() {
        $method = isset($_SERVER['REQUEST_METHOD']) ? strtoupper($_SERVER['REQUEST_METHOD']) : 'GET';
        if (in_array($method, array('GET', 'HEAD', 'OPTIONS'), true)) return;

        $token = isset($_SERVER['HTTP_X_CSRF_TOKEN']) ? $_SERVER['HTTP_X_CSRF_TOKEN'] : '';
        if (!ascb_verify_csrf($token)) {
            http_response_code(403);
            header('Content-Type: application/json; charset=utf-8');
            echo json_encode(array('ok' => false, 'error' => 'Expired o invalid ang request token. I-refresh ang page at subukan muli.'));
            exit;
        }
    }
}


if (!function_exists('ascb_extend_session_cookie')) {
    function ascb_extend_session_cookie($expiresAt) {
        if (headers_sent()) return;
        $p = session_get_cookie_params();
        $parts = array();
        $parts[] = rawurlencode(session_name()) . '=' . rawurlencode(session_id());
        $parts[] = 'Expires=' . gmdate('D, d M Y H:i:s', (int) $expiresAt) . ' GMT';
        $parts[] = 'Max-Age=' . max(0, (int) $expiresAt - time());
        $parts[] = 'Path=' . ($p['path'] ? $p['path'] : '/');
        if (!empty($p['domain'])) $parts[] = 'Domain=' . $p['domain'];
        if (ascb_is_https()) $parts[] = 'Secure';
        $parts[] = 'HttpOnly';
        $parts[] = 'SameSite=Lax';
        header('Set-Cookie: ' . implode('; ', $parts), false);
    }
}
