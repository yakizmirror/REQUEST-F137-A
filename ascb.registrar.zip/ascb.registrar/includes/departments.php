<?php
/* Department / Dean scope helpers. Backward-compatible until migration is run. */
if (!function_exists('ascb_has_column')) {
    function ascb_has_column($pdo, $table, $column) {
        try {
            $t = str_replace('`','',$table);
            $col = $pdo->quote($column);
            $stmt = $pdo->query("SHOW COLUMNS FROM `" . $t . "` LIKE " . $col);
            return (bool)$stmt->fetch();
        } catch (Exception $e) {
            $GLOBALS['ascb_department_schema_error'] = 'ascb_has_column(' . $table . '.' . $column . '): ' . $e->getMessage();
            return false;
        }
    }
}
if (!function_exists('ascb_current_department_id')) {
    function ascb_current_department_id($pdo, $user) {
        if (ascb_get($user, 'role', '') !== 'DEAN') return null;
        $uid = (int)ascb_get($user, 'id', 0);
        if (!$uid || !ascb_has_column($pdo, 'users', 'department_id')) return null;
        $st=$pdo->prepare("SELECT department_id FROM users WHERE id=?"); $st->execute(array($uid));
        $v=$st->fetchColumn(); return $v !== false && $v !== null ? (int)$v : null;
    }
}
if (!function_exists('ascb_require_dean_department')) {
    function ascb_require_dean_department($pdo, $user) {
        $id=ascb_current_department_id($pdo,$user);
        if (ascb_get($user,'role','')==='DEAN' && !$id) {
            http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'Walang Department na naka-assign sa Dean account na ito.')); exit;
        }
        return $id;
    }
}
?>
