<?php
/* =========================================================
   PROGRAMS & SUBJECTS — SHARED HELPERS
   ---------------------------------------------------------
   Ginagamit ng api/programs.php (CRUD) AT ng dashboard.php
   (para i-embed ang data bilang JS globals sa page load, para
   ang mga bagong idinagdag na Course/Major/Subject/Trimester
   o Semester ay awtomatikong "callable" (magagamit) agad sa
   Enrollment module — walang kailangang i-edit na code).
   ========================================================= */

require_once __DIR__ . '/helpers.php';

/* Existing hardcoded program codes (structuredPrograms sa
   script.js) — bawal gamitin ang mga ito bilang BAGONG code
   ng admin, para walang mag-conflict. Panatilihing tugma ang
   listahang ito sa `programNames` sa script.js. */
if (!isset($GLOBALS['ASCB_RESERVED_PROGRAM_CODES'])) {
    $GLOBALS['ASCB_RESERVED_PROGRAM_CODES'] = array(
        'BSCS', 'BSIS', 'BSIT', 'BSCRIM', 'BSA',
        'BSBA-FM', 'BSBA-HRDM', 'BSBA-MM',
        'BEED', 'BSED-ENGLISH', 'BSED-MATH', 'BSED-SOCIAL',
    );
    $GLOBALS['ASCB_YEAR_LEVEL_RANK'] = array('1st Year' => 1, '2nd Year' => 2, '3rd Year' => 3, '4th Year' => 4);
    $GLOBALS['ASCB_TERM_RANK'] = array(
        '1st Trimester' => 1, '2nd Trimester' => 2, '3rd Trimester' => 3,
        '1st Semester' => 1, '2nd Semester' => 2, 'Summer' => 3,
    );
}

if (!function_exists('ascb_program_label')) {
    function ascb_program_label($courseName, $major) {
        $courseName = trim((string) $courseName);
        $major = trim((string) $major);
        return $major !== '' ? ($courseName . ' Major in ' . $major) : $courseName;
    }
}

if (!function_exists('ascb_subject_sort')) {
    function ascb_subject_sort($a, $b, $yearRank, $termRank) {
        $ya = isset($yearRank[$a['year_level']]) ? $yearRank[$a['year_level']] : 99;
        $yb = isset($yearRank[$b['year_level']]) ? $yearRank[$b['year_level']] : 99;
        if ($ya !== $yb) return $ya - $yb;
        $ta = isset($termRank[$a['term_label']]) ? $termRank[$a['term_label']] : 99;
        $tb = isset($termRank[$b['term_label']]) ? $termRank[$b['term_label']] : 99;
        if ($ta !== $tb) return $ta - $tb;
        if ((int) $a['sort_order'] !== (int) $b['sort_order']) return (int) $a['sort_order'] - (int) $b['sort_order'];
        return (int) $a['id'] - (int) $b['id'];
    }
}

/* Bumubuo ng { names, termTypes, structured } — direktang
   maii-merge sa `programNames` / `programTermTypes` /
   `structuredPrograms` sa JS side (Object.assign). Kung hindi
   pa na-run ang migration (wala pang `programs` table), balik
   nang tahimik ang mga blangkong array sa halip na mag-error,
   para hindi masira ang dashboard ng mga lumang install. */
if (!function_exists('ascb_build_structured_programs')) {
    function ascb_build_structured_programs($pdo) {
        $empty = array('names' => new stdClass(), 'termTypes' => new stdClass(), 'structured' => new stdClass());

        try {
            $programs = $pdo->query("SELECT id, code, course_name, major, term_type FROM programs WHERE is_active = 1")->fetchAll();
        } catch (PDOException $e) {
            return $empty;
        }

        if (!$programs) {
            return $empty;
        }

        $yearRank = $GLOBALS['ASCB_YEAR_LEVEL_RANK'];
        $termRank = $GLOBALS['ASCB_TERM_RANK'];

        $names = array();
        $termTypes = array();
        $structured = array();

        $subjStmt = $pdo->prepare("SELECT year_level, term_label, subject_code, description, units, sort_order, id FROM program_subjects WHERE program_id = ?");

        foreach ($programs as $p) {
            $names[$p['code']] = ascb_program_label($p['course_name'], $p['major']);
            $termTypes[$p['code']] = $p['term_type'];

            $subjStmt->execute(array($p['id']));
            $rows = $subjStmt->fetchAll();
            usort($rows, function ($a, $b) use ($yearRank, $termRank) {
                return ascb_subject_sort($a, $b, $yearRank, $termRank);
            });

            $groups = array();
            $groupIndex = array();
            foreach ($rows as $r) {
                $key = $r['year_level'] . '|' . $r['term_label'];
                if (!isset($groupIndex[$key])) {
                    $groupIndex[$key] = count($groups);
                    $groups[] = array('year' => $r['year_level'], 'trimester' => $r['term_label'], 'subjects' => array());
                }
                $groups[$groupIndex[$key]]['subjects'][] = array(
                    'code' => $r['subject_code'],
                    'description' => $r['description'],
                    'units' => (float) $r['units'],
                );
            }

            // Built-in/factory programs may be present in DB only for Department mapping.
            // Do not overwrite their hardcoded prospectus with an empty array.
            if (!empty($groups)) $structured[$p['code']] = $groups;
        }

        return array('names' => $names, 'termTypes' => $termTypes, 'structured' => $structured);
    }
}

/* Program dropdown options (code => label) mula sa DB, para
   idagdag sa $ascbProgramOptions (hardcoded) sa dashboard.php —
   kaya lumalabas agad ang bagong Course/Program sa Enrollment
   dropdown kahit fresh page load (hindi lang kapag na-add via
   AJAX habang naka-open ang page). */
if (!function_exists('ascb_program_dropdown_options')) {
    function ascb_program_dropdown_options($pdo) {
        try {
            $programs = $pdo->query("SELECT code, course_name, major FROM programs WHERE is_active = 1 ORDER BY course_name, major")->fetchAll();
        } catch (PDOException $e) {
            return array();
        }
        $options = array();
        foreach ($programs as $p) {
            $options[$p['code']] = ascb_program_label($p['course_name'], $p['major']);
        }
        return $options;
    }
}
