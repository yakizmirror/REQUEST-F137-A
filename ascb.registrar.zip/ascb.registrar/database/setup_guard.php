<?php
/* Prevent accidental/public execution of migration and seeding scripts. */
require_once __DIR__ . '/../config/app.php';

$allowWebSetup = ascb_env('ASCB_ALLOW_WEB_SETUP', '0') === '1';
if (PHP_SAPI !== 'cli' && !$allowWebSetup) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    echo "Setup scripts are disabled over the web. Run them from the command line, or explicitly set ASCB_ALLOW_WEB_SETUP=1 only during controlled installation.\n";
    exit;
}
