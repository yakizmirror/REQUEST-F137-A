<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ENROLLMENT: SEX / STUDENT TYPE
   ---------------------------------------------------------
   Idinagdag ito para sa dalawang bagong dropdown sa Enrollment
   Menu (Enroll / Update / New Term). Nagdadagdag ito ng
   DALAWANG BAGONG column sa existing na `enrollees` table:

       sex            ENUM('Male','Female')                  DEFAULT NULL
       student_type   ENUM('Regular','Transferee','Irregular') DEFAULT NULL

   Walang binabago o binubura sa mga existing rows/columns —
   ligtas itong patakbuhin kahit may laman na ang enrollees mo.
   Blangko (NULL) ang dalawang bagong column sa mga LUMANG
   record — pwede na lang itong punan sa susunod na Update.
   Idempotent ito (safe ulitin) — chinecheck muna kung nandiyan
   na ang column bago idagdag.

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_enrollment_sex_studenttype_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

function ascb_migrate_sst_column_exists($pdo, $table, $column) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $stmt->execute(array($table, $column));
    return ((int) $stmt->fetchColumn()) > 0;
}

try {
    $sexAdded = false;
    $typeAdded = false;

    if (!ascb_migrate_sst_column_exists($pdo, 'enrollees', 'sex')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN sex ENUM('Male','Female') DEFAULT NULL AFTER middle_name");
        $sexAdded = true;
    }

    if (!ascb_migrate_sst_column_exists($pdo, 'enrollees', 'student_type')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN student_type ENUM('Regular','Transferee','Irregular') DEFAULT NULL AFTER sex");
        $typeAdded = true;
    }

    echo "<p><strong>Migration complete.</strong> Handa na ang Sex / Student Type fields.</p>";
    echo "<p>Column <code>sex</code>: " . ($sexAdded ? "naidagdag." : "nandiyan na (nilaktawan).") . "</p>";
    echo "<p>Column <code>student_type</code>: " . ($typeAdded ? "naidagdag." : "nandiyan na (nilaktawan).") . "</p>";
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Sex / Student Type module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
