<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ENROLLMENT: COURSE & SUBJECTS
   ---------------------------------------------------------
   Idinagdag ito para sa bagong Course / Major at Subjects
   (mula sa prospectus) sa Enrollment panel. Nagdadagdag lang
   ito ng mga BAGONG column sa existing na `enrollees` table:

       program_code   VARCHAR(30)   — hal. BSBA-FM
       course         VARCHAR(150)  — pangalan ng kurso
       major          VARCHAR(150)  — blangko kung wala
       year_level     VARCHAR(30)
       trimester      VARCHAR(30)
       subjects_json  TEXT          — [{code, description, units}]

   Walang binabago o binubura sa mga existing rows/columns —
   ligtas itong patakbuhin kahit may laman na ang enrollees mo,
   at idempotent ito (safe ulitin — chinecheck muna kung
   nandiyan na ang column bago idagdag).

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_enrollment_course_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.

   NOTE: Kung bagong install ka lamang (kakatapos mo lang
   i-import ang database/ascb_registrar.sql), HINDI mo na
   kailangan patakbuhin ito — kasama na ang mga column na ito
   doon.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

function ascb_migrate_column_exists($pdo, $table, $column) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $stmt->execute(array($table, $column));
    return ((int) $stmt->fetchColumn()) > 0;
}

$columnsToAdd = array(
    'program_code'  => "ALTER TABLE enrollees ADD COLUMN program_code VARCHAR(30) DEFAULT NULL AFTER prev_school_senior_hs",
    'course'        => "ALTER TABLE enrollees ADD COLUMN course VARCHAR(150) DEFAULT NULL AFTER program_code",
    'major'         => "ALTER TABLE enrollees ADD COLUMN major VARCHAR(150) DEFAULT NULL AFTER course",
    'year_level'    => "ALTER TABLE enrollees ADD COLUMN year_level VARCHAR(30) DEFAULT NULL AFTER major",
    'trimester'     => "ALTER TABLE enrollees ADD COLUMN trimester VARCHAR(30) DEFAULT NULL AFTER year_level",
    'subjects_json' => "ALTER TABLE enrollees ADD COLUMN subjects_json TEXT DEFAULT NULL AFTER trimester",
);

try {
    $added = array();
    $skipped = array();

    foreach ($columnsToAdd as $column => $sql) {
        if (ascb_migrate_column_exists($pdo, 'enrollees', $column)) {
            $skipped[] = $column;
            continue;
        }
        $pdo->exec($sql);
        $added[] = $column;
    }

    echo "<p><strong>Migration complete.</strong> Handa na ang Course / Major / Subjects sa Enrollment module.</p>";

    if (!empty($added)) {
        echo "<p>Naidagdag na columns: " . htmlspecialchars(implode(', ', $added)) . "</p>";
    }
    if (!empty($skipped)) {
        echo "<p>Nandiyan na (nilaktawan): " . htmlspecialchars(implode(', ', $skipped)) . "</p>";
    }

    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Course / Subjects sa Enrollment module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
