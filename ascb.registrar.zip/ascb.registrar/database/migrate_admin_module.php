<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ADMIN MODULE MIGRATION
   ---------------------------------------------------------
   Idinagdag ito para sa bagong "Admin" panel (User Management,
   Schools & Courses management, Activity Log). Gumagawa lang
   ito ng BAGONG table (`activity_log`) — walang ginagalaw o
   binabago sa mga existing tables/data mo, kaya ligtas itong
   patakbuhin kahit may laman na ang database mo.

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_admin_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
        I-delete o i-rename mo na ang file na ito (hal.
        migrate_admin_module.php.bak) kung gusto mo, pero hindi
        naman ito peligroso kahit ma-access ulit paglaon dahil
        idempotent ito (safe ulitin — hindi ito gagawa ng
        duplicate na table o magbubura ng laman).

   NOTE: Kung bagong install ka lamang (kakatapos mo lang
   i-import ang database/ascb_registrar.sql), HINDI mo na
   kailangan patakbuhin ito — kasama na ang `activity_log`
   table doon.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS activity_log (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            user_id       INT           DEFAULT NULL,
            display_name  VARCHAR(100)  DEFAULT NULL,
            role          VARCHAR(50)   DEFAULT NULL,
            action        VARCHAR(50)   NOT NULL,
            entity_type   VARCHAR(30)   DEFAULT NULL,
            entity_label  VARCHAR(255)  DEFAULT NULL,
            details       VARCHAR(500)  DEFAULT NULL,
            created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_activitylog_user
                FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_activitylog_created (created_at),
            INDEX idx_activitylog_action (action)
        ) ENGINE=InnoDB"
    );

    echo "<p><strong>Migration complete.</strong> Handa na ang Admin module (Users, Schools &amp; Courses, Activity Log).</p>";
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Admin module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
