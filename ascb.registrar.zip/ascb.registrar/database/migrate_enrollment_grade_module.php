<?php
/* Backward-compatible migration entry point.
   Existing installations may already have this filename bookmarked.
   The actual migration now lives in migrate_grade_management_module.php. */
require __DIR__ . '/migrate_grade_management_module.php';
