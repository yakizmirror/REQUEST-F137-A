<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ENROLLMENT: STUDENT ID
   ---------------------------------------------------------
   Idinagdag ito para sa auto-generated "Student ID" ng bawat
   estudyante (hal. 2026-00001). Nagdadagdag ito ng BAGONG
   column sa existing na `enrollees` table:

       student_id   VARCHAR(20)   — hal. "2026-00001"

   Paano gumagana ang Student ID:
     - Sa unang enrollment ng isang estudyante ("SAVE ENROLLEE"),
       awtomatikong gumagawa ng bagong Student ID ang system
       (taon ng first enrollment + 5-digit running number).
     - Kapag gumamit ng "New Term" (bagong record para sa
       susunod na term), ang PAREHONG Student ID ng estudyante
       ang gagamitin — hindi na gagawa ng bago — kaya iisa lang
       ang Student ID niya kahit ilang term/record pa niya.
     - Hindi na nagbabago ang Student ID kapag "Update" (edit)
       lang ang ginawa.

   Walang binabago o binubura sa mga existing rows/columns —
   ligtas itong patakbuhin kahit may laman na ang enrollees mo.
   Idempotent ito (safe ulitin) — chinecheck muna kung nandiyan
   na ang column bago idagdag, at BINIBIGYAN AGAD ng Student ID
   ang mga LUMANG record na wala pa nito (grouped by
   Surname + Given Name + Middle Name, kagaya ng ginagawa ng
   Grade Evaluation module, para isang Student ID lang bawat
   estudyante kahit maraming term na naka-record na siya).

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_enrollment_student_id_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

function ascb_migrate_studentid_column_exists($pdo, $table, $column) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $stmt->execute(array($table, $column));
    return ((int) $stmt->fetchColumn()) > 0;
}

function ascb_migrate_studentid_index_exists($pdo, $table, $indexName) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?"
    );
    $stmt->execute(array($table, $indexName));
    return ((int) $stmt->fetchColumn()) > 0;
}

try {
    $columnAdded = false;

    if (!ascb_migrate_studentid_column_exists($pdo, 'enrollees', 'student_id')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN student_id VARCHAR(20) DEFAULT NULL AFTER id");
        $columnAdded = true;
    }

    if (!ascb_migrate_studentid_index_exists($pdo, 'enrollees', 'idx_enrollee_student_id')) {
        $pdo->exec("ALTER TABLE enrollees ADD INDEX idx_enrollee_student_id (student_id)");
    }

    /* ---------------------------------------------------
       BACKFILL — bigyan ng Student ID ang mga lumang record
       na wala pa nito, isang Student ID bawat estudyante
       (grouped by pangalan), base sa taon ng UNANG record
       niya at pagkakasunod-sunod ng pagka-enroll.
       --------------------------------------------------- */
    $rows = $pdo->query(
        "SELECT id, surname, first_name, middle_name, created_at
           FROM enrollees
          WHERE student_id IS NULL OR student_id = ''
          ORDER BY created_at ASC, id ASC"
    )->fetchAll();

    $groups = array();
    foreach ($rows as $row) {
        $key = mb_strtolower(trim($row['surname'])) . '|'
             . mb_strtolower(trim($row['first_name'])) . '|'
             . mb_strtolower(trim($row['middle_name']));
        if (!isset($groups[$key])) {
            $groups[$key] = array();
        }
        $groups[$key][] = $row;
    }

    // Alamin ang huling ginamit na sequence number bawat taon,
    // para hindi mag-tama sa mga bagong ie-generate sa hinaharap.
    $yearMax = array();
    $stmt = $pdo->query("SELECT student_id FROM enrollees WHERE student_id LIKE '____-%'");
    foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $sid) {
        if (preg_match('/^(\d{4})-(\d+)$/', $sid, $m)) {
            $y = $m[1];
            $n = (int) $m[2];
            if (!isset($yearMax[$y]) || $n > $yearMax[$y]) {
                $yearMax[$y] = $n;
            }
        }
    }

    $updateStmt = $pdo->prepare("UPDATE enrollees SET student_id = ? WHERE id = ?");
    $backfilled = 0;

    foreach ($groups as $terms) {
        $first = $terms[0];
        $year = $first['created_at'] ? date('Y', strtotime($first['created_at'])) : date('Y');

        if (!isset($yearMax[$year])) {
            $yearMax[$year] = 0;
        }
        $yearMax[$year] += 1;

        $studentId = $year . '-' . str_pad($yearMax[$year], 5, '0', STR_PAD_LEFT);

        foreach ($terms as $termRow) {
            $updateStmt->execute(array($studentId, $termRow['id']));
            $backfilled++;
        }
    }

    echo "<p><strong>Migration complete.</strong> Handa na ang Student ID module.</p>";
    echo "<p>Column <code>student_id</code>: " . ($columnAdded ? "naidagdag." : "nandiyan na (nilaktawan).") . "</p>";
    echo "<p>Nabigyan ng Student ID ang " . (int) $backfilled . " (na) lumang record na wala pa nito.</p>";
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Student ID module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
