<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ONE-TIME USER SEEDER
   ---------------------------------------------------------
   Bakit hiwalay ito sa .sql file? Dahil kailangang i-hash
   (via PHP password_hash) ang mga password bago isave sa
   database — hindi pwedeng plain text lang. Ang PHP na
   tumatakbo sa XAMPP mo mismo ang gagawa ng hash, kaya
   dapat browser/localhost ang magpatakbo nito, hindi phpMyAdmin.

   PAANO GAMITIN:
     1. Siguraduhing na-import mo na ang ascb_registrar.sql
        (gumawa ito ng mga tables, pero WALANG laman ang
        `users` table).
     2. Buksan sa browser:
        http://localhost/ascb-registrar/database/seed_users.php
     3. Kapag nakita mong "Successfully created 4 user account/s"
        — TAPOS NA. I-delete o i-rename mo na ang file na ito
        (halimbawa: seed_users.php.bak) para hindi na ito
        maabot ninuman pagkatapos.

   Kung gusto mong magdagdag pa ng account paglaon, mas ligtas
   gumawa ka na lang ng sarili mong munting script (o direkta
   sa phpMyAdmin) na gagamit din ng password_hash() — huwag
   nang i-re-run ang file na ito.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

/* Ang mga starting account — parehong username/password/pangalan
   ng orihinal na hardcoded ASCB_USERS sa auth.js.

   NOTE (dinala mula sa dating auth.js comment): 3 dito ay malinaw
   ang pagkakatugma ng "Prepared By" code (initials + apelyido).
   Ang SALUBRE ay walang klarong tugma sa dating dropdown list
   ("francelmae" ay hindi mukhang Salubre) — hula lang ito sa
   pag-eliminate. Puwede itong ayusin diretso sa `users` table
   (column na `prepared_by_code`) kapag nakumpirma na ang tamang code. */
$staff = [
    ['username' => 'admin', 'password' => 'amparo',   'display_name' => 'REYNALYN AMPARO',    'role' => 'ADMIN STAFF', 'prepared_by_code' => 'rbamparo'],
    ['username' => 'admin', 'password' => 'castillo', 'display_name' => 'ARCHIE CASTILLO',     'role' => 'ADMIN STAFF', 'prepared_by_code' => 'accastillo'],
    ['username' => 'admin', 'password' => 'yasoña',   'display_name' => 'R.M. SMITH YASOÑA',   'role' => 'ADMIN STAFF', 'prepared_by_code' => 'rmyasoña'],
    ['username' => 'admin', 'password' => 'salubre',  'display_name' => 'FRANCEL MAE SALUBRE', 'role' => 'ADMIN STAFF', 'prepared_by_code' => 'francelmae'],
    ['username' => 'admin', 'password' => 'bontia',  'display_name' => 'JOSELITO BONTIA, MAEd', 'role' => 'UNIT HEAD', 'prepared_by_code' => 'jgbontia'],
    ['username' => 'admin', 'password' => 'caponong',  'display_name' => 'REBECCA CAPONONG, MAEd', 'role' => 'SCHOOL REGISTRAR', 'prepared_by_code' => 'rcaponong'],
];

header('Content-Type: text/html; charset=utf-8');

$existing = $pdo->query("SELECT COUNT(*) AS c FROM users")->fetch();

if ((int)$existing['c'] > 0) {
    echo "<p>May laman na ang <code>users</code> table (" . (int)$existing['c'] . " account/s). ";
    echo "Para hindi ma-duplicate, hindi na ito tumakbo.</p>";
    echo "<p>Kung gusto mong i-reset: sa phpMyAdmin, i-TRUNCATE ang <code>users</code> table, tapos i-reload ang page na ito.</p>";
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO users (username, password_hash, display_name, role, prepared_by_code)
     VALUES (?, ?, ?, ?, ?)"
);

$count = 0;
foreach ($staff as $s) {
    $stmt->execute([
        $s['username'],
        password_hash($s['password'], PASSWORD_DEFAULT),
        $s['display_name'],
        $s['role'],
        $s['prepared_by_code'],
    ]);
    $count++;
}

echo "<p><strong>Successfully created {$count} user account/s.</strong></p>";
echo "<p>⚠️ <strong>IMPORTANT:</strong> Para sa security, i-delete o i-rename na ang file na ito ";
echo "(<code>database/seed_users.php</code>) ngayong tapos na ang setup.</p>";
echo "<p><a href=\"../index.php\">← Pumunta sa Login page</a></p>";
