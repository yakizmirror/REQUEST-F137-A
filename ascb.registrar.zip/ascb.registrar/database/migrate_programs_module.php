<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — PROGRAMS & SUBJECTS MODULE MIGRATION
   ---------------------------------------------------------
   Idinagdag ito para sa bagong "Programs & Subjects" na bahagi
   ng Admin panel — dito pwedeng magdagdag ng BAGONG Course/
   Program (kasama ang Major kung meron, at kung Trimester o
   Semester ang term system nito), pati na rin ang mga Subject
   nito bawat Year Level + Term. Awtomatiko itong lalabas sa
   Enrollment module (Course/Program dropdown at "Load Subjects
   for Term") — hindi na kailangang mag-edit ng code.

   Gumagawa lang ito ng BAGONG tables (`programs` at
   `program_subjects`) — walang ginagalaw o binabago sa mga
   existing tables/data mo, kaya ligtas itong patakbuhin kahit
   may laman na ang database mo.

   PAANO GAMITIN:
     1. Buksan sa browser:
            
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
        Idempotent ito (safe ulitin — hindi ito gagawa ng
        duplicate na table o magbubura ng laman).
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS programs (
            id           INT AUTO_INCREMENT PRIMARY KEY,
            department_id INT DEFAULT NULL,
            code         VARCHAR(30)   NOT NULL,   -- hal. \"BSHM\" o \"BSBA-OM\" (may major)
            course_name  VARCHAR(200)  NOT NULL,   -- hal. \"Bachelor of Science in Hospitality Management\"
            major        VARCHAR(150)  DEFAULT NULL, -- blangko kung walang major
            term_type    ENUM('Trimester','Semester') NOT NULL DEFAULT 'Trimester',
            is_active    TINYINT(1)    NOT NULL DEFAULT 1,
            created_at   TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_program_code (code)
        ) ENGINE=InnoDB"
    );

    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS program_subjects (
            id            INT AUTO_INCREMENT PRIMARY KEY,
            program_id    INT           NOT NULL,
            year_level    VARCHAR(30)   NOT NULL,  -- hal. \"1st Year\"
            term_label    VARCHAR(30)   NOT NULL,  -- hal. \"1st Trimester\" o \"1st Semester\"
            subject_code  VARCHAR(50)   NOT NULL,
            description   VARCHAR(255)  NOT NULL,
            units         DECIMAL(4,1)  NOT NULL DEFAULT 3,
            sort_order    INT           NOT NULL DEFAULT 0,
            created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_programsubject_program
                FOREIGN KEY (program_id) REFERENCES programs(id) ON DELETE CASCADE,
            INDEX idx_programsubject_program (program_id),
            INDEX idx_programsubject_term (program_id, year_level, term_label)
        ) ENGINE=InnoDB"
    );

    echo "<p><strong>Migration complete.</strong> Handa na ang Programs &amp; Subjects module (Admin &rarr; Programs &amp; Subjects).</p>";
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Programs &amp; Subjects module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
