<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ENROLLMENT MODULE MIGRATION
   ---------------------------------------------------------
   Idinagdag ito para sa bagong "Enrollment" panel (pagdagdag
   ng basic info ng estudyante: Surname, Given Name, Middle
   Name, Birth Date, Address, Previous School — Junior HS at
   Senior HS). Gumagawa lang ito ng BAGONG table (`enrollees`)
   — walang ginagalaw o binabago sa mga existing tables/data
   mo, kaya ligtas itong patakbuhin kahit may laman na ang
   database mo.

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_enrollment_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
        I-delete o i-rename mo na ang file na ito (hal.
        migrate_enrollment_module.php.bak) kung gusto mo, pero
        hindi naman ito peligroso kahit ma-access ulit paglaon
        dahil idempotent ito (safe ulitin — hindi ito gagawa
        ng duplicate na table o magbubura ng laman).

   NOTE: Kung bagong install ka lamang (kakatapos mo lang
   i-import ang database/ascb_registrar.sql), HINDI mo na
   kailangan patakbuhin ito — kasama na ang `enrollees` table
   doon.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

try {
    $pdo->exec(
        "CREATE TABLE IF NOT EXISTS enrollees (
            id                      INT AUTO_INCREMENT PRIMARY KEY,
            surname                 VARCHAR(100)  NOT NULL,
            first_name              VARCHAR(100)  NOT NULL,
            middle_name             VARCHAR(100)  DEFAULT NULL,
            birth_date              DATE          DEFAULT NULL,
            address                 VARCHAR(255)  DEFAULT NULL,
            prev_school_junior_hs   VARCHAR(255)  DEFAULT NULL,
            prev_school_senior_hs   VARCHAR(255)  DEFAULT NULL,
            enrolled_by_user_id     INT           DEFAULT NULL,
            created_at              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
            CONSTRAINT fk_enrollee_user
                FOREIGN KEY (enrolled_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
            INDEX idx_enrollee_created (created_at),
            INDEX idx_enrollee_name (surname, first_name)
        ) ENGINE=InnoDB"
    );

    echo "<p><strong>Migration complete.</strong> Handa na ang Enrollment module.</p>";
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Enrollment module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
