<?php
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/db.php';
header('Content-Type: text/html; charset=utf-8');

try {
    $pdo->beginTransaction();

    $pdo->exec("CREATE TABLE IF NOT EXISTS enrollment_subjects (
        id INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_id INT NOT NULL,
        course_code VARCHAR(50) DEFAULT NULL,
        description VARCHAR(255) NOT NULL,
        units DECIMAL(6,2) NOT NULL DEFAULT 0,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_es_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollees(id) ON DELETE CASCADE,
        INDEX idx_es_enrollment (enrollment_id),
        INDEX idx_es_code (course_code)
    ) ENGINE=InnoDB");

    $pdo->exec("CREATE TABLE IF NOT EXISTS grades (
        id INT AUTO_INCREMENT PRIMARY KEY,
        enrollment_subject_id INT NOT NULL,
        grade VARCHAR(20) DEFAULT NULL,
        entered_by_user_id INT DEFAULT NULL,
        entered_at DATETIME DEFAULT NULL,
        updated_by_user_id INT DEFAULT NULL,
        updated_at DATETIME DEFAULT NULL,
        CONSTRAINT fk_grade_subject FOREIGN KEY (enrollment_subject_id) REFERENCES enrollment_subjects(id) ON DELETE CASCADE,
        CONSTRAINT fk_grade_entered_by FOREIGN KEY (entered_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        CONSTRAINT fk_grade_updated_by FOREIGN KEY (updated_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        UNIQUE KEY uq_grade_subject (enrollment_subject_id),
        INDEX idx_grade_value (grade)
    ) ENGINE=InnoDB");

    $rows = $pdo->query("SELECT id, subjects_json FROM enrollees WHERE archived_at IS NULL")->fetchAll();
    $subjectStmt = $pdo->prepare("SELECT id FROM enrollment_subjects WHERE enrollment_id = ? AND ((course_code IS NOT NULL AND course_code = ?) OR (course_code IS NULL AND ? = '')) AND description = ? LIMIT 1");
    $insertSubject = $pdo->prepare("INSERT INTO enrollment_subjects (enrollment_id, course_code, description, units) VALUES (?, ?, ?, ?)");
    $updateSubject = $pdo->prepare("UPDATE enrollment_subjects SET units = ? WHERE id = ?");
    $findGrade = $pdo->prepare("SELECT id FROM grades WHERE enrollment_subject_id = ? LIMIT 1");
    $insertGrade = $pdo->prepare("INSERT INTO grades (enrollment_subject_id, grade, entered_at) VALUES (?, ?, ?)");
    $updateGrade = $pdo->prepare("UPDATE grades SET grade = ?, updated_at = ? WHERE id = ?");

    $migratedSubjects = 0;
    $migratedGrades = 0;
    foreach ($rows as $row) {
        $subjects = json_decode((string)$row['subjects_json'], true);
        if (!is_array($subjects)) continue;
        foreach ($subjects as $s) {
            $code = trim((string)($s['code'] ?? ''));
            $description = trim((string)($s['description'] ?? ''));
            if ($code === '' && $description === '') continue;
            $units = is_numeric($s['units'] ?? null) ? (float)$s['units'] : 0;
            $subjectStmt->execute([(int)$row['id'], $code, $code, $description]);
            $subjectId = $subjectStmt->fetchColumn();
            if (!$subjectId) {
                $insertSubject->execute([(int)$row['id'], $code !== '' ? $code : null, $description !== '' ? $description : '(No description)', $units]);
                $subjectId = $pdo->lastInsertId();
                $migratedSubjects++;
            } else {
                $updateSubject->execute([$units, $subjectId]);
            }
            $grade = trim((string)($s['grade'] ?? ''));
            if ($grade !== '') {
                $findGrade->execute([(int)$subjectId]);
                $gid = $findGrade->fetchColumn();
                if ($gid) {
                    $updateGrade->execute([$grade, date('Y-m-d H:i:s'), $gid]);
                } else {
                    $insertGrade->execute([(int)$subjectId, $grade, date('Y-m-d H:i:s')]);
                    $migratedGrades++;
                }
            }
        }
    }

    $pdo->commit();
    echo '<h2>Grade Management migration complete.</h2>';
    echo '<p>Subjects migrated/created: '.htmlspecialchars((string)$migratedSubjects).'</p>';
    echo '<p>Grades migrated/created: '.htmlspecialchars((string)$migratedGrades).'</p>';
    echo '<p>Enrollment will now store subjects only. Grades are maintained separately.</p>';
    echo '<p><a href="../dashboard.php">← Back to Dashboard</a></p>';
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    http_response_code(500);
    echo '<h2>Migration failed</h2><pre>'.htmlspecialchars($e->getMessage()).'</pre>';
}
