<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ENROLLMENT: MOBILE NUMBER + APPROVAL
   ---------------------------------------------------------
   Idinagdag ito para sa dalawang bagong bagay sa Enrollment
   module. Nagdadagdag ito ng mga BAGONG column sa existing na
   `enrollees` table:

       mobile_number       VARCHAR(20)  — hal. "09171234567"

       status               ENUM('pending','approved','rejected')
                             DEFAULT 'approved'
       approved_by_user_id  INT          — sino ang nag-approve/reject
       approved_at          DATETIME     — kailan na-approve/reject
       approval_remarks     VARCHAR(255) — opsyonal na dahilan

   Paano gumagana ang APPROVAL:
     - Kapag ang nag-INPUT (SAVE ENROLLEE / Update / New Term) ay
       isang ADMIN STAFF, awtomatikong "pending" ang record —
       kailangan pa itong aprubahan ng UNIT HEAD bago ituring na
       tapos/tama ang datos.
     - Kapag UNIT HEAD o SCHOOL REGISTRAR ang nag-input, awtomatikong
       "approved" agad (hindi na kailangan pang aprubahan pa).
     - Tanging UNIT HEAD lang ang pwedeng mag-Approve/Reject
       (tingnan ang includes/permissions.php, 'approve_enrollment').

   Walang binabago o binubura sa mga existing rows/columns —
   ligtas itong patakbuhin kahit may laman na ang enrollees mo.
   Idempotent ito (safe ulitin) — chinecheck muna kung nandiyan
   na ang column bago idagdag. Ang mga LUMANG record na wala pang
   status ay itatakda bilang "approved" (ituring na tapos/tama na
   dati pa, hindi na kailangang aprubahan pa).

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_enrollment_approval_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

function ascb_migrate_approval_column_exists($pdo, $table, $column) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $stmt->execute(array($table, $column));
    return ((int) $stmt->fetchColumn()) > 0;
}

function ascb_migrate_approval_index_exists($pdo, $table, $indexName) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?"
    );
    $stmt->execute(array($table, $indexName));
    return ((int) $stmt->fetchColumn()) > 0;
}

function ascb_migrate_approval_fk_exists($pdo, $table, $fkName) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'"
    );
    $stmt->execute(array($table, $fkName));
    return ((int) $stmt->fetchColumn()) > 0;
}

try {
    $notes = array();

    /* ---------- mobile_number ---------- */
    if (!ascb_migrate_approval_column_exists($pdo, 'enrollees', 'mobile_number')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN mobile_number VARCHAR(20) DEFAULT NULL AFTER address");
        $notes[] = "Column <code>mobile_number</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>mobile_number</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- status ---------- */
    if (!ascb_migrate_approval_column_exists($pdo, 'enrollees', 'status')) {
        $pdo->exec(
            "ALTER TABLE enrollees
                ADD COLUMN status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved'
                AFTER enrolled_by_user_id"
        );
        $notes[] = "Column <code>status</code>: naidagdag (default 'approved' para sa lumang record).";
    } else {
        $notes[] = "Column <code>status</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- approved_by_user_id ---------- */
    if (!ascb_migrate_approval_column_exists($pdo, 'enrollees', 'approved_by_user_id')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN approved_by_user_id INT DEFAULT NULL AFTER status");
        $notes[] = "Column <code>approved_by_user_id</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>approved_by_user_id</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- approved_at ---------- */
    if (!ascb_migrate_approval_column_exists($pdo, 'enrollees', 'approved_at')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN approved_at DATETIME DEFAULT NULL AFTER approved_by_user_id");
        $notes[] = "Column <code>approved_at</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>approved_at</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- approval_remarks ---------- */
    if (!ascb_migrate_approval_column_exists($pdo, 'enrollees', 'approval_remarks')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN approval_remarks VARCHAR(255) DEFAULT NULL AFTER approved_at");
        $notes[] = "Column <code>approval_remarks</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>approval_remarks</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- index sa status ---------- */
    if (!ascb_migrate_approval_index_exists($pdo, 'enrollees', 'idx_enrollee_status')) {
        $pdo->exec("ALTER TABLE enrollees ADD INDEX idx_enrollee_status (status)");
        $notes[] = "Index <code>idx_enrollee_status</code>: naidagdag.";
    }

    /* ---------- FK ng approver papunta sa users ---------- */
    if (!ascb_migrate_approval_fk_exists($pdo, 'enrollees', 'fk_enrollee_approver')) {
        try {
            $pdo->exec(
                "ALTER TABLE enrollees
                    ADD CONSTRAINT fk_enrollee_approver
                    FOREIGN KEY (approved_by_user_id) REFERENCES users(id) ON DELETE SET NULL"
            );
            $notes[] = "Foreign key <code>fk_enrollee_approver</code>: naidagdag.";
        } catch (PDOException $fkEx) {
            // Hindi kritikal — patuloy pa rin gagana ang approval
            // feature kahit walang FK constraint (edge case lang ito,
            // hal. may orphaned data na sa approved_by_user_id).
            $notes[] = "Foreign key <code>fk_enrollee_approver</code>: hindi naidagdag (" . htmlspecialchars($fkEx->getMessage()) . ") — hindi kritikal, tuloy pa rin ang migration.";
        }
    }

    /* ---------- backfill: lumang record na walang status ---------- */
    $backfilled = $pdo->exec("UPDATE enrollees SET status = 'approved' WHERE status IS NULL OR status = ''");

    echo "<p><strong>Migration complete.</strong> Handa na ang Mobile Number + Approval module ng Enrollment.</p>";
    foreach ($notes as $note) {
        echo "<p>" . $note . "</p>";
    }
    echo "<p>Nai-set sa 'approved' ang " . (int) $backfilled . " (na) lumang record na walang status pa.</p>";
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Mobile Number + Approval module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
