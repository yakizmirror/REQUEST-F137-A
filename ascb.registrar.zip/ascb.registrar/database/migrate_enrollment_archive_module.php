<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ENROLLMENT: REJECTED + ARCHIVE MODULE
   ---------------------------------------------------------
   Idinagdag ito para sa dalawang bagong bagay sa Enrollment
   module:

     1. REJECTED STUDENTS — mga record na "rejected" (status
        column, nandiyan na mula sa approval module) ay HINDI
        na lumalabas sa Grade Evaluation at sa normal na
        Enrollment / New Term list — ang mga ito ay makikita
        na lang sa bagong "Rejected Students" menu, hanggang
        i-delete (i-archive) o baguhin pa ang record.

     2. ARCHIVE — kapag "na-delete" ang isang enrollee (mula sa
        Enrollment, New Term, o Rejected Students list), HINDI
        na ito tuluyang binubura sa database — inililipat na
        lang ito sa "Archive" (para sa mga estudyanteng nag-drop
        o tinanggal na sa listahan), gamit ang mga BAGONG column
        na ito sa `enrollees` table:

          archived_at           DATETIME     — kailan na-archive
          archived_by_user_id   INT          — sino ang nag-archive
          archive_reason        VARCHAR(255) — opsyonal na dahilan

        Tanging record na NAKA-ARCHIVE NA ang tunay na
        binubura (permanent delete) kapag "Delete Permanently"
        mula mismo sa Archive view — normal na "Delete" (mula sa
        Enrollment / New Term / Rejected Students) ay archive lang.

   Walang binabago o binubura sa mga existing rows/columns —
   ligtas itong patakbuhin kahit may laman na ang enrollees mo.
   Idempotent ito (safe ulitin) — chinecheck muna kung nandiyan
   na ang column bago idagdag.

   PAANO GAMITIN:
     1. Buksan sa browser:
        http://localhost/ascb-registrar/database/migrate_enrollment_archive_module.php
     2. Kapag nakita mong "Migration complete" — TAPOS NA.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

header('Content-Type: text/html; charset=utf-8');

function ascb_migrate_archive_column_exists($pdo, $table, $column) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?"
    );
    $stmt->execute(array($table, $column));
    return ((int) $stmt->fetchColumn()) > 0;
}

function ascb_migrate_archive_index_exists($pdo, $table, $indexName) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.STATISTICS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND INDEX_NAME = ?"
    );
    $stmt->execute(array($table, $indexName));
    return ((int) $stmt->fetchColumn()) > 0;
}

function ascb_migrate_archive_fk_exists($pdo, $table, $fkName) {
    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLE_CONSTRAINTS
          WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND CONSTRAINT_NAME = ?
            AND CONSTRAINT_TYPE = 'FOREIGN KEY'"
    );
    $stmt->execute(array($table, $fkName));
    return ((int) $stmt->fetchColumn()) > 0;
}

try {
    $notes = array();

    /* ---------- archived_at ---------- */
    if (!ascb_migrate_archive_column_exists($pdo, 'enrollees', 'archived_at')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN archived_at DATETIME DEFAULT NULL AFTER approval_remarks");
        $notes[] = "Column <code>archived_at</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>archived_at</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- archived_by_user_id ---------- */
    if (!ascb_migrate_archive_column_exists($pdo, 'enrollees', 'archived_by_user_id')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN archived_by_user_id INT DEFAULT NULL AFTER archived_at");
        $notes[] = "Column <code>archived_by_user_id</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>archived_by_user_id</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- archive_reason ---------- */
    if (!ascb_migrate_archive_column_exists($pdo, 'enrollees', 'archive_reason')) {
        $pdo->exec("ALTER TABLE enrollees ADD COLUMN archive_reason VARCHAR(255) DEFAULT NULL AFTER archived_by_user_id");
        $notes[] = "Column <code>archive_reason</code>: naidagdag.";
    } else {
        $notes[] = "Column <code>archive_reason</code>: nandiyan na (nilaktawan).";
    }

    /* ---------- index sa archived_at ---------- */
    if (!ascb_migrate_archive_index_exists($pdo, 'enrollees', 'idx_enrollee_archived')) {
        $pdo->exec("ALTER TABLE enrollees ADD INDEX idx_enrollee_archived (archived_at)");
        $notes[] = "Index <code>idx_enrollee_archived</code>: naidagdag.";
    }

    /* ---------- FK ng archiver papunta sa users ---------- */
    if (!ascb_migrate_archive_fk_exists($pdo, 'enrollees', 'fk_enrollee_archiver')) {
        try {
            $pdo->exec(
                "ALTER TABLE enrollees
                    ADD CONSTRAINT fk_enrollee_archiver
                    FOREIGN KEY (archived_by_user_id) REFERENCES users(id) ON DELETE SET NULL"
            );
            $notes[] = "Foreign key <code>fk_enrollee_archiver</code>: naidagdag.";
        } catch (PDOException $fkEx) {
            $notes[] = "Foreign key <code>fk_enrollee_archiver</code>: hindi naidagdag (" . htmlspecialchars($fkEx->getMessage()) . ") — hindi kritikal, tuloy pa rin ang migration.";
        }
    }

    echo "<p><strong>Migration complete.</strong> Handa na ang Rejected Students + Archive module ng Enrollment.</p>";
    foreach ($notes as $note) {
        echo "<p>" . $note . "</p>";
    }
    echo "<p><a href=\"../dashboard.php\">&larr; Pumunta sa Dashboard</a></p>";

} catch (PDOException $e) {
    http_response_code(500);
    echo "<p>May error sa pag-setup ng Rejected Students + Archive module:</p>";
    echo "<pre>" . htmlspecialchars($e->getMessage()) . "</pre>";
}
