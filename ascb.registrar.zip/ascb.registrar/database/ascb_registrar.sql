-- =========================================================
-- ASCB REGISTRAR SYSTEM — DATABASE SCHEMA
-- For XAMPP (MySQL / MariaDB via phpMyAdmin)
-- ---------------------------------------------------------
-- Paano gamitin (phpMyAdmin):
--   1. Buksan ang http://localhost/phpmyadmin
--   2. Click "Import" tab
--   3. Piliin ang file na ito (ascb_registrar.sql)
--   4. Click "Go"
-- Awtomatiko nang gagawin ang database na "ascb_registrar"
-- kasama ang lahat ng tables at starter data (schools/courses).
--
-- NOTE: Ang mga USER ACCOUNTS ay hindi kasama dito dahil
-- kailangan silang i-hash (PHP password_hash) para secure.
-- Pagkatapos i-import ang file na ito, buksan sa browser ang:
--   http://localhost/ascb-registrar/database/seed_users.php
-- para gawin ang 4 na starting accounts.
-- =========================================================

CREATE DATABASE IF NOT EXISTS ascb_registrar
    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

USE ascb_registrar;


-- ---------------------------------------------------------
-- DEPARTMENTS (Dean scope / program grouping)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS departments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    code VARCHAR(30) NOT NULL,
    name VARCHAR(200) NOT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 1,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_department_code (code),
    UNIQUE KEY uniq_department_name (name(191))
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- USERS  (kapalit ng hardcoded ASCB_USERS array sa auth.js)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id                INT AUTO_INCREMENT PRIMARY KEY,
    username          VARCHAR(50)  NOT NULL,
    password_hash     VARCHAR(255) NOT NULL,
    display_name      VARCHAR(100) NOT NULL,
    role              VARCHAR(50)  NOT NULL DEFAULT 'ADMIN STAFF',
    department_id     INT          DEFAULT NULL,
    prepared_by_code  VARCHAR(50)  DEFAULT NULL,
    is_active         TINYINT(1)   NOT NULL DEFAULT 1,
    created_at        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_display_name (display_name),
    INDEX idx_users_department (department_id),
    CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL
    -- NOTE: username ay sinadyang HINDI unique — apat na account
    -- ang gumagamit ng "admin" bilang username sa orihinal na
    -- system, magkakaiba lang ng password. Ganito rin dito:
    -- pinipili ng login.php ang row na tumugma ang username AT
    -- ang password (via password_verify).
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- SCHOOLS  (Form 137-A "receiving school" dropdown)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS schools (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(255) NOT NULL,
    address     VARCHAR(255) DEFAULT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_school_name (name(191))
    -- NOTE: (191) = index prefix length, hindi column length. Ginawa
    -- ito dahil sa mas lumang MySQL/MariaDB (madalas sa old XAMPP),
    -- ang max index length ay 767 bytes lang, at utf8mb4 ay
    -- 4 bytes/character — kaya lalampas ang buong VARCHAR(255) sa
    -- limit na iyon (255 x 4 = 1020 bytes). 191 x 4 = 764 bytes,
    -- ligtas na sa limit. Buo pa rin ang column (VARCHAR(255)),
    -- unique index lang ang naka-limit sa unang 191 characters.
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- COURSES  (Form 137-A course dropdown)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS courses (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100) NOT NULL,
    created_at  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uniq_course_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- ENROLLEES  (Enrollment Module — basic student info)
-- Ginagamit ni api/enrollment.php
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrollees (
    id                      INT AUTO_INCREMENT PRIMARY KEY,
    student_id              VARCHAR(20)   DEFAULT NULL,     -- auto-generated, hal. "2025-00001" (pareho bawat term ng isang estudyante)
    surname                 VARCHAR(100)  NOT NULL,
    first_name              VARCHAR(100)  NOT NULL,
    middle_name             VARCHAR(100)  DEFAULT NULL,
    sex                     ENUM('Male','Female') DEFAULT NULL,
    student_type            ENUM('Regular','Transferee','Irregular') DEFAULT NULL,
    birth_date              DATE          DEFAULT NULL,
    address                 VARCHAR(255)  DEFAULT NULL,
    mobile_number           VARCHAR(20)   DEFAULT NULL,  -- hal. "09171234567"
    prev_school_junior_hs   VARCHAR(255)  DEFAULT NULL,
    prev_school_senior_hs   VARCHAR(255)  DEFAULT NULL,
    program_code            VARCHAR(30)   DEFAULT NULL,  -- hal. BSBA-FM (key sa structuredPrograms/programNames)
    department_id           INT           DEFAULT NULL,     -- snapshot ng Department ng enrollment
    course                  VARCHAR(150)  DEFAULT NULL,  -- pangalan ng kurso, hiwalay sa major
    major                   VARCHAR(150)  DEFAULT NULL,  -- blangko kung walang major ang kurso
    year_level              VARCHAR(30)   DEFAULT NULL,
    trimester               VARCHAR(30)   DEFAULT NULL,
    school_year             VARCHAR(20)   DEFAULT NULL,  -- hal. "2025-2026" (School Year ng enrollment na ito)
    subjects_json           TEXT          DEFAULT NULL,  -- [{code, description, units, grade}, ...] mula sa prospectus (may grade na per subject)
    enrolled_by_user_id     INT           DEFAULT NULL,
    status                  ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
                                                          -- 'pending' kapag ADMIN STAFF ang nag-input,
                                                          -- naghihintay ng approval ng UNIT HEAD.
    approved_by_user_id     INT           DEFAULT NULL,
    approved_at             DATETIME      DEFAULT NULL,
    approval_remarks        VARCHAR(255)  DEFAULT NULL,  -- opsyonal na dahilan, lalo na kapag na-reject
    archived_at             DATETIME      DEFAULT NULL,  -- kapag "na-delete" (archive, hindi tuluyang delete)
    archived_by_user_id     INT           DEFAULT NULL,
    archive_reason          VARCHAR(255)  DEFAULT NULL,  -- opsyonal na dahilan, hal. "Dropped"
    created_at              TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_enrollee_user
        FOREIGN KEY (enrolled_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_enrollee_approver
        FOREIGN KEY (approved_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_enrollee_archiver
        FOREIGN KEY (archived_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_enrollee_department
        FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
    INDEX idx_enrollee_created (created_at),
    INDEX idx_enrollee_name (surname, first_name),
    INDEX idx_enrollee_student_id (student_id),
    INDEX idx_enrollee_department (department_id),
    INDEX idx_enrollee_status (status),
    INDEX idx_enrollee_archived (archived_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- ENROLLMENT SUBJECTS / GRADES
-- Subjects belong to one enrollment term; grades are maintained
-- separately so editing a grade never changes enrollment approval.
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS enrollment_subjects (
    id                  INT AUTO_INCREMENT PRIMARY KEY,
    enrollment_id       INT NOT NULL,
    course_code         VARCHAR(50)  DEFAULT NULL,
    description         VARCHAR(255) NOT NULL,
    units               DECIMAL(6,2) NOT NULL DEFAULT 0,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_es_enrollment FOREIGN KEY (enrollment_id) REFERENCES enrollees(id) ON DELETE CASCADE,
    INDEX idx_es_enrollment (enrollment_id),
    INDEX idx_es_code (course_code)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS grades (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    enrollment_subject_id INT NOT NULL,
    grade                 VARCHAR(20) DEFAULT NULL,
    entered_by_user_id    INT DEFAULT NULL,
    entered_at            DATETIME DEFAULT NULL,
    updated_by_user_id    INT DEFAULT NULL,
    updated_at            DATETIME DEFAULT NULL,
    CONSTRAINT fk_grade_subject FOREIGN KEY (enrollment_subject_id) REFERENCES enrollment_subjects(id) ON DELETE CASCADE,
    CONSTRAINT fk_grade_entered_by FOREIGN KEY (entered_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    CONSTRAINT fk_grade_updated_by FOREIGN KEY (updated_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE KEY uq_grade_subject (enrollment_subject_id),
    INDEX idx_grade_value (grade)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- CERTIFICATES  (log ng bawat na-generate na certificate)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS certificates (
    id                 INT AUTO_INCREMENT PRIMARY KEY,
    certificate_type   VARCHAR(30)   NOT NULL,   -- ENROLLMENT / REGISTRATION / GRADE_EVALUATION
    student_name       VARCHAR(150)  NOT NULL,
    student_id         VARCHAR(50)   NOT NULL,
    program            VARCHAR(50)   NOT NULL,
    year_level         VARCHAR(30)   NOT NULL,
    trimester          VARCHAR(30)   NOT NULL,
    academic_year      VARCHAR(20)   NOT NULL,
    enrollment_date    DATE          DEFAULT NULL,
    status             VARCHAR(30)   DEFAULT NULL,
    or_number          VARCHAR(50)   DEFAULT NULL,
    total_units        DECIMAL(6,2)  DEFAULT NULL,
    gwa                DECIMAL(4,2)  DEFAULT NULL,
    subjects_json      TEXT          DEFAULT NULL,  -- [{code, description, grade, units}, ...]
    prepared_by        VARCHAR(50)   DEFAULT NULL,
    issued_by_user_id  INT           DEFAULT NULL,
    created_at         TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_certificates_user
        FOREIGN KEY (issued_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_cert_student (student_id),
    INDEX idx_cert_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- FORM 137 REQUESTS  (log ng bawat Form 137-A request letter)
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS form137_requests (
    id                    INT AUTO_INCREMENT PRIMARY KEY,
    request_date          DATE          DEFAULT NULL,
    school_name           VARCHAR(255)  NOT NULL,
    school_address        VARCHAR(255)  DEFAULT NULL,
    first_request         TINYINT(1)    NOT NULL DEFAULT 0,
    second_request        TINYINT(1)    NOT NULL DEFAULT 0,
    urgent_request        TINYINT(1)    NOT NULL DEFAULT 0,
    bearer_request        TINYINT(1)    NOT NULL DEFAULT 0,
    copy_for_ascb         TINYINT(1)    NOT NULL DEFAULT 0,
    students_json         TEXT          NOT NULL,  -- [{name, course, schoolYear, yearSection}, ...]
    requested_by_user_id  INT           DEFAULT NULL,
    created_at            TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_f137_user
        FOREIGN KEY (requested_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_f137_created (created_at)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- DOCUMENT TRANSACTIONS  (Releasing & Receiving of Documents)
-- Ginagamit ni api/documents.php
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS document_transactions (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    direction            VARCHAR(10)   NOT NULL,   -- RELEASED / RECEIVED
    document_name        VARCHAR(255)  NOT NULL,
    party_name           VARCHAR(255)  NOT NULL,
    transaction_date     DATE          DEFAULT NULL,
    remarks              VARCHAR(500)  DEFAULT NULL,
    handled_by_user_id   INT           DEFAULT NULL,
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doctx_user
        FOREIGN KEY (handled_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_doctx_created (created_at),
    INDEX idx_doctx_direction (direction)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- DOCUMENT TRANSACTION FILES  (mga naka-attach na PDF bawat entry)
-- Ginagamit ni api/documents.php at api/document_file.php
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS document_transaction_files (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id       INT           NOT NULL,
    original_filename    VARCHAR(255)  NOT NULL,
    stored_filename      VARCHAR(255)  NOT NULL,
    filesize_bytes       BIGINT        DEFAULT NULL,
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_doctxfile_tx
        FOREIGN KEY (transaction_id) REFERENCES document_transactions(id) ON DELETE CASCADE,
    INDEX idx_doctxfile_tx (transaction_id)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- APPROVED SO  (pangalan + isang PDF file bawat entry)
-- Ginagamit ni api/approved_so.php at api/approved_so_file.php
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS approved_so (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    name                 VARCHAR(255)  NOT NULL,
    stored_filename      VARCHAR(255)  NOT NULL,
    original_filename    VARCHAR(255)  NOT NULL,
    filesize_bytes       BIGINT        DEFAULT NULL,
    uploaded_by_user_id  INT           DEFAULT NULL,
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_approvedso_user
        FOREIGN KEY (uploaded_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_approvedso_created (created_at),
    INDEX idx_approvedso_name (name)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- COURSE FILES  (pangalan + course + isang Excel file bawat entry)
-- Ginagamit ni api/course_files.php at api/course_files_file.php
-- NOTE: SADYANG WALANG "UPDATE/REPLACE FILE" — sa design pa
-- lang, hindi na mababago ang laman ng na-upload na Excel file
-- (create + delete lang, tulad ng update ng approved_so).
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS course_files (
    id                   INT AUTO_INCREMENT PRIMARY KEY,
    student_name         VARCHAR(255)  NOT NULL,
    course                VARCHAR(100)  NOT NULL,
    stored_filename      VARCHAR(255)  NOT NULL,
    original_filename    VARCHAR(255)  NOT NULL,
    filesize_bytes       BIGINT        DEFAULT NULL,
    uploaded_by_user_id  INT           DEFAULT NULL,
    created_at           TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_coursefiles_user
        FOREIGN KEY (uploaded_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_coursefiles_created (created_at),
    INDEX idx_coursefiles_name (student_name),
    INDEX idx_coursefiles_course (course)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- ACTIVITY LOG  (history ng Admin panel: user accounts,
-- schools/courses, login/logout)
-- Ginagamit ni includes/activity_log.php at api/activity_log.php
-- ---------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity_log (
    id            INT AUTO_INCREMENT PRIMARY KEY,
    user_id       INT           DEFAULT NULL,
    display_name  VARCHAR(100)  DEFAULT NULL,
    role          VARCHAR(50)   DEFAULT NULL,
    action        VARCHAR(50)   NOT NULL,
    entity_type   VARCHAR(30)   DEFAULT NULL,
    entity_label  VARCHAR(255)  DEFAULT NULL,
    details       VARCHAR(500)  DEFAULT NULL,
    created_at    TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_activitylog_user
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL,
    INDEX idx_activitylog_created (created_at),
    INDEX idx_activitylog_action (action)
) ENGINE=InnoDB;

-- ---------------------------------------------------------
-- STARTER DATA — Schools (galing sa dating F137_DEFAULT_SCHOOLS)
-- ---------------------------------------------------------
INSERT INTO schools (name, address) VALUES
    ('ANDRES SORIANO COLLEGES OF BISLIG, INC.', 'Mangagoy, Bislig City'),
    ('TABON M. ESTRELLA NATIONAL HIGH SCHOOL', 'Tabon, Bislig City'),
    ('STAND ALONE SENIOR HIGH SCHOOL', 'Comawas, Bislig City'),
    ('SOUTHERN TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES, INC.', 'Andres Soriano Avenue, Mangagoy, Bislig City'),
    ('AGUSAN NATIONAL HIGH SCHOOL', 'Butuan City, Surigao del Sur'),
    ('BERNARDO D. CARPIO NATIONAL HIGH SCHOOL', 'Pioneer Village, Buhangin, Davao City'),
    ('BISLIG CITY NATIONAL HIGH SCHOOL', 'Purok 10 Villa Josefa Poblacion, Bislig City'),
    ('HINATUAN NATIONAL COMPREHENSIVE HIGH SCHOOL', 'Sto. Niño, Hinatuan, Surigao del Sur'),
    ('LAWIGAN NATIONAL HIGH SCHOOL', 'Lawigan, Bislig City'),
    ('LINGIG NATIONAL HIGH SCHOOL', 'Lingig 1 District'),
    ('MAHARLIKA NATIONAL HIGH SCHOOL', 'Maharlika, Bislig City')
ON DUPLICATE KEY UPDATE address = VALUES(address);

-- ---------------------------------------------------------
-- STARTER DATA — Courses (galing sa dating F137_DEFAULT_COURSES)
-- ---------------------------------------------------------
INSERT INTO courses (name) VALUES
    ('BSIT'), ('BSCS'), ('BSIS'), ('BEED'),
    ('BSBA-MM'), ('BSBA-FM'), ('BSBA-HRDM'), ('BSED-ENGLISH')
ON DUPLICATE KEY UPDATE name = VALUES(name);


-- PROGRAMS & SUBJECTS (Department-aware)
CREATE TABLE IF NOT EXISTS programs (
 id INT AUTO_INCREMENT PRIMARY KEY, department_id INT DEFAULT NULL, code VARCHAR(30) NOT NULL,
 course_name VARCHAR(200) NOT NULL, major VARCHAR(150) DEFAULT NULL,
 term_type ENUM('Trimester','Semester') NOT NULL DEFAULT 'Trimester', is_active TINYINT(1) NOT NULL DEFAULT 1,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE KEY uniq_program_code(code), INDEX idx_programs_department(department_id),
 CONSTRAINT fk_programs_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS program_subjects (
 id INT AUTO_INCREMENT PRIMARY KEY, program_id INT NOT NULL, year_level VARCHAR(30) NOT NULL, term_label VARCHAR(30) NOT NULL,
 subject_code VARCHAR(50) NOT NULL, description VARCHAR(255) NOT NULL, units DECIMAL(4,1) NOT NULL DEFAULT 3, sort_order INT NOT NULL DEFAULT 0,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, CONSTRAINT fk_programsubject_program FOREIGN KEY(program_id) REFERENCES programs(id) ON DELETE CASCADE,
 INDEX idx_programsubject_program(program_id), INDEX idx_programsubject_term(program_id,year_level,term_label)
) ENGINE=InnoDB;
CREATE TABLE IF NOT EXISTS backup_history (
 id INT AUTO_INCREMENT PRIMARY KEY, backup_type VARCHAR(30) NOT NULL, department_id INT DEFAULT NULL, school_year VARCHAR(20) DEFAULT NULL,
 term_label VARCHAR(30) DEFAULT NULL, filename VARCHAR(255) NOT NULL, created_by_user_id INT DEFAULT NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CONSTRAINT fk_backup_department FOREIGN KEY(department_id) REFERENCES departments(id) ON DELETE SET NULL,
 CONSTRAINT fk_backup_user FOREIGN KEY(created_by_user_id) REFERENCES users(id) ON DELETE SET NULL, INDEX idx_backup_created(created_at)
) ENGINE=InnoDB;
