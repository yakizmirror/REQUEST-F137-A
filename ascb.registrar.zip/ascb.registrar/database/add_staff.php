<?php
require_once __DIR__ . '/setup_guard.php';

/* =========================================================
   ASCB REGISTRAR SYSTEM — ADD 2 NEW STAFF ACCOUNTS
   ---------------------------------------------------------
   Idinagdag lang ito para sa UNIT HEAD (Joselito Bontia) at
   SCHOOL REGISTRAR (Rebecca Caponong) — hindi na kailangang
   patakbuhin ulit ang seed_users.php dahil may laman na ang
   `users` table mo.

   PAANO GAMITIN:
     1. I-save ang file na ito sa parehong folder ng
        seed_users.php (yung /database/ folder).
     2. Buksan sa browser:
        http://localhost/ascb-registrar/database/add_staff.php
     3. Kapag nakita mong "Successfully added..." — TAPOS NA.
        I-delete o i-rename mo agad ang file na ito
        (hal. add_staff.php.bak) para hindi na ito maabot
        ninuman pagkatapos.
   ========================================================= */

require_once __DIR__ . '/../config/db.php';

/* Mga bagong account na idadagdag */
$newStaff = [
    ['username' => 'admin', 'password' => 'bontia',   'display_name' => 'JOSELITO BONTIA, MAEd',  'role' => 'UNIT HEAD',       'prepared_by_code' => 'jgbontia'],
    ['username' => 'admin', 'password' => 'caponong', 'display_name' => 'REBECCA CAPONONG, MAEd', 'role' => 'SCHOOL REGISTRAR', 'prepared_by_code' => 'rcaponong'],
];

header('Content-Type: text/html; charset=utf-8');

/* Iwasang ma-duplicate: i-check muna per display_name kung
   existing na siya bago mag-insert. */
$checkStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE display_name = ?");
$insertStmt = $pdo->prepare(
    "INSERT INTO users (username, password_hash, display_name, role, prepared_by_code)
     VALUES (?, ?, ?, ?, ?)"
);

$added = 0;
$skipped = [];

foreach ($newStaff as $s) {
    $checkStmt->execute([$s['display_name']]);
    $exists = (int) $checkStmt->fetch()['c'];

    if ($exists > 0) {
        $skipped[] = $s['display_name'];
        continue;
    }

    $insertStmt->execute([
        $s['username'],
        password_hash($s['password'], PASSWORD_DEFAULT),
        $s['display_name'],
        $s['role'],
        $s['prepared_by_code'],
    ]);
    $added++;
}

echo "<p><strong>Successfully added {$added} new staff account/s.</strong></p>";

if ($skipped) {
    echo "<p>Na-skip (may existing na row na parehong display_name): " . implode(', ', $skipped) . "</p>";
}

echo "<p>⚠️ <strong>IMPORTANT:</strong> Para sa security, i-delete o i-rename na ang file na ito ";
echo "(<code>database/add_staff.php</code>) ngayong tapos na.</p>";
echo "<p><a href=\"../index.php\">← Pumunta sa Login page</a></p>";
