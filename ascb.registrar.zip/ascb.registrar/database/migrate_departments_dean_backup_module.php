<?php
require_once __DIR__ . '/setup_guard.php';
require_once __DIR__ . '/../config/db.php';
header('Content-Type: text/html; charset=utf-8');
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS departments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        code VARCHAR(30) NOT NULL,
        name VARCHAR(200) NOT NULL,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uniq_department_code (code),
        UNIQUE KEY uniq_department_name (name(191))
    ) ENGINE=InnoDB");

    $builtins = array(
        array('BSCS','Bachelor of Science in Computer Science',null), array('BSIS','Bachelor of Science in Information Systems',null),
        array('BSIT','Bachelor of Science in Information Technology',null), array('BSCRIM','Bachelor of Science in Criminology',null),
        array('BSA','Bachelor of Science in Accountancy',null), array('BSBA-FM','Bachelor of Science in Business Administration','Financial Management'),
        array('BSBA-HRDM','Bachelor of Science in Business Administration','Human Resource Development Management'), array('BSBA-MM','Bachelor of Science in Business Administration','Marketing Management'),
        array('BEED','Bachelor of Elementary Education',null), array('BSED-ENGLISH','Bachelor of Secondary Education','English'),
        array('BSED-MATH','Bachelor of Secondary Education','Mathematics'), array('BSED-SOCIAL','Bachelor of Secondary Education','Social Studies')
    );
    $ins=$pdo->prepare("INSERT IGNORE INTO programs(code,course_name,major,term_type,is_active) VALUES(?,?,?,'Trimester',1)"); foreach($builtins as $bp)$ins->execute($bp);

    $c=$pdo->query("SHOW COLUMNS FROM users LIKE 'department_id'")->fetch();
    if(!$c) $pdo->exec("ALTER TABLE users ADD COLUMN department_id INT DEFAULT NULL AFTER role, ADD INDEX idx_users_department (department_id), ADD CONSTRAINT fk_users_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL");

    $c=$pdo->query("SHOW COLUMNS FROM programs LIKE 'department_id'")->fetch();
    if(!$c) $pdo->exec("ALTER TABLE programs ADD COLUMN department_id INT DEFAULT NULL AFTER id, ADD INDEX idx_programs_department (department_id), ADD CONSTRAINT fk_programs_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL");

    $c=$pdo->query("SHOW COLUMNS FROM enrollees LIKE 'department_id'")->fetch();
    if(!$c) $pdo->exec("ALTER TABLE enrollees ADD COLUMN department_id INT DEFAULT NULL AFTER program_code, ADD INDEX idx_enrollee_department (department_id), ADD CONSTRAINT fk_enrollee_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL");
    $pdo->exec("UPDATE enrollees e INNER JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code)) SET e.department_id=p.department_id WHERE e.department_id IS NULL AND p.department_id IS NOT NULL");

    $pdo->exec("CREATE TABLE IF NOT EXISTS backup_history (
        id INT AUTO_INCREMENT PRIMARY KEY,
        backup_type VARCHAR(30) NOT NULL,
        department_id INT DEFAULT NULL,
        school_year VARCHAR(20) DEFAULT NULL,
        term_label VARCHAR(30) DEFAULT NULL,
        filename VARCHAR(255) NOT NULL,
        created_by_user_id INT DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        CONSTRAINT fk_backup_department FOREIGN KEY (department_id) REFERENCES departments(id) ON DELETE SET NULL,
        CONSTRAINT fk_backup_user FOREIGN KEY (created_by_user_id) REFERENCES users(id) ON DELETE SET NULL,
        INDEX idx_backup_created (created_at)
    ) ENGINE=InnoDB");

    echo '<h2>Department / Dean / Backup migration complete.</h2>';
    echo '<p>Pwede nang gumawa ng Departments, mag-assign ng Program at Dean, at gumamit ng Department Excel export / Full SQL backup.</p>';
    echo '<p><a href="../dashboard.php">&larr; Dashboard</a></p>';
} catch (PDOException $e) { http_response_code(500); echo '<pre>'.htmlspecialchars($e->getMessage()).'</pre>'; }
