/* =========================================================
   ASCB REGISTRAR SYSTEM
   UI HELPERS (login/logout is now handled server-side by
   PHP + MySQL — see index.php, logout.php, includes/auth_check.php)
   ---------------------------------------------------------
   Ang mga sumusunod na dating nandito ay pinalitan na ng PHP:
     - ASCB_USERS (hardcoded accounts)       -> `users` table
     - ascbHandleLogin / ascbGetSession/etc  -> index.php ($_SESSION)
     - ascbGuardPage                         -> includes/auth_check.php
     - ascbInitHeaderSession/ascbInitPreparedBy -> server-rendered na
       diretso sa dashboard.php (walang JS na kailangan)
   ========================================================= */

function ascbConfirmLogout() {
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay) overlay.classList.add("active");
}

function ascbCancelLogout() {
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay) overlay.classList.remove("active");
}

function ascbLogout() {
    window.location.href = "logout.php";
}


/* =========================================================
   LOGIN PAGE — show/hide password only
   (ang pag-verify ng username/password ay ginagawa na ng
   index.php sa server, hindi na dito sa browser)
   ========================================================= */

function ascbTogglePasswordVisibility() {
    const passwordInput = document.getElementById("loginPassword");
    const toggleBtn = document.getElementById("loginTogglePw");
    if (!passwordInput || !toggleBtn) return;

    const isHidden = passwordInput.type === "password";
    passwordInput.type = isHidden ? "text" : "password";
    toggleBtn.textContent = isHidden ? "Hide" : "Show";
}


/* =========================================================
   LEFT NAVBAR — VIEW SWITCHING
   Dashboard, Certificates, and Form 137 are all shown/hidden
   in-place as pages — nothing opens as an overlay anymore.
   ========================================================= */

const ASCB_LAST_VIEW_KEY = "ascb_reg_last_view";

function ascbNavigate(view) {
    document.querySelectorAll(".main-nav-link[data-view]").forEach(function (btn) {
        btn.classList.toggle("active", btn.dataset.view === view);
    });

    document.querySelectorAll(".app-view").forEach(function (section) {
        section.classList.toggle("active-view", section.id === view + "View");
    });

    sessionStorage.setItem(ASCB_LAST_VIEW_KEY, view);

    ascbToggleSidebar(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
}

/* Puts the page back on whichever view the user was last on
   (Dashboard / Certificates / Form 137), so reloading the page
   doesn't bounce back to the Dashboard. Call this once, right
   after the view sections exist in the DOM. */
function ascbRestoreLastView() {
    const lastView = sessionStorage.getItem(ASCB_LAST_VIEW_KEY);
    if (!lastView || lastView === "dashboard") return;

    document.querySelectorAll(".main-nav-link[data-view]").forEach(function (btn) {
        btn.classList.toggle("active", btn.dataset.view === lastView);
    });

    document.querySelectorAll(".app-view").forEach(function (section) {
        section.classList.toggle("active-view", section.id === lastView + "View");
    });
}

/* ---------- Actions panel (collapsible, on the Certificates view) ---------- */

function ascbToggleActionsPanel() {
    const panel = document.getElementById("actionsPanel");
    if (panel) panel.classList.toggle("collapsed");
}

/* ---------- Mobile off-canvas sidebar ---------- */

function ascbToggleSidebar(forceOpen) {
    const sidebar = document.getElementById("mainSidebar");
    const backdrop = document.getElementById("sidebarBackdrop");
    if (!sidebar || !backdrop) return;

    const shouldOpen =
        typeof forceOpen === "boolean" ? forceOpen : !sidebar.classList.contains("open");

    sidebar.classList.toggle("open", shouldOpen);
    backdrop.classList.toggle("open", shouldOpen);
}


/* ---------- logout confirmation modal: dismiss helpers ---------- */

document.addEventListener("click", function (event) {
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay && event.target === overlay) {
        ascbCancelLogout();
    }
});

document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") return;
    const overlay = document.getElementById("ascbLogoutModal");
    if (overlay && overlay.classList.contains("active")) {
        ascbCancelLogout();
    }
});
