# ASCB Registrar — Debug / Deployment Hardening Report

## Fixed functional problems
- Restored the missing JavaScript implementation for Approved SO, FORM 9 / Course Files, and the Admin module. The dashboard referenced these functions but they did not exist, which would cause `ReferenceError` and non-working buttons.
- Added client-side pagination/search/rendering for the restored modules.
- Removed a fragile inline Grade Evaluation handler that could break when a grouping key contained quotes/special characters.
- Added an `mbstring`-independent fallback for the sidebar avatar initial, preventing a fatal error on PHP installs without `mbstring`.

## Fixed deployment/security problems
- Database credentials can now come from environment variables or `config/local.php`; local XAMPP defaults still work for development.
- Database errors are generic in production and detailed only when `ASCB_DEBUG=1`.
- Added secure session settings, idle timeout handling, reliable 30-day "Keep me signed in", HttpOnly/SameSite cookies, and standard response security headers.
- Added CSRF protection to all authenticated write API requests.
- Active user/role is re-checked from the database on protected requests, so deactivated/deleted accounts cannot keep using an old session.
- Added slower failed-login response to reduce rapid password guessing.
- New/changed account passwords now require at least 8 characters.
- Prevented demotion of the last active UNIT HEAD account.
- Protected `/config`, `/includes`, `/database`, and `/uploads` from direct Apache web access.
- Setup/migration scripts are guarded against accidental public execution.
- Replaced predictable upload filenames with random server filenames.
- Sanitized download response filenames to avoid response-header injection.
- Upload folders are checked for write permission and return a clear deployment error if not writable.
- Changed the application's per-file upload limit from an unrealistic hard-coded 1 GB to a configurable 25 MB default (`ASCB_MAX_UPLOAD_MB`).
- Removed uploaded sample/data files from the client-ready package so student/client files are not accidentally handed to another installation.
- Form 137 draft data now uses `sessionStorage` rather than persistent `localStorage`, reducing data left behind on a shared workstation.

## Deployment checks added
- `database/deployment_check.php` checks PHP, extensions, writable upload folders, upload settings, database connectivity, and required tables.
- `DEPLOYMENT_GUIDE.md` documents client setup, database configuration, Apache/Nginx considerations, backups, and final test steps.
- `PHP_UPLOAD_CONFIG_EXAMPLE.ini` contains example PHP upload settings.

## Validation performed in this workspace
- All PHP files passed `php -l` syntax validation after the changes.
- `script.js` and `auth.js` passed Node JavaScript syntax validation.
- Dashboard inline event handlers were statically compared against available JavaScript functions; no missing handlers remain.
- Duplicate HTML `id` values were checked in `dashboard.php`; none were found.

## Environment limitation during test
The sandbox used for this audit does not have the PHP `pdo_mysql` driver or a MySQL server, so a true database integration test could not be executed here. Run `php database/deployment_check.php` on the actual XAMPP/client machine before handoff.
