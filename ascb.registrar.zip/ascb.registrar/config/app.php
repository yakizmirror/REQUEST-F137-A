<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — APPLICATION CONFIGURATION
   ---------------------------------------------------------
   Production-safe defaults. Values can be overridden through
   environment variables without editing PHP source files.
   ========================================================= */

if (!function_exists('ascb_env')) {
    function ascb_env($name, $default = null) {
        $value = getenv($name);
        return ($value === false || $value === '') ? $default : $value;
    }
}

if (!defined('ASCB_DEBUG')) {
    define('ASCB_DEBUG', ascb_env('ASCB_DEBUG', '0') === '1');
}

if (!defined('ASCB_TIMEZONE')) {
    define('ASCB_TIMEZONE', ascb_env('ASCB_TIMEZONE', 'Asia/Manila'));
}
date_default_timezone_set(ASCB_TIMEZONE);

/* Upload limit enforced by the application. The PHP/web-server
   limits must be equal to or higher than this value. */
if (!defined('ASCB_MAX_UPLOAD_MB')) {
    $uploadMb = (int) ascb_env('ASCB_MAX_UPLOAD_MB', '25');
    if ($uploadMb < 1) $uploadMb = 25;
    if ($uploadMb > 250) $uploadMb = 250; // safety ceiling
    define('ASCB_MAX_UPLOAD_MB', $uploadMb);
}

if (ASCB_DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
}
