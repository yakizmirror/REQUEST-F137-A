<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — DATABASE CONNECTION (PDO)
   ---------------------------------------------------------
   Environment overrides supported:
     ASCB_DB_HOST, ASCB_DB_PORT, ASCB_DB_NAME,
     ASCB_DB_USER, ASCB_DB_PASS

   Local XAMPP fallback remains localhost/root/no password so
   the existing development setup continues to work.
   ========================================================= */

require_once __DIR__ . '/app.php';

/* For XAMPP/client installs that do not use server environment
   variables, copy local.php.example to local.php and edit it. */
$ascbLocalDb = array();
if (is_file(__DIR__ . '/local.php')) {
    $loaded = require __DIR__ . '/local.php';
    if (is_array($loaded)) $ascbLocalDb = $loaded;
}

if (!defined('DB_HOST')) define('DB_HOST', isset($ascbLocalDb['host']) ? $ascbLocalDb['host'] : ascb_env('ASCB_DB_HOST', 'localhost'));
if (!defined('DB_PORT')) define('DB_PORT', isset($ascbLocalDb['port']) ? $ascbLocalDb['port'] : ascb_env('ASCB_DB_PORT', '3306'));
if (!defined('DB_NAME')) define('DB_NAME', isset($ascbLocalDb['name']) ? $ascbLocalDb['name'] : ascb_env('ASCB_DB_NAME', 'ascb_registrar'));
if (!defined('DB_USER')) define('DB_USER', isset($ascbLocalDb['user']) ? $ascbLocalDb['user'] : ascb_env('ASCB_DB_USER', 'root'));
if (!defined('DB_PASS')) define('DB_PASS', isset($ascbLocalDb['pass']) ? $ascbLocalDb['pass'] : ascb_env('ASCB_DB_PASS', ''));

$pdo = null;

try {
    $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME . ';charset=utf8mb4';
    $pdo = new PDO(
        $dsn,
        DB_USER,
        DB_PASS,
        array(
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_TIMEOUT            => 5,
        )
    );

    /* Keep database timestamps/date rendering aligned with the
       registrar's configured timezone even if the server is UTC. */
    $pdo->exec("SET time_zone = '+08:00'");

    require_once __DIR__ . '/../includes/schema_upgrade.php';
    ascb_ensure_department_schema($pdo);
} catch (Exception $e) {
    error_log('ASCB database connection failed: ' . $e->getMessage());

    if (defined('ASCB_DB_OPTIONAL') && ASCB_DB_OPTIONAL) {
        $pdo = null;
    } else {
        http_response_code(500);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><html><head><meta charset="utf-8"><title>Database unavailable</title></head><body>';
        echo '<h2>Database connection unavailable</h2>';
        echo '<p>Hindi makakonekta ang Registrar System sa database. Paki-check ang database service at deployment configuration.</p>';
        if (ASCB_DEBUG) {
            echo '<pre>' . htmlspecialchars($e->getMessage(), ENT_QUOTES, 'UTF-8') . '</pre>';
        }
        echo '</body></html>';
        exit;
    }
}
