<?php
/* AUTH GUARD (server-side): redirects to index.php before any
   HTML is sent if there's no valid session — this replaces the
   old client-side ascbGuardPage() approach. */
require_once __DIR__ . '/includes/auth_check.php';
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/permissions.php';
require_once __DIR__ . '/includes/programs_helper.php';

$ascbSchools = $pdo->query("SELECT id, name, address FROM schools ORDER BY name")->fetchAll();
$ascbCourses = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
$ascbPermissions = ascb_permissions_for(ascb_get($ascbUser, 'role', ''));

/* Course / Program options — dapat tugma sa `programNames` sa
   script.js (parehong key), pinagmumulan ng dropdown ng Course
   sa Enrollment panel. */
$ascbProgramOptions = array(
    ''             => 'Select Program',
    'BSCS'         => 'Bachelor of Science in Computer Science (BSCS)',
    'BSIS'         => 'Bachelor of Science in Information Systems (BSIS)',
    'BSIT'         => 'Bachelor of Science in Information Technology (BSIT)',
    'BSCRIM'       => 'Bachelor of Science in Criminology (BS Crim)',
    'BSA'          => 'Bachelor of Science in Accountancy (BSA)',
    'BSBA-FM'      => 'BSBA - Financial Management',
    'BSBA-HRDM'    => 'BSBA - Human Resource Development Management',
    'BSBA-MM'      => 'BSBA - Marketing Management',
    'BEED'         => 'Bachelor of Elementary Education (BEED)',
    'BSED-ENGLISH' => 'BSED - English',
    'BSED-MATH'    => 'BSED - Mathematics',
    'BSED-SOCIAL'  => 'BSED - Social Studies',
);

/* Mga BAGONG Course/Program na idinagdag ng admin (Admin ->
   Programs & Subjects) — mula sa `programs`/`program_subjects`
   tables. Isinasama agad sa dropdown (fresh page load) at sa
   structuredPrograms/programNames ng JS (para sa Enrollment
   subject-loading), kaya "callable" agad sa Enrollment ang
   bagong idinagdag na course/major/subject/trimester/semester. */
$ascbProgramOptions = $ascbProgramOptions + ascb_program_dropdown_options($pdo);
$ascbCustomProgramsData = ascb_build_structured_programs($pdo);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" type="image/png" href="ASCB_LOGO.png">
    <title>OFFICE OF THE REGISTRAR</title>

    <script src="auth.js"></script>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700;800&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="style.css">

    <!-- Apply saved theme before first paint, so there's no
         light-mode flash when Dark Mode is on. -->
    <script>
        (function () {
            var t = localStorage.getItem("ascbTheme") === "dark" ? "dark" : "light";
            document.documentElement.setAttribute("data-theme", t);
        })();
    </script>
</head>

<body>

<div class="app-shell" id="appShell">

    <!-- =====================================================
         MOBILE TOP BAR (shown only on small screens)
    ====================================================== -->
    <div class="mobile-topbar">
        <button type="button" class="mobile-menu-btn" onclick="ascbToggleSidebar()" aria-label="Open menu">☰</button>
        <img src="ASCB_LOGO.png" class="mobile-topbar-logo" alt="ASCB Logo">
        <span class="mobile-topbar-title">ASCB Registrar</span>
    </div>

    <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="ascbToggleSidebar(false)"></div>


    <!-- =====================================================
         LEFT NAVIGATION SIDEBAR
    ====================================================== -->
    <aside class="main-sidebar" id="mainSidebar">

        <div class="main-sidebar-brand">
            <img src="asc-badge.png" class="main-sidebar-logo" alt="ASCB Logo">
            <h5>OFFICE OF THE REGISTRAR</h5>
        </div>

        <nav class="main-sidebar-nav">

            <div class="main-sidebar-label">Menu</div>

            <button type="button" class="main-nav-link active" id="navDashboard" data-view="dashboard" onclick="ascbNavigate('dashboard'); ascbLoadDashboardStats();">
                <span class="main-nav-icon">🏠</span>
                Dashboard
            </button>

            <button type="button" class="main-nav-link" id="navEnrollment" data-view="enrollment" onclick="ascbNavigate('enrollment'); ascbLoadEnrollment();">
                <span class="main-nav-icon">📝</span>
                Enrollment
            </button>

            <button type="button" class="main-nav-link" id="navNewTerm" data-view="newterm" onclick="ascbNavigate('newterm'); ascbLoadEnrollment();">
                <span class="main-nav-icon">🗂</span>
                New Term
            </button>

            <button type="button" class="main-nav-link" id="navCertificates" data-view="certificates" onclick="ascbNavigate('certificates')">
                <span class="main-nav-icon">📃</span>
                Certificates
            </button>

            <button type="button" class="main-nav-link" id="navGradeManagement" data-view="grademanagement" onclick="ascbNavigate('grademanagement'); ascbLoadGradeManagement();">
                <span class="main-nav-icon">✏️</span>
                Grade Management
            </button>

            <button type="button" class="main-nav-link" id="navGradeEvaluation" data-view="gradeevaluation" onclick="ascbNavigate('gradeevaluation'); ascbLoadGradeEvaluation();">
                <span class="main-nav-icon">🎓</span>
                Grade Evaluation
            </button>

            <button type="button" class="main-nav-link" id="navForm137" data-view="form137" onclick="ascbNavigate('form137')">
                <span class="main-nav-icon">📄</span>
                Form 137-A
            </button>

            <button type="button" class="main-nav-link" id="navRecords" data-view="records" onclick="ascbNavigate('records'); ascbLoadRecords();">
                <span class="main-nav-icon">🗂</span>
                History
            </button>

            <button type="button" class="main-nav-link" id="navReleasing" data-view="releasing" onclick="ascbNavigate('releasing'); ascbLoadDocuments();">
                <span class="main-nav-icon">📦</span>
                Releasing &amp; Receiving
            </button>

            <button type="button" class="main-nav-link" id="navApprovedSO" data-view="approvedso" onclick="ascbNavigate('approvedso'); ascbLoadApprovedSO();">
                <span class="main-nav-icon">✅</span>
                Approved SO
            </button>

            <button type="button" class="main-nav-link" id="navCourseFiles" data-view="coursefiles" onclick="ascbNavigate('coursefiles'); ascbLoadCourseFiles();">
                <span class="main-nav-icon">📊</span>
                FORM 9
            </button>

            <button type="button" class="main-nav-link" id="navRejected" data-view="rejected" onclick="ascbNavigate('rejected'); ascbLoadRejectedStudents();">
                <span class="main-nav-icon">🚫</span>
                Rejected Students
            </button>

            <div class="main-sidebar-label">System</div>

            <button type="button" class="main-nav-link" id="navArchive" data-view="archive" onclick="ascbNavigate('archive'); ascbLoadArchive();">
                <span class="main-nav-icon">🗄</span>
                Archive
            </button>

            <button type="button" class="main-nav-link" id="navAdmin" data-view="admin" onclick="ascbNavigate('admin'); ascbAdminOpen();">
                <span class="main-nav-icon">⚙</span>
                Settings
            </button>

        </nav>

        <div class="main-sidebar-footer">

            <div class="main-sidebar-user">
                <div class="main-sidebar-user-avatar" id="ascbUserAvatar"><?php echo htmlspecialchars(ascb_first_initial($ascbUser['displayName']), ENT_QUOTES, 'UTF-8'); ?></div>
                <div class="main-sidebar-user-info">
                    <span class="main-sidebar-user-name" id="ascbCurrentUserName"><?php echo htmlspecialchars($ascbUser['displayName']); ?></span>
                    <span class="main-sidebar-user-role" id="ascbCurrentUserRole"><?php echo htmlspecialchars($ascbUser['role']); ?></span>
                </div>
            </div>

            <button type="button" class="main-sidebar-logout" onclick="ascbConfirmLogout()" title="Sign out">
                <span class="main-nav-icon">⎋</span>
                Logout
            </button>

            <button type="button" class="theme-quick-toggle" data-theme-quick-toggle onclick="ascbToggleTheme()" title="Toggle dark mode">
                <span class="theme-quick-toggle-icon">🌙</span> Dark Mode
            </button>

        </div>

    </aside>


    <!-- =====================================================
         APP MAIN
    ====================================================== -->
    <main class="app-main">

        <!-- =================================================
             DASHBOARD VIEW
        ================================================== -->
        <section class="app-view active-view" id="dashboardView">

            <div class="dashboard-welcome">
                <h2>WELCOME BACK<span id="dashboardUserName">, <?php echo htmlspecialchars($ascbUser['displayName']); ?></span>!</h2>
                <p>Here's a quick overview of the Office of the Registrar.</p>
            </div>

            <!-- =============================================
                 ENROLLMENT OVERVIEW — Total Enrolled, Male/Female,
                 saka breakdown kada Course/Program. Ino-fetch mula
                 sa api/dashboard_stats.php (tingnan ang
                 ascbLoadDashboardStats() sa script.js).
            ============================================== -->
            <div class="dashboard-stats" id="dashboardStats">

                <div class="dashboard-stats-header">
                    <h3>Enrollment Overview</h3>
                    <div class="dashboard-stats-header-actions">
                        <select id="dashboardTrimesterFilter" onchange="ascbLoadDashboardStats()" title="I-filter ayon sa Trimester">
                            <option value="">All Trimesters</option>
                            <option value="1st Trimester">1st Trimester</option>
                            <option value="2nd Trimester">2nd Trimester</option>
                            <option value="3rd Trimester">3rd Trimester</option>
                        </select>
                        <button type="button" class="btn btn-outline" onclick="ascbLoadDashboardStats()" title="Refresh">⟳ Refresh</button>
                        <button type="button" class="btn btn-outline" onclick="ascbExportDashboardReport()" title="I-export bilang Excel">📊 Report</button>
                    </div>
                </div>

                <div class="records-status" id="dashboardStatsStatus">Loading…</div>

                <div class="dashboard-stats-cards" id="dashboardStatsCards" style="display:none;">
                    <div class="dashboard-stat-card dashboard-stat-total">
                        <span class="dashboard-stat-label">TOTAL ENROLLED</span>
                        <span class="dashboard-stat-value" id="dashboardStatTotal">0</span>
                    </div>
                    <div class="dashboard-stat-card dashboard-stat-male">
                        <span class="dashboard-stat-label">MALE</span>
                        <span class="dashboard-stat-value" id="dashboardStatMale">0</span>
                    </div>
                    <div class="dashboard-stat-card dashboard-stat-female">
                        <span class="dashboard-stat-label">FEMALE</span>
                        <span class="dashboard-stat-value" id="dashboardStatFemale">0</span>
                    </div>
                </div>

                <div class="dashboard-course-stats" id="dashboardCourseStats" style="display:none;"></div>

            </div>

            <div class="dashboard-grid">

                <button type="button" class="dashboard-action-card" onclick="ascbNavigate('enrollment'); ascbLoadEnrollment();">
                    <span class="dashboard-action-icon">📝</span>
                    <div>
                        <h3>Enroll a Student</h3>
                        <p>Add a new enrollee's Surname, Given Name, Middle Name, Birth Date, Address, and Previous School.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

                <button type="button" class="dashboard-action-card" onclick="ascbNavigate('certificates')">
                    <span class="dashboard-action-icon">📃</span>
                    <div>
                        <h3>Generate Certificate</h3>
                        <p>Create a Certificate of Enrollment, Registration, or Grade Evaluation for a student.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

                <button type="button" class="dashboard-action-card" onclick="ascbNavigate('form137')">
                    <span class="dashboard-action-icon">📄</span>
                    <div>
                        <h3>Request Form 137-A</h3>
                        <p>Prepare a transfer of credentials request letter for a receiving school.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

                <button type="button" class="dashboard-action-card" onclick="ascbNavigate('gradeevaluation'); ascbLoadGradeEvaluation();">
                    <span class="dashboard-action-icon">🎓</span>
                    <div>
                        <h3>Grade Evaluation</h3>
                        <p>Pick a student and see every subject and grade from all of their enrollment records in one place.</p>
                    </div>
                    <span class="dashboard-action-arrow">→</span>
                </button>

            </div>

        </section>


        <!-- =================================================
             CERTIFICATES VIEW
        ================================================== -->
        <section class="app-view" id="certificatesView">

            <!-- =============================================
                 ACTIONS PANEL (collapsible)
            ============================================== -->
            <div class="actions-panel" id="actionsPanel">

                <button type="button" class="actions-panel-toggle" onclick="ascbToggleActionsPanel()">
                    <span class="actions-panel-toggle-label">
                        <span class="app-nav-icon">⚙</span>
                        Actions
                    </span>
                    <span class="actions-panel-chevron" id="actionsPanelChevron">▾</span>
                </button>

                <div class="actions-panel-body" id="actionsPanelBody">

                    <div class="certificate-type-selector">
                        <label for="certificateType" class="actions-inline-label">Certificate Type</label>
                        <select id="certificateType" onchange="changeCertificateType()">

                            <option value="ENROLLMENT">CERTIFICATE OF ENROLLMENT</option>

                            <option value="REGISTRATION">CERTIFICATE OF REGISTRATION</option>

                            <option value="GRADE_EVALUATION">GRADE EVALUATION</option>

                        </select>
                    </div>

                    <button
                        type="button"
                        class="app-nav-btn app-nav-btn-primary"
                        onclick="generateCertificate()"
                    >
                        <span class="app-nav-icon">✔</span>
                        SUBMIT DATA
                    </button>

                    <button
                        type="button"
                        class="app-nav-btn"
                        onclick="clearForm()"
                    >
                        <span class="app-nav-icon">↺</span>
                        CLEAR DATA
                    </button>

                </div>

            </div>

        <!-- STUDENT INFORMATION -->
        <section class="card">

            <div class="card-title">

                <div>
                    <h2>STUDENT INFORMATION</h2>
                    <p>
                        Enter the student's enrollment details.
                    </p>
                </div>

            </div>


            <div class="form-grid">

                <!-- STUDENT NAME -->
                <div class="form-group">

                    <label for="studentName">
                        Student Name
                    </label>

                    <input
                        type="text"
                        id="studentName"
                        placeholder="LAST NAME, FIRST NAME M.I."
                    >

                </div>


                <!-- STUDENT ID -->
                <div class="form-group">

                    <label for="studentId">
                        Student ID
                    </label>

                    <input
                        type="text"
                        id="studentId"
                        placeholder="Student ID Number"
                    >

                </div>


                <!-- PROGRAM -->
                <div class="form-group">

                    <label for="program">
                        Course / Program
                    </label>

                    <select id="program" onchange="loadSubjects()">

                        <option value="">
                            Select Program
                        </option>

                        <option value="BSCS">
                            Bachelor of Science in Computer Science (BSCS)
                        </option>

                        <option value="BSIS">
                            Bachelor of Science in Information Systems (BSIS)
                        </option>

                        <option value="BSIT">
                            Bachelor of Science in Information Technology (BSIT)
                        </option>

                        <option value="BSCRIM">
                            Bachelor of Science in Criminology (BS Crim)
                        </option>

                        <option value="BSA">
                            Bachelor of Science in Accountancy (BSA)
                        </option>

                        <option value="BSBA-FM">
                            BSBA - Financial Management
                        </option>

                        <option value="BSBA-HRDM">
                            BSBA - Human Resource Development Management
                        </option>

                        <option value="BSBA-MM">
                            BSBA - Marketing Management
                        </option>

                        <option value="BEED">
                            Bachelor of Elementary Education (BEED)
                        </option>

                        <option value="BSED-ENGLISH">
                            BSED - English
                        </option>

                        <option value="BSED-MATH">
                            BSED - Mathematics
                        </option>

                        <option value="BSED-SOCIAL">
                            BSED - Social Studies
                        </option>

                    </select>

                </div>


                <!-- YEAR -->
                <div class="form-group">

                    <label for="yearLevel">
                        Year Level
                    </label>

                    <select id="yearLevel">

                        <option value="">
                            Select Year Level
                        </option>

                        <option>
                            1st Year
                        </option>

                        <option>
                            2nd Year
                        </option>

                        <option>
                            3rd Year
                        </option>

                        <option>
                            4th Year
                        </option>

                    </select>

                </div>


                <!-- TRIMESTER -->
                <div class="form-group">

                    <label for="trimester">
                       Trimester
                    </label>

                    <select id="trimester">

                        <option value="">
                            Select Trimester
                        </option>

                        <option>
                            1st Trimester
                        </option>

                        <option>
                            2nd Trimester
                        </option>

                        <option>
                            3rd Trimester
                        </option>

                    </select>

                </div>


                <!-- ACADEMIC YEAR -->
                <div class="form-group">

                    <label for="academicYear">
                        Academic Year
                    </label>

                    <input
                        type="text"
                        id="academicYear"
                        placeholder="2026–2027"
                    >

                </div>


                <!-- DATE OF ENROLLMENT -->
                <div class="form-group">

                    <label for="enrollmentDate">
                        Date of Enrollment
                    </label>

                    <input
                        type="date"
                        id="enrollmentDate"
                    >

                </div>


                <!-- STATUS -->
                <div class="form-group">

                    <label for="status">
                        Enrollment Status
                    </label>

                    <select id="status">

                        <option>
                            OFFICIALLY ENROLLED
                        </option>

                        <option>
                            FOR VALIDATION
                        </option>

                    </select>

                </div>


                <!-- OR NUMBER -->
                <div class="form-group">

                    <label for="orNumber">
                        O.R. Number
                    </label>

                    <input
                        type="text"
                        id="orNumber"
                        placeholder="Official Receipt No."
                    >

                </div>


                <!-- PREPARED BY (hidden — auto-credited to the
                     logged-in user; see ascbInitPreparedBy()) -->
                <input type="hidden" id="preparedBy" value="<?php echo htmlspecialchars(ascb_get($ascbUser, 'preparedBy', '')); ?>">

            </div>

        </section>


        <!-- =================================================
             SUBJECTS
        ================================================== -->
        <section class="card">

            <div class="subjects-header">

                <div class="subjects-header-text">

                    <h2>
                        SUBJECTS
                    </h2>

                    <p>
                        Load subjects from the prospectus, or add them yourself. Grades are entered separately in Grade Management.
                    </p>

                </div>

                <div class="subjects-header-actions">

                    <button
                        type="button"
                        class="btn btn-outline"
                        onclick="addSubjectsForTerm()"
                    >
                        <span class="btn-icon">⬇</span> Load Subjects for Term
                    </button>

                    <button
                        type="button"
                        class="btn btn-add"
                        onclick="addSubjectRow()"
                    >
                        <span class="btn-icon">+</span> Add Subject
                    </button>

                </div>

            </div>


            <div class="table-wrapper">

                <table class="subject-input-table">

                        <thead>
                            <tr>

                                <th width="25%">
                                    Course Code
                                </th>

                                <th width="40%">
                                    Course Description
                                </th>

                                <th width="13%">
                                    Grade
                                </th>

                                <th width="10%">
                                    Units
                                </th>

                                <th width="7%">
                                    Action
                                </th>

                            </tr>
                        </thead>


                        <tbody id="subjectRows">
                            <!-- JavaScript generated rows -->
                        </tbody>


                        <tfoot>
                            <tr>

                                <td
                                    colspan="3"
                                    class="total-label"
                                >
                                    TOTAL UNITS
                                </td>

                                <td
                                    id="totalUnitsInput"
                                    class="total-value"
                                >
                                    0
                                </td>

                                <td></td>

                            </tr>

                            <tr id="gwaInputRow">

                                <td
                                    colspan="3"
                                    class="total-label"
                                >
                                    GENERAL WEIGHTED AVERAGE (GWA)
                                </td>

                                <td
                                    id="gwaValueInput"
                                    class="total-value"
                                >
                                    0.00
                                </td>

                                <td></td>

                            </tr>
                        </tfoot>

                    </table>

            </div>

        </section>
        </section>


        <!-- =================================================
             FORM 137 VIEW
             Functions the same way as Certificates: a normal
             in-page view reached from the sidebar, with a
             collapsible actions panel and stacked form cards.
             Generating opens a print-ready preview modal.
        ================================================== -->
        <section class="app-view" id="form137View">

            <!-- =============================================
                 ACTIONS PANEL (collapsible)
            ============================================== -->
            <div class="actions-panel" id="f137ActionsPanel">

                <button type="button" class="actions-panel-toggle" onclick="ascbToggleF137ActionsPanel()">
                    <span class="actions-panel-toggle-label">
                        <span class="app-nav-icon">⚙</span>
                        Actions
                    </span>
                    <span class="actions-panel-chevron" id="f137ActionsPanelChevron">▾</span>
                </button>

                <div class="actions-panel-body" id="f137ActionsPanelBody">

                    <div class="f137-view-intro">
                        <h2>Request Form 137-A</h2>
                        <p>Prepare a transfer-of-credentials request letter for a receiving school.</p>
                    </div>

                    <button
                        type="button"
                        class="app-nav-btn app-nav-btn-primary"
                        onclick="generateForm137()"
                    >
                        <span class="app-nav-icon">✔</span>
                        SUBMIT DATA
                    </button>

                    <button
                        type="button"
                        class="app-nav-btn"
                        onclick="clearForm137()"
                    >
                        <span class="app-nav-icon">↺</span>
                        CLEAR DATA
                    </button>

                </div>

            </div>

            <!-- STUDENT INFORMATION -->
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">👤</span>
                    <div>
                        <h3>Student Information</h3>
                        <p>Add one or more students for this request.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field f137-span-2">
                        <label for="f137_studentName">Student Name</label>
                        <input id="f137_studentName" type="text" placeholder="Last Name, First Name, Middle Name">
                    </div>

                    <div class="f137-field">
                        <label for="f137_courseSelect">Admitted To / Course</label>
                        <div class="f137-inline">
                            <select id="f137_courseSelect"></select>
                            <button type="button" class="f137-plus" onclick="openF137CourseDialog()">+</button>
                        </div>
                    </div>

                    <div class="f137-field">
                        <label for="f137_schoolYear">Last School Year Attended</label>
                        <input id="f137_schoolYear" type="text" placeholder="e.g. 2023-2024">
                    </div>

                    <div class="f137-field">
                        <label for="f137_yearSection">Year &amp; Section</label>
                        <input id="f137_yearSection" type="text" placeholder="e.g. XII-HUMSS B">
                    </div>
                </div>

                <button type="button" class="f137-add-student" onclick="addF137Student()">
                    + Add Student to This Request
                </button>

                <div class="f137-students-list" id="f137_studentsList"></div>
            </section>

            <!-- RECEIVING SCHOOL -->
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">🏫</span>
                    <div>
                        <h3>Receiving School</h3>
                        <p>One recipient per request letter.</p>
                    </div>
                </div>

                <div class="f137-field">
                    <label for="f137_schoolSelect">Previous / Last School Attended</label>
                    <div class="f137-inline">
                        <select id="f137_schoolSelect"></select>
                        <button type="button" class="f137-plus" onclick="openF137SchoolDialog()">+</button>
                    </div>
                    <small>Double-click a saved school to remove it.</small>
                </div>

                <div class="f137-field">
                    <label for="f137_schoolAddress">School Address</label>
                    <input id="f137_schoolAddress" type="text" placeholder="School address">
                </div>
            </section>

            <!-- REQUEST DETAILS -->
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">✍</span>
                    <div>
                        <h3>Request Details</h3>
                        <p>Select the applicable request options.</p>
                    </div>
                </div>

                <div class="f137-check-grid">
                    <label><input type="checkbox" id="f137_firstRequest"> <span>1st Request</span></label>
                    <label><input type="checkbox" id="f137_secondRequest"> <span>2nd Request</span></label>
                    <label><input type="checkbox" id="f137_urgentRequest"> <span>Urgent</span></label>
                    <label><input type="checkbox" id="f137_bearerRequest"> <span>Entrust to Bearer</span></label>
                    <label class="f137-span-2"><input type="checkbox" id="f137_copyForASCB"> <span>Indicate: Copy for <strong>Andres Soriano Colleges of Bislig, Inc.</strong></span></label>
                </div>

                <div class="f137-field">
                    <label for="f137_requestDate">Date</label>
                    <input id="f137_requestDate" type="date">
                </div>
            </section>

        </section>


        <!-- =================================================
             RECORDS VIEW
             Nagpapakita ng mga naka-log na Certificates at
             Form 137-A requests mula sa database (api/records.php).
        ================================================== -->
        <section class="app-view" id="recordsView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Records</h3>
                        <p>Lahat ng na-log na Certificates at Form 137-A Requests</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-tabs">
                        <button type="button" class="records-tab active" id="recordsTabCertificates" onclick="ascbRecordsSwitchTab('certificates')">
                            📃 Certificates
                        </button>
                        <button type="button" class="records-tab" id="recordsTabForm137" onclick="ascbRecordsSwitchTab('form137')">
                            📄 Form 137-A
                        </button>
                    </div>

                    <div class="records-search">
                        <input type="text" id="recordsSearchInput" placeholder="Search student, OR #, school..." oninput="ascbRecordsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadRecords()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="recordsStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="recordsTableWrapper" style="display:none;">
                    <table class="records-table" id="recordsTable">
                        <thead id="recordsTableHead"></thead>
                        <tbody id="recordsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="recordsPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             RELEASING & RECEIVING VIEW
             Log ng mga papasok/palabas na dokumento, may PDF
             attachment/s bawat entry (api/documents.php).
        ================================================== -->
        <section class="app-view" id="releasingView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">📦</span>
                    <div>
                        <h3>Releasing &amp; Receiving of Documents</h3>
                        <p>DATABASE PARA SA MGA RECEIVING DOCUMENTS</p>
                    </div>
                </div>

                <div class="f137-form-grid">

                    <div class="f137-field">
                        <label for="docs_direction">Type</label>
                        <select id="docs_direction">
                            <option value="RELEASED">RELEASED</option>
                            <option value="RECEIVED">RECEIVED</option>
                        </select>
                    </div>

                    <div class="f137-field">
                        <label for="docs_documentName">Document Name / Description</label>
                        <input id="docs_documentName" type="text" placeholder="e.g. Form 137, TOR, Diploma">
                    </div>

                    <div class="f137-field">
                        <label for="docs_partyName" id="docs_partyNameLabel">Released To</label>
                        <input id="docs_partyName" type="text" placeholder="FULLNAME">
                    </div>

                    <div class="f137-field">
                        <label for="docs_date">Date</label>
                        <input id="docs_date" type="date">
                    </div>

                    <div class="f137-field f137-span-2">
                        <label for="docs_remarks">Remarks (optional)</label>
                        <input id="docs_remarks" type="text" placeholder="Karagdagang detalye">
                    </div>

                    <div class="f137-field f137-span-2">
                        <label for="docs_files">Attach PDF file/s</label>
                        <input id="docs_files" type="file" accept="application/pdf" multiple>
                    </div>

                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbDocsSubmit()">
                    <span class="app-nav-icon">✔</span>
                    SAVE ENTRY
                </button>

                <div class="records-status" id="docsFormStatus" style="display:none;"></div>

            </section>

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Logs</h3>
                        <p>Releasing and Receiving Credentials</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-tabs">
                        <button type="button" class="records-tab active" id="docsTabAll" onclick="ascbDocsSwitchTab('')">All</button>
                        <button type="button" class="records-tab" id="docsTabReleased" onclick="ascbDocsSwitchTab('RELEASED')">Released</button>
                        <button type="button" class="records-tab" id="docsTabReceived" onclick="ascbDocsSwitchTab('RECEIVED')">Received</button>
                    </div>

                    <div class="records-search">
                        <input type="text" id="docsSearchInput" placeholder="Search document, party..." oninput="ascbDocsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadDocuments()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="docsStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="docsTableWrapper" style="display:none;">
                    <table class="records-table" id="docsTable">
                        <thead>
                            <tr>
                                <th>Date Submitted</th>
                                <th>Type</th>
                                <th>Document</th>
                                <th>Released To / Received From</th>
                                <th>Files</th>
                                <th>Handled By</th>
                                <th>Remarks</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="docsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="docsPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             ENROLLMENT VIEW
             Basic student info bawat entry (api/enrollment.php).
             Add / Edit / Delete.
        ================================================== -->
        <section class="app-view" id="enrollmentView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">📝</span>
                    <div>
                        <h3>Enroll a Student</h3>
                        <p>I-lagay ang basic info ng estudyante.</p>
                    </div>
                </div>

                <div class="f137-form-grid">

                    <div class="f137-mini-divider f137-span-2" style="border-top:none;padding-top:0;">Personal Information</div>

                    <div class="f137-field">
                        <label for="enroll_surname">Surname</label>
                        <input id="enroll_surname" type="text" placeholder="e.g. Dela Cruz">
                    </div>

                    <div class="f137-field">
                        <label for="enroll_firstName">Given Name</label>
                        <input id="enroll_firstName" type="text" placeholder="e.g. Juan">
                    </div>

                    <div class="f137-field">
                        <label for="enroll_middleName">Middle Name</label>
                        <input id="enroll_middleName" type="text" placeholder="e.g. Santos">
                    </div>

                    <div class="f137-field">
                        <label for="enroll_sex">Sex</label>
                        <select id="enroll_sex">
                            <option value="">Select Sex</option>
                            <option value="Male">Male</option>
                            <option value="Female">Female</option>
                        </select>
                    </div>

                    <div class="f137-field">
                        <label for="enroll_studentType">Student Type</label>
                        <select id="enroll_studentType">
                            <option value="">Select Student Type</option>
                            <option value="Regular">Regular</option>
                            <option value="Transferee">Transferee</option>
                            <option value="Irregular">Irregular</option>
                        </select>
                    </div>

                    <div class="f137-field">
                        <label for="enroll_birthDate">Birth Date</label>
                        <input id="enroll_birthDate" type="date">
                    </div>

                    <div class="f137-mini-divider f137-span-2">Contact &amp; Educational Background</div>

                    <div class="f137-field f137-span-2">
                        <label for="enroll_address">Address</label>
                        <input id="enroll_address" type="text" placeholder="e.g. Purok 1, Mangagoy, Bislig City">
                    </div>

                    <div class="f137-field">
                        <label for="enroll_mobileNumber">Mobile Number</label>
                        <input id="enroll_mobileNumber" type="text" placeholder="e.g. 09171234567" maxlength="20">
                    </div>

                    <div class="f137-field f137-span-2">
                        <label for="enroll_prevSchoolJuniorHs">Previous School — Junior High School</label>
                        <input id="enroll_prevSchoolJuniorHs" type="text" placeholder="e.g. Bislig City National High School">
                    </div>

                    <div class="f137-field f137-span-2">
                        <label for="enroll_prevSchoolSeniorHs">Previous School — Senior High School</label>
                        <input id="enroll_prevSchoolSeniorHs" type="text" placeholder="e.g. Stand Alone Senior High School">
                    </div>

                    <div class="f137-mini-divider f137-span-2">Program &amp; Enrollment Details</div>

                    <div class="f137-field f137-span-2">
                        <label for="enroll_program">Course / Program</label>
                        <select id="enroll_program" onchange="ascbEnrollProgramChanged()">
                            <?php foreach ($ascbProgramOptions as $code => $label): ?>
                            <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($label); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="f137-field">
                        <label for="enroll_major">Major</label>
                        <input id="enroll_major" type="text" placeholder="Automatic" readonly>
                        <small>Auto-fills kapag may major ang napiling course.</small>
                    </div>

                    <div class="f137-field">
                        <label for="enroll_yearLevel">Year Level</label>
                        <select id="enroll_yearLevel">
                            <option value="">Select Year Level</option>
                            <option>1st Year</option>
                            <option>2nd Year</option>
                            <option>3rd Year</option>
                            <option>4th Year</option>
                        </select>
                    </div>

                    <div class="f137-field">
                        <label for="enroll_trimester">Trimester</label>
                        <select id="enroll_trimester">
                            <option value="">Select Trimester</option>
                            <option>1st Trimester</option>
                            <option>2nd Trimester</option>
                            <option>3rd Trimester</option>
                        </select>
                    </div>

                        <div class="f137-field">
                            <label for="enroll_schoolYear">School Year</label>
                            <input 
                                id="enroll_schoolYear" 
                                type="text" 
                                placeholder="e.g. 2025-2026"
                                maxlength="9"
                                inputmode="numeric"
                                pattern="[0-9]{4}-[0-9]{4}"
                                oninput="
                                    this.value = this.value
                                        .replace(/[^0-9]/g, '')
                                        .replace(/^(\d{4})(\d)/, '$1-$2');
                                "
                            >
                            <small>Format: YYYY-YYYY</small>
                        </div>


                </div>


                <div class="subjects-header">

                    <div class="subjects-header-text">
                        <h3>Subjects</h3>
                        <p style="margin:0;">Load subjects from the prospectus, o idagdag mo mismo. <strong>Grades are entered in Grade Management.</strong></p>
                    </div>

                    <div class="subjects-header-actions">
                        <button type="button" class="btn btn-outline" onclick="ascbEnrollAddSubjectsForTerm('enroll_subjectRows', 'enroll_program', 'enroll_yearLevel', 'enroll_trimester')">
                            <span class="btn-icon">⬇</span> Load Subjects for Term
                        </button>
                        <button type="button" class="btn btn-add" onclick="ascbEnrollAddSubjectRow('enroll_subjectRows')">
                            <span class="btn-icon">+</span> Add Subject
                        </button>
                    </div>

                </div>

                <div class="table-wrapper">
                    <table class="subject-input-table">
                        <thead>
                            <tr>
                                <th width="22%">Course Code</th>
                                <th width="38%">Course Description</th>
                                <th width="15%">Units</th>
                                <th width="25%">Action</th>
                            </tr>
                        </thead>
                        <tbody id="enroll_subjectRows"></tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" class="total-label">Total Units</td>
                                <td id="enroll_totalUnitsInput" colspan="3"></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbEnrollSubmit()" style="margin-top:16px;">
                    <span class="app-nav-icon">✔</span>
                    Save Enrollee
                </button>

                <div class="records-status" id="enrollFormStatus" style="display:none;"></div>

            </section>

        </section>


        <!-- =================================================
             NEW TERM VIEW
             Listahan ng mga naka-enroll na estudyante (dating
             nasa loob ng ENROLLMENT VIEW). Ginawa itong bukod
             na tab/view para hiwalay sa "Enroll a Student" form.
             Parehong data at functions pa rin ang ginagamit
             (api/enrollment.php, ascbLoadEnrollment(), atbp.) —
             inilipat lang ang section papunta rito.
        ================================================== -->
        <section class="app-view" id="newtermView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Enrollees</h3>
                        <p>Listahan ng mga naka-enroll na estudyante.</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="text" id="enrollSearchInput" placeholder="Search name, previous school, mobile number..." oninput="ascbEnrollFilter()">
                        <select id="enrollStatusFilterInput" onchange="ascbEnrollFilter()" title="I-filter ayon sa Approval Status">
                            <option value="">Lahat ng Status</option>
                            <option value="pending">Pending</option>
                            <option value="approved">Enrolled</option>
                        </select>
                        <button type="button" class="btn btn-secondary" id="enrollViewAllBtn" onclick="ascbEnrollToggleViewAll()" title="Ipakita lahat ng records (walang pagination)">View All</button>
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadEnrollment()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="enrollStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="enrollTableWrapper" style="display:none;">
                    <table class="records-table" id="enrollTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>Year &amp; Trimester</th>
                                <th>Approval Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="enrollTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="enrollPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             REJECTED STUDENTS VIEW
             Listahan ng mga enrollee na "rejected" ang status
             (hindi pa naka-archive). Hindi na lumalabas ang mga
             ito sa Enrollment / New Term list o sa Grade
             Evaluation habang nandito pa sila. "Delete" dito ay
             nag-a-archive lang (tingnan ang Archive menu sa
             ibaba), hindi tuluyang binubura sa database.
        ================================================== -->
        <section class="app-view" id="rejectedView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🚫</span>
                    <div>
                        <h3>Rejected Students</h3>
                        <p>Student Not Qualified</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="text" id="rejectedSearchInput" placeholder="Search name, course, student ID..." oninput="ascbRejectedFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadRejectedStudents()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="rejectedStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="rejectedTableWrapper" style="display:none;">
                    <table class="records-table" id="rejectedTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>School Year</th>
                                <th>Reason / Rejected By</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="rejectedTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="rejectedPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             ARCHIVE VIEW
             Listahan ng mga enrollee na na-archive na (dating
             "Delete" mula sa Enrollment / New Term / Rejected
             Students) — hal. mga estudyanteng nag-drop. Hindi
             sila tuluyang nabubura sa database dito, "Restore"
             lang ang ibinabalik sa normal na listahan. "Delete
             Permanently" lang dito ang tunay na tumatanggal sa
             database.
        ================================================== -->
        <section class="app-view" id="archiveView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗄</span>
                    <div>
                        <h3>Archive</h3>
                        <p>Mga estudyanteng nag-drop o tinanggal sa listahan — nandito pa rin sila sa database, "Restore" lang para ibalik.</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="text" id="archiveSearchInput" placeholder="Search name, course, student ID..." oninput="ascbArchiveFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadArchive()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="archiveStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="archiveTableWrapper" style="display:none;">
                    <table class="records-table" id="archiveTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>Archived On</th>
                                <th>Archived By / Reason</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="archiveTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="archivePagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             GRADE MANAGEMENT VIEW
        ================================================== -->
        <section class="app-view" id="grademanagementView">
            <section class="f137-card">
                <div class="f137-section-title">
                    <span class="f137-icon">✏️</span>
                    <div>
                        <h3>Grade Management</h3>
                        <p>Mag-input at mag-update ng grades dito. Hindi binabago ng grade update ang enrollment approval status.</p>
                    </div>
                </div>
                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="text" id="gradeMgmtSearchInput" placeholder="Search student name or Student ID..." oninput="ascbGradeManagementFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadGradeManagement()">⟳ Refresh</button>
                    </div>
                </div>
                <div class="records-status" id="gradeMgmtStatus">Loading students…</div>
                <div class="table-wrapper records-table-wrapper" id="gradeMgmtWrapper" style="display:none;">
                    <table class="records-table">
                        <thead><tr><th>Student ID</th><th>Name</th><th>Course</th><th>Latest Term</th><th>Terms</th><th>Actions</th></tr></thead>
                        <tbody id="gradeMgmtBody"></tbody>
                    </table>
                </div>
                <div class="pagination-bar" id="gradeMgmtPagination"></div>
            </section>
        </section>

        <!-- =================================================
             GRADE EVALUATION VIEW
             Read-only report na pinagsasama-sama ang LAHAT ng
             subjects/grades ng isang estudyante mula sa lahat
             ng kanyang naka-log na Enrollment records (lahat ng
             School Year / Year Level / Trimester), gamit ang
             data mula sa api/grades.php. Read-only report ito;
             ang grade entry at updates ay ginagawa sa Grade Management.
        ================================================== -->
        <section class="app-view" id="gradeevaluationView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🎓</span>
                    <div>
                        <h3>Grade Evaluation</h3>
                        <p>Piliin ang estudyante para makita ang lahat ng subjects at grades niya mula sa bawat enrollment record.</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="text" id="gradeEvalSearchInput" placeholder="Search student name..." oninput="ascbGradeEvalFilterStudents()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadGradeEvaluation()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="gradeEvalListStatus">Loading students…</div>

                <div class="table-wrapper records-table-wrapper" id="gradeEvalListWrapper" style="display:none;">
                    <table class="records-table" id="gradeEvalStudentTable">
                        <thead>
                            <tr>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Course</th>
                                <th>Major</th>
                                <th>Enrollment Records</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="gradeEvalStudentTableBody"></tbody>
                    </table>
                </div>

                <div class="pagination-bar" id="gradeEvalPagination"></div>

            </section>

        </section>


        <!-- =================================================
             APPROVED SO VIEW
             Pangalan + PDF file bawat entry (api/approved_so.php).
             Add / Edit (palitan ang pangalan at/o PDF) / Delete.
        ================================================== -->
        <section class="app-view" id="approvedsoView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">✅</span>
                    <div>
                        <h3>Upload Approved Special Order</h3>
                        <p>I-upload ang pangalan at PDF file ng bawat approved SO.</p>
                    </div>
                </div>

                <div class="f137-form-grid">

                    <div class="f137-field f137-span-2">
                        <label for="so_name">Name</label>
                        <input id="so_name" type="text" placeholder="e.g. Juan Dela Cruz">
                    </div>

                    <div class="f137-field f137-span-2">
                        <label for="so_file">Attach PDF file</label>
                        <input id="so_file" type="file" accept="application/pdf">
                    </div>

                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbSoSubmit()">
                    <span class="app-nav-icon">✔</span>
                    SAVE ENTRY
                </button>

                <div class="records-status" id="soFormStatus" style="display:none;"></div>

            </section>

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Approved Special Order</h3>
                        <p>Only Approved S.O. 2023-Present</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="text" id="soSearchInput" placeholder="Search name..." oninput="ascbSoFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadApprovedSO()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="soStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="soTableWrapper" style="display:none;">
                    <table class="records-table" id="soTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>File</th>
                                <th>Uploaded By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="soTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="soPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             COURSE FILES VIEW
             Pangalan + Course + isang Excel file bawat entry
             (api/course_files.php). Pwedeng i-upload (create) at
             i-delete lang — SINADYANG WALA nang "Update/Replace
             file" dito, para hindi na mababago ang laman ng
             na-upload na Excel kailanman; download at delete
             na lang ang pwede pagkatapos i-upload.
        ================================================== -->
        <section class="app-view" id="coursefilesView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">📊</span>
                    <div>
                        <h3>Upload FORM 9</h3>
                        <p>I-upload ang pangalan, course, at Excel file (.xlsx / .xls / .csv). Hindi na ito mababago pagkatapos i-save — download o delete na lang ang pwede.</p>
                    </div>
                </div>

                <div class="f137-form-grid">

                    <div class="f137-field">
                        <label for="cf_name">Name</label>
                        <input id="cf_name" type="text" placeholder="e.g. Juan Dela Cruz">
                    </div>

                    <div class="f137-field">
                        <label for="cf_course">Course</label>
                        <select id="cf_course"></select>
                    </div>

                    <div class="f137-field f137-span-2">
                        <label for="cf_file">Attach Excel file (.xlsx / .xls / .csv)</label>
                        <input id="cf_file" type="file" accept=".xlsx,.xls,.csv">
                    </div>

                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbCfSubmit()">
                    <span class="app-nav-icon">✔</span>
                    SAVE ENTRY
                </button>

                <div class="records-status" id="cfFormStatus" style="display:none;"></div>

            </section>

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Course Files</h3>
                        <p>Listahan ng mga na-upload na Excel file kada estudyante/course.</p>
                    </div>
                </div>

                <div class="records-toolbar">

                    <div class="records-search">
                        <input type="text" id="cfSearchInput" placeholder="Search name or course..." oninput="ascbCfFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadCourseFiles()" title="Refresh">⟳ Refresh</button>
                    </div>

                </div>

                <div class="records-status" id="cfStatus">Loading records…</div>

                <div class="table-wrapper records-table-wrapper" id="cfTableWrapper" style="display:none;">
                    <table class="records-table" id="cfTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Course</th>
                                <th>File</th>
                                <th>Uploaded By</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="cfTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="cfPagination"></div>
                </div>

            </section>

        </section>


        <!-- =================================================
             ADMIN VIEW
             Lahat ng naka-login ay may access dito, pero
             magkaiba ang kayang gawin bawat role — tingnan ang
             includes/permissions.php. Kung ano ang kaya ng
             kasalukuyang user, sinasabi ito ng $ascbPermissions
             (PHP) / ASCB_PERMISSIONS (JS).
        ================================================== -->
        <section class="app-view" id="adminView">

            <section class="f137-card">

                <div class="f137-section-title">
                    <span class="f137-icon">⚙</span>
                    <div>
                        <h3>Admin</h3>
                        <p>User accounts, Schools &amp; Courses, at Activity Log ng system.</p>
                    </div>
                </div>

                <div class="records-tabs" id="adminTabs">
                    <button type="button" class="records-tab active" id="adminTabAccount" onclick="ascbAdminSwitchTab('account')">
                        👤 My Account
                    </button>
                    <button type="button" class="records-tab" id="adminTabAppearance" onclick="ascbAdminSwitchTab('appearance')">
                        🎨 Appearance
                    </button>
                    <button type="button" class="records-tab" id="adminTabUsers" onclick="ascbAdminSwitchTab('users')">
                        🧑‍💼 Users
                    </button>
                    <button type="button" class="records-tab" id="adminTabLookups" onclick="ascbAdminSwitchTab('lookups')">
                        🏫 Schools &amp; Courses
                    </button>
                    <button type="button" class="records-tab" id="adminTabDepartments" onclick="ascbAdminSwitchTab('departments')">
                        🏢 Departments &amp; Backup
                    </button>
                    <button type="button" class="records-tab" id="adminTabPrograms" onclick="ascbAdminSwitchTab('programs')">
                        📚 Programs &amp; Subjects
                    </button>
                    <button type="button" class="records-tab" id="adminTabLog" onclick="ascbAdminSwitchTab('log')">
                        🗂 Activity Log
                    </button>
                </div>

            </section>

            <!-- ---------- MY ACCOUNT ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelAccount">

                <div class="f137-section-title">
                    <span class="f137-icon">👤</span>
                    <div>
                        <h3><?php echo htmlspecialchars($ascbUser['displayName']); ?></h3>
                        <p><?php echo htmlspecialchars($ascbUser['role']); ?></p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="acct_currentPassword">Current Password</label>
                        <input id="acct_currentPassword" type="password" autocomplete="current-password">
                    </div>
                    <div class="f137-field">
                        <label for="acct_newPassword">New Password</label>
                        <input id="acct_newPassword" type="password" autocomplete="new-password">
                    </div>
                    <div class="f137-field">
                        <label for="acct_confirmPassword">Confirm New Password</label>
                        <input id="acct_confirmPassword" type="password" autocomplete="new-password">
                    </div>
                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbChangeOwnPassword()">
                    <span class="app-nav-icon">✔</span>
                    CHANGE PASSWORD
                </button>

                <div class="records-status" id="acctStatus" style="display:none;"></div>

            </section>

            <!-- Duplicate marker removed -->
            <section class="f137-card admin-tab-panel" id="adminPanelAppearance" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🎨</span>
                    <div>
                        <h3>Appearance</h3>
                        <p>I-adjust kung paano itsura ang system para sa'yo.</p>
                    </div>
                </div>

                <div class="theme-switch">
                    <button
                        type="button"
                        class="theme-switch-track"
                        id="themeSwitchTrack"
                        data-theme-switch
                        role="switch"
                        aria-checked="false"
                        aria-label="Toggle dark mode"
                        onclick="ascbToggleTheme()"
                    >
                        <span class="theme-switch-thumb"></span>
                    </button>
                    <div class="theme-switch-labels">
                        <strong>Dark Mode</strong>
                        <span data-theme-status>Light mode is on.</span>
                    </div>
                </div>

                <p style="margin:12px 0 0;font-size:11px;color:var(--muted);">Naka-save ang setting na ito sa browser na ito, kaya kailangan mo itong i-on ulit kapag gumamit ka ng ibang device o browser.</p>

            </section>

            <!-- ---------- USERS (UNIT HEAD lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelUsers" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">➕</span>
                    <div>
                        <h3>Add Staff Account</h3>
                        <p>Gumawa ng bagong account para sa Office of the Registrar.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="user_displayName">Full Name</label>
                        <input id="user_displayName" type="text" placeholder="e.g. JUAN DELA CRUZ">
                    </div>
                    <div class="f137-field">
                        <label for="user_role">Role</label>
                        <select id="user_role">
                            <option value="ADMIN STAFF">ADMIN STAFF</option>
                            <option value="SCHOOL REGISTRAR">SCHOOL REGISTRAR</option>
                            <option value="UNIT HEAD">UNIT HEAD</option>
                            <option value="DEAN">DEAN</option>
                        </select>
                    </div>
                    <div class="f137-field">
                        <label for="user_departmentId">Department (required for DEAN)</label>
                        <select id="user_departmentId"><option value="">— Select Department —</option></select>
                    </div>
                    <div class="f137-field">
                        <label for="user_preparedByCode">"Prepared By" Code (optional)</label>
                        <input id="user_preparedByCode" type="text" placeholder="e.g. jdcruz">
                    </div>
                    <div class="f137-field">
                        <label for="user_username">Username</label>
                        <input id="user_username" type="text" value="admin">
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="user_password">Password</label>
                        <input id="user_password" type="password" placeholder="Hindi bababa sa 8 karakter">
                    </div>
                </div>

                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbUserAdd()">
                    <span class="app-nav-icon">✔</span>
                    ADD ACCOUNT
                </button>

                <div class="records-status" id="userFormStatus" style="display:none;"></div>

            </section>

            <section class="f137-card admin-tab-panel" id="adminPanelUsersList" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🧑‍💼</span>
                    <div>
                        <h3>Staff Accounts</h3>
                        <p>Lahat ng account sa Office of the Registrar.</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="text" id="userSearchInput" placeholder="Search name, role..." oninput="ascbUsersFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadUsers()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="usersStatus">Loading accounts…</div>

                <div class="table-wrapper records-table-wrapper" id="usersTableWrapper" style="display:none;">
                    <table class="records-table" id="usersTable">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Role</th>
                                <th>Department</th>
                                <th>Prepared By</th>
                                <th>Status</th>
                                <th>Date Added</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="usersTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="usersPagination"></div>
                </div>

            </section>

            <!-- ---------- SCHOOLS & COURSES (view: lahat; delete: may permission lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelLookups" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🏫</span>
                    <div>
                        <h3>Schools</h3>
                        <p>Listahan ng schools sa Form 137-A dropdown.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="admLookup_schoolName">School Name</label>
                        <input id="admLookup_schoolName" type="text" placeholder="School name">
                    </div>
                    <div class="f137-field">
                        <label for="admLookup_schoolAddress">Address (optional)</label>
                        <input id="admLookup_schoolAddress" type="text" placeholder="Address">
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbAdminAddSchool()">
                    <span class="app-nav-icon">✔</span>
                    ADD SCHOOL
                </button>
                <div class="records-status" id="admSchoolFormStatus" style="display:none;"></div>

                <div class="records-toolbar" style="margin-top:20px;">
                    <div class="records-search">
                        <input type="text" id="admSchoolSearchInput" placeholder="Search school..." oninput="ascbAdminSchoolsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbAdminLoadSchools()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="admSchoolsStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="admSchoolsTableWrapper" style="display:none;">
                    <table class="records-table" id="admSchoolsTable">
                        <thead>
                            <tr>
                                <th>School Name</th>
                                <th>Address</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admSchoolsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="admSchoolsPagination"></div>
                </div>

            </section>

            <section class="f137-card admin-tab-panel" id="adminPanelLookupsCourses" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🎓</span>
                    <div>
                        <h3>Courses</h3>
                        <p>Listahan ng courses sa Form 137-A dropdown.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field f137-span-2">
                        <label for="admLookup_courseName">Course Name</label>
                        <input id="admLookup_courseName" type="text" placeholder="e.g. BSIT">
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbAdminAddCourse()">
                    <span class="app-nav-icon">✔</span>
                    ADD COURSE
                </button>
                <div class="records-status" id="admCourseFormStatus" style="display:none;"></div>

                <div class="records-toolbar" style="margin-top:20px;">
                    <div class="records-search">
                        <input type="text" id="admCourseSearchInput" placeholder="Search course..." oninput="ascbAdminCoursesFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbAdminLoadCourses()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="admCoursesStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="admCoursesTableWrapper" style="display:none;">
                    <table class="records-table" id="admCoursesTable">
                        <thead>
                            <tr>
                                <th>Course Name</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admCoursesTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="admCoursesPagination"></div>
                </div>

            </section>


            <!-- ---------- DEPARTMENTS / DEAN EXPORT / FULL BACKUP ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelDepartments" style="display:none;">
                <div class="f137-section-title"><span class="f137-icon">🏢</span><div><h3>Departments &amp; Dean Data Distribution</h3><p>I-group ang Programs per Department, mag-assign ng Dean account, at mag-export ng Department student data para sa Dean.</p></div></div>
                <div class="f137-form-grid" id="deptManageForm">
                    <div class="f137-field"><label for="dept_code">Department Code</label><input id="dept_code" type="text" placeholder="e.g. CBE"></div>
                    <div class="f137-field"><label for="dept_name">Department Name</label><input id="dept_name" type="text" placeholder="e.g. College of Business Education"></div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" id="deptAddBtn" onclick="ascbDepartmentAdd()"><span class="app-nav-icon">✔</span> ADD DEPARTMENT</button>
                <div class="records-status" id="deptStatus" style="display:none;"></div>

                <div class="f137-section-title" style="margin-top:24px;"><span class="f137-icon">🔗</span><div><h3>Assign Existing Programs / Courses to Department</h3><p>I-assign ang mga existing Program/Course na dati nang ginawa pero walang Department. Hindi buburahin ang enrollment records.</p></div></div>
                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="deptAssign_department">Target Department</label>
                        <select id="deptAssign_department" onchange="ascbLoadDepartmentAssignablePrograms()"><option value="">— Select Department —</option></select>
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="deptAssign_search">Search Program / Course</label>
                        <input id="deptAssign_search" type="text" placeholder="e.g. BSIT, Bachelor of Science..." oninput="ascbRenderDepartmentAssignablePrograms()">
                    </div>
                </div>
                <div class="records-status" id="deptAssignStatus" style="display:none;"></div>
                <div class="table-wrapper records-table-wrapper" id="deptAssignTableWrapper" style="display:none; margin-top:12px;">
                    <table class="records-table">
                        <thead><tr><th style="width:7%;">Select</th><th>Course Code</th><th>Course / Program</th><th>Major</th><th>Current Department</th></tr></thead>
                        <tbody id="deptAssignTableBody"></tbody>
                    </table>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" id="deptAssignBtn" onclick="ascbAssignSelectedPrograms()" style="margin-top:10px; display:none;"><span class="app-nav-icon">🔗</span> ASSIGN SELECTED PROGRAMS</button>
                <button type="button" class="btn btn-outline" id="deptAssignSelectAllBtn" onclick="ascbToggleDepartmentAssignablePrograms(true)" style="margin:10px 0 0 8px; display:none;">Select All Visible</button>
                <button type="button" class="btn btn-outline" id="deptAssignClearBtn" onclick="ascbToggleDepartmentAssignablePrograms(false)" style="margin:10px 0 0 8px; display:none;">Clear Visible</button>
                <div class="table-wrapper records-table-wrapper" style="margin-top:16px;"><table class="records-table"><thead><tr><th>Code</th><th>Department</th><th>Programs</th><th>Active Deans</th><th>Status</th><th>Actions</th></tr></thead><tbody id="deptTableBody"></tbody></table></div>
                <hr style="margin:24px 0; opacity:.25;">
                <div class="f137-section-title"><span class="f137-icon">📊</span><div><h3>Department Excel Export</h3><p>Excel-compatible student/enrollment/subject/grade data. DEAN accounts can export only their assigned Department.</p></div></div>
                <div class="f137-form-grid">
                    <div class="f137-field"><label for="deptExport_department">Department</label><select id="deptExport_department"><option value="">— Select Department —</option></select></div>
                    <div class="f137-field"><label for="deptExport_sy">School Year (optional)</label><input id="deptExport_sy" type="text" placeholder="e.g. 2026-2027"></div>
                    <div class="f137-field"><label for="deptExport_term">Term (optional)</label><select id="deptExport_term"><option value="">All Terms</option><option>1st Trimester</option><option>2nd Trimester</option><option>3rd Trimester</option><option>1st Semester</option><option>2nd Semester</option></select></div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbDepartmentExport()"><span class="app-nav-icon">⬇</span> EXPORT EXCEL</button>
                <button type="button" class="btn btn-outline" id="fullSqlBackupBtn" onclick="ascbFullSqlBackup()" style="margin-left:8px;">Full SQL Backup</button>
            </section>

            <!-- ---------- PROGRAMS & SUBJECTS (view: lahat; delete: may permission lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelPrograms" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">📚</span>
                    <div>
                        <h3>Add Course / Program</h3>
                        <p>Idagdag ang bagong Course, Major (kung meron), at kung Trimester o Semester ang term system nito. Awtomatiko itong lalabas sa Course dropdown ng Enrollment.</p>
                    </div>
                </div>

                <div class="f137-form-grid">
                    <div class="f137-field">
                        <label for="admProg_departmentId">Department</label>
                        <select id="admProg_departmentId"><option value="">— Select Department —</option></select>
                    </div>
                    <div class="f137-field">
                        <label for="admProg_code">Course Code</label>
                        <input id="admProg_code" type="text" placeholder="e.g. BSHM">
                    </div>
                    <div class="f137-field">
                        <label for="admProg_termType">Term System</label>
                        <select id="admProg_termType">
                            <option value="Trimester">Trimester</option>
                            <option value="Semester">Semester</option>
                        </select>
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="admProg_courseName">Course Name</label>
                        <input id="admProg_courseName" type="text" placeholder="e.g. Bachelor of Science in Hospitality Management">
                    </div>
                    <div class="f137-field f137-span-2">
                        <label for="admProg_major">Major (optional)</label>
                        <input id="admProg_major" type="text" placeholder="e.g. Financial Management — iwan blangko kung walang major">
                    </div>
                </div>
                <button type="button" class="app-nav-btn app-nav-btn-primary" onclick="ascbAdminAddProgram()">
                    <span class="app-nav-icon">✔</span>
                    ADD PROGRAM
                </button>
                <div class="records-status" id="admProgFormStatus" style="display:none;"></div>

                <div class="records-toolbar" style="margin-top:20px;">
                    <div class="records-search">
                        <input type="text" id="admProgSearchInput" placeholder="Search course, major..." oninput="ascbAdminProgramsFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbAdminLoadPrograms()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="admProgsStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="admProgsTableWrapper" style="display:none;">
                    <table class="records-table" id="admProgsTable">
                        <thead>
                            <tr>
                                <th>Department</th>
                                <th>Course Code</th>
                                <th>Course Name</th>
                                <th>Major</th>
                                <th>Term System</th>
                                <th>Subjects</th>
                                <th>Status</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody id="admProgsTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="admProgsPagination"></div>
                </div>

            </section>

            <!-- ---------- ACTIVITY LOG (UNIT HEAD / SCHOOL REGISTRAR lang) ---------- -->
            <section class="f137-card admin-tab-panel" id="adminPanelLog" style="display:none;">

                <div class="f137-section-title">
                    <span class="f137-icon">🗂</span>
                    <div>
                        <h3>Activity Log</h3>
                        <p>History ng mga pangyayari sa buong system.</p>
                    </div>
                </div>

                <div class="records-toolbar">
                    <div class="records-search">
                        <input type="text" id="logSearchInput" placeholder="Search name, action..." oninput="ascbActivityLogFilter()">
                        <button type="button" class="btn btn-secondary" onclick="ascbLoadActivityLog()" title="Refresh">⟳ Refresh</button>
                    </div>
                </div>

                <div class="records-status" id="logStatus">Loading…</div>

                <div class="table-wrapper records-table-wrapper" id="logTableWrapper" style="display:none;">
                    <table class="records-table" id="logTable">
                        <thead>
                            <tr>
                                <th>Date/Time</th>
                                <th>User</th>
                                <th>Role</th>
                                <th>Action</th>
                                <th>Details</th>
                            </tr>
                        </thead>
                        <tbody id="logTableBody"></tbody>
                    </table>
                    <div class="pagination-bar" id="logPagination"></div>
                </div>

            </section>

            <section class="f137-card admin-tab-panel" id="adminPanelNoAccess" style="display:none;">
                <div class="records-empty" style="padding: 30px 0;">Wala kang access sa section na ito.</div>
            </section>

        </section>

    </main>

</div>



<!-- =========================================================
     CERTIFICATE MODAL
========================================================== -->

<div
    class="modal"
    id="certificateModal"
>

    <div
        class="modal-overlay"
        onclick="closeCertificate()"
    ></div>


    <div class="modal-window">


        <!-- MODAL TOOLBAR -->
        <div class="modal-toolbar">

            <div>

                <strong>
                    Certificate Preview
                </strong>

                <span>
                    Ready for printing
                </span>

            </div>


            <div class="toolbar-buttons">

                <button
                    type="button"
                    class="btn btn-secondary"
                    onclick="closeCertificate()"
                >
                    Close
                </button>

                <button
                    type="button"
                    class="btn btn-primary"
                    onclick="printCertificate()"
                >
                    Print Certificate
                </button>

            </div>

        </div>



        <!-- =================================================
             SCROLLABLE PREVIEW WRAPPER
             (keeps the fixed 8.5x11in sheet fully viewable
             and scrollable inside the modal, on any screen)
        ================================================== -->

        <div class="modal-print-scroll">

        <!-- =================================================
             PRINT AREA
             LETTER / SHORT BOND
             8.5 x 11 INCHES
        ================================================== -->

        <div
            class="print-area"
            id="printArea"
        >


            <!-- =================================================
                 OFFICIAL HEADER
                 LOGO + SCHOOL NAME + ADDRESS + OFFICE + EMAIL
            ================================================== -->

            <div class="document-header">

                <img
                    src="Header_ASCB.png"
                    class="letterhead-banner"
                    alt="Andres Soriano Colleges of Bislig, Inc."
                >

                <div class="header-subtitle">

                    <p class="header-office">
                        Office of the Registrar
                    </p>

                    <p class="header-email">
                        collegeregistrar.ascb@gmail.com &nbsp;|&nbsp; (086) 853-2306 (PhilCom)
                    </p>

                </div>

            </div>



            <!-- =================================================
                 CENTER WATERMARK
                 IMPORTANT:
                 Actual IMG instead of CSS background
            ================================================== -->

            <div
                class="watermark-container"
                aria-hidden="true"
            >

                <img
                    src="ASCB_LOGO.png"
                    class="document-watermark"
                    alt=""
                >

            </div>



            <!-- =================================================
                 DOCUMENT CONTENT
            ================================================== -->

            <div class="document-content">


                <!-- TITLE -->

                <h1 class="certificate-title" id="previewCertificateTitle">
                    CERTIFICATE OF ENROLLMENT
                </h1>



                <!-- INTRODUCTION -->

                <p class="certificate-intro" id="certificateIntro">

                        This is to certify that

                        <strong id="previewStudentName">
                            ______________________________
                        </strong>

                        is officially enrolled at

                        <strong>
                            Andres Soriano Colleges of Bislig, Inc.
                        </strong>

                        in the

                        <strong id="previewProgram">
                            ______________________________
                        </strong>

                        program for the

                        <strong id="previewTrimester">
                            ______________________________
                        </strong>,

                        <strong>Academic Year</strong>

                        <strong id="previewAcademicYear">
                            ____________
                        </strong>.

                    </p>



                <!-- SUMMARY -->

                <p class="summary-title">

                    <span id="summaryTitleText">Below is the Summary of the Student's Enrollment:</span>

                </p>



                <!-- =================================================
                     STUDENT DETAILS
                ================================================== -->

                <div class="student-details">


                    <div class="detail-row">

                        <span class="detail-label">
                            Student Name
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewName2"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Student ID
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewStudentId"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Course / Program
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewCourse"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Year Level
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewYearLevel"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row">

                        <span class="detail-label">
                            Semester / Trimester
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewTerm"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row" id="detailRowEnrollmentDate">

                        <span class="detail-label">
                            Date of Enrollment
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <span
                            id="previewEnrollmentDate"
                            class="detail-value"
                        ></span>

                    </div>



                    <div class="detail-row" id="detailRowStatus">

                        <span class="detail-label">
                            Status
                        </span>

                        <span class="colon">
                            :
                        </span>

                        <strong
                            id="previewStatus"
                            class="detail-value status-text"
                        ></strong>

                    </div>


                </div>



                <!-- =================================================
                     SUBJECT TABLE
                ================================================== -->

                <table class="certificate-table">


                    <thead>

                        <tr id="certTableHeadRow">

                            <th class="code-column">
                                Course Code
                            </th>

                            <th>
                                Course Description
                            </th>

                            <th class="units-column">
                                Units
                            </th>

                        </tr>

                    </thead>


                    <tbody id="previewSubjects">

                        <!-- JavaScript -->

                    </tbody>


                    <tfoot>

                        <tr>

                            <td colspan="2" class="cert-total-label" id="certTotalLabelCell">
                                TOTAL UNITS
                            </td>

                            <td id="previewTotalUnits">
                                0
                            </td>

                        </tr>

                        <tr id="certGwaRow" style="display: none;">

                            <td colspan="2" class="cert-total-label" id="certGwaLabelCell">
                                GENERAL WEIGHTED AVERAGE (GWA)
                            </td>

                            <td id="previewGWA">
                                0.00
                            </td>

                        </tr>

                    </tfoot>


                </table>



                <!-- =================================================
                     CERTIFICATION
                ================================================== -->

                <div class="certification-text" id="certificationTextBlock">

                    <h2 id="certificationTextContent">

                        This certification is issued upon the request
                        of the student for whatever lawful purpose it
                        may serve.

                    </h2>

                </div>

                <div class="Issued" id="issuedDateBlock">
                <h2>

                        Issued this

                        <span id="previewIssuedDate">
                            ____________________
                        </span>

                        at Andres Soriano Colleges of Bislig, Inc.,
                        Mangagoy, Bislig City, Surigao del Sur.

                </h2>
                </div>



                <!-- =================================================
                     SIGNATURE
                ================================================== -->

                <div class="signature-area">


                    <div class="signature-box">





                        <div class="signature-space">
                            &nbsp;
                        </div>


                        <div class="signature-line">

                            REBECCA P. CAPONONG, MAEd

                        </div>


                        <div class="signature-position">

                            School Registrar

                        </div>


                    </div>


                </div>



            </div>



            <!-- =================================================
                 SCHOOL SEAL NOTICE
                 FIXED AT VERY BOTTOM LEFT
            ================================================== -->

            <div class="school-seal-warning">
                <strong>NOT VALID WITHOUT</strong>
                <strong><span>SCHOOL SEAL</span></strong>
            </div>


            <!-- =================================================
                 TRANSACTION NOTES
                 O.R. NUMBER + PREPARED BY
                 FIXED BELOW THE SCHOOL SEAL NOTICE
            ================================================== -->

            <div class="transaction-notes">

                <div class="transaction-row">
                    <span class="transaction-label">O.R. No.</span>
                    <span class="transaction-colon">:</span>
                    <span id="previewOrNumber" class="transaction-value">—</span>
                </div>

                <div class="transaction-row">
                    <span class="transaction-label">Prepared by</span>
                    <span class="transaction-colon">:</span>
                    <span id="previewPreparedBy" class="transaction-value">—</span>
                </div>

            </div>


        </div>

        </div>

    </div>

</div>



<!-- SCRIPT -->


<!-- =========================================================
     GRADE EVALUATION REPORT MODAL
     Binuksan pag ni-View sa Grade Evaluation student list.
     Maliit/centered modal (gaya ng ibang detail modals) na
     sakto lang sa laman/screen — hindi na full-screen — at may
     sarili siyang scroll kapag mahaba ang laman (maraming
     trimester/record). Nasa loob din ng parehong card ang
     pangalan at course/major (hindi na hiwalay sa toolbar).
========================================================== -->
<div class="f137-mini-modal" id="gradeManagementModal">
    <div class="f137-mini-card f137-mini-card-lg">
        <button type="button" class="f137-mini-close" onclick="ascbGradeManagementClose()">×</button>
        <div class="f137-section-title" style="margin-bottom:12px;">
            <span class="f137-icon">✏️</span>
            <div><h3 id="gradeMgmtModalName" style="margin:0;">Enter Grades</h3><p id="gradeMgmtModalSub" style="margin:2px 0 0;font-size:12.5px;color:var(--muted);">&nbsp;</p></div>
        </div>
        <div id="gradeMgmtTermTabs" class="grade-mgmt-term-tabs"></div>
        <div id="gradeMgmtEditorBody"></div>
        <div class="records-status" id="gradeMgmtSaveStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="gradeEvalReportModal">

    <div class="f137-mini-card f137-mini-card-lg grade-eval-report-card">

        <button type="button" class="f137-mini-close" onclick="ascbGradeEvalCloseReport()">×</button>

        <div class="f137-section-title" style="margin-bottom:4px;">
            <span class="f137-icon">📋</span>
            <div>
                <h3 id="gradeEvalReportName" style="margin:0;">Grade Evaluation</h3>
                <p id="gradeEvalReportSub" style="margin:2px 0 0; font-size:12.5px; color:var(--muted);">&nbsp;</p>
            </div>
        </div>

        <div id="gradeEvalReportBody"></div>

        <div class="subjects-header-actions" style="margin-top:6px; flex-wrap:wrap; align-items:flex-end; gap:10px;">
            <div class="f137-field" style="min-width:220px; margin:0;">
                <label for="gradeEvalTermSelect" style="font-size:12px;">Trimester na i-p-print (isa lang)</label>
                <select id="gradeEvalTermSelect"></select>
            </div>
            <button type="button" class="btn btn-outline" onclick="ascbGradeEvalPrintTerm()">
                <span class="btn-icon">🖶</span> Print Selected Trimester (Short Bond Paper)
            </button>
            <button type="button" class="btn btn-outline" onclick="ascbGradeEvalPrintAll()">
                <span class="btn-icon">🖶</span> Print All Trimesters (Long Bond Paper)
            </button>
        </div>

    </div>

</div>


<!-- =========================================================
     FORM 137 PREVIEW MODAL
     Opened by "Preview & Generate" once the form validates,
     the same way the Certificates view opens its preview.
========================================================= -->
<div class="modal" id="form137PreviewModal">

    <div class="modal-overlay" onclick="closeForm137Preview()"></div>

    <div class="modal-window">

        <div class="modal-toolbar">
            <div>
                <strong>Form 137-A Request Letter</strong>
                <span>Ready for printing</span>
            </div>

            <div class="toolbar-buttons">
                <button type="button" class="btn btn-secondary" onclick="closeForm137Preview()">Close</button>
                <button type="button" class="btn btn-primary" onclick="printForm137()">Print</button>
            </div>
        </div>

        <div class="modal-print-scroll">
            <article class="f137-paper" id="f137PrintArea">
                <div class="document-header">
                    <img src="Header_ASCB.png" class="letterhead-banner" alt="Andres Soriano Colleges of Bislig, Inc.">
                    <div class="header-subtitle">
                        <p class="header-office">Office of the Registrar</p>
                        <p class="header-email">collegeregistrar.ascb@gmail.com &nbsp;|&nbsp; (086) 853-2306 (PhilCom)</p>
                    </div>
                </div>

                <div class="f137-watermark">
                    <img src="ASCB_LOGO.png" alt="">
                </div>

                <div class="f137-paper-content">
                    <div class="f137-date" id="f137_previewDate"></div>

                    <div class="f137-recipient">
                        <strong>The Principal</strong>
                        <div id="f137_previewSchool">ANDRES SORIANO COLLEGES OF BISLIG, INC.</div>
                        <div id="f137_previewSchoolAddress">Mangagoy, Bislig City</div>
                    </div>

                    <div class="f137-salutation">Sir/Madam:</div>

                    <p class="f137-letter-text">
                        May I have the honor to request for the original copy of the
                        <strong>Form 137-A</strong> of the following student<span id="f137_pluralTag">s</span>
                        who <span id="f137_isAreTag">are</span> temporarily enrolled in this school
                        upon presentation of his/her Form-138 duly signed by the principal.
                    </p>

                    <table class="f137-student-table">
                        <thead>
                            <tr>
                                <th>NAME</th>
                                <th>ADMITTED TO</th>
                                <th>LAST SCHOOL YEAR<br>ATTENDED</th>
                                <th>YEAR &amp; SECTION</th>
                            </tr>
                        </thead>
                        <tbody id="f137_studentTableBody"></tbody>
                    </table>

                    <p class="f137-letter-text-we f137-request-paragraph">
                        We shall highly appreciate your kind consideration of this request
                        and the prompt release of the above-mentioned academic record<span id="f137_pluralTag2">s</span>.
                        <br><br>
                        Thank you very much for your continued cooperation and support.
                    </p>

                    <div class="f137-options">
                        <div><span id="f137_checkFirst" class="f137-print-check"></span> 1st Request</div>
                        <div><span id="f137_checkSecond" class="f137-print-check"></span> 2nd Request</div>
                        <div><span id="f137_checkUrgent" class="f137-print-check"></span> Urgent</div>
                        <div><span id="f137_checkBearer" class="f137-print-check"></span> Please entrust to the bearer</div>
                        <div class="f137-option-wide"><span id="f137_checkCopy" class="f137-print-check"></span> Indicate: Copy for <strong>Andres Soriano Colleges of Bislig, Inc.</strong></div>
                    </div>

                    <div class="f137-signature">
                        <div>Very truly yours,</div>
                        <div class="f137-signature-space"></div>
                        <strong style="text-decoration: underline; text-underline-offset: 2px;">
                            REBECCA P. CAPONONG, MAEd
                        </strong>
                        <span>School Registrar</span>
                    </div>

                    <div class="f137-seal-warning"><strong>NOT VALID WITHOUT</strong><br><strong>SCHOOL SEAL</strong></div>
                </div>
            </article>
        </div>
    </div>
</div>

<div class="f137-mini-modal" id="f137SchoolDialog">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="closeF137SchoolDialog()">×</button>
        <h3>Add School</h3>
        <input id="f137_newSchoolName" type="text" placeholder="School Name">
        <input id="f137_newSchoolAddress" type="text" placeholder="School Address">
        <button type="button" class="btn btn-primary" onclick="saveF137School()">Add School</button>
    </div>
</div>

<div class="f137-mini-modal" id="f137CourseDialog">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="closeF137CourseDialog()">×</button>
        <h3>Add Course</h3>
        <input id="f137_newCourseName" type="text" placeholder="e.g. BS Psychology">
        <button type="button" class="btn btn-primary" onclick="saveF137Course()">Add Course</button>
    </div>
</div>

<div class="f137-mini-modal" id="docsEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbDocsCloseEdit()">×</button>
        <h3>Edit Document Entry</h3>
        <input type="hidden" id="docs_edit_id">

        <label for="docs_edit_direction" class="actions-inline-label" style="display:block; margin-bottom:6px;">Type</label>
        <select id="docs_edit_direction" style="width:100%; margin-bottom:10px;">
            <option value="RELEASED">RELEASED</option>
            <option value="RECEIVED">RECEIVED</option>
        </select>

        <input id="docs_edit_documentName" type="text" placeholder="Document Name / Description" style="margin-bottom:10px;">
        <input id="docs_edit_partyName" type="text" placeholder="Released To / Received From" style="margin-bottom:10px;">
        <input id="docs_edit_date" type="date" style="margin-bottom:10px;">
        <input id="docs_edit_remarks" type="text" placeholder="Remarks (optional)" style="margin-bottom:10px;">

        <label class="actions-inline-label" style="display:block; margin-bottom:6px;">Current Files</label>
        <div id="docs_edit_filesList" style="margin-bottom:10px;"></div>

        <label for="docs_edit_files" class="actions-inline-label" style="display:block; margin-bottom:6px;">Add more PDF file/s (optional)</label>
        <input id="docs_edit_files" type="file" accept="application/pdf" multiple>

        <button type="button" class="btn btn-primary" onclick="ascbDocsSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="docsEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="enrollEditModal">
    <div class="f137-mini-card f137-mini-card-lg">
        <button type="button" class="f137-mini-close" onclick="ascbEnrollCloseEdit()">×</button>
        <h3>UPDATE INFORMATION</h3>
        <input type="hidden" id="enroll_edit_id">

        <div class="f137-mini-note">
            Student ID: <strong id="enroll_edit_studentIdDisplay">—</strong> (Permanent Student No.)
        </div>

        <div class="f137-mini-divider">Personal Info</div>
        <div class="f137-form-grid">

            <div class="f137-field">
                <label for="enroll_edit_surname">Surname</label>
                <input id="enroll_edit_surname" type="text" placeholder="e.g. Dela Cruz">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_firstName">Given Name</label>
                <input id="enroll_edit_firstName" type="text" placeholder="e.g. Juan">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_middleName">Middle Name</label>
                <input id="enroll_edit_middleName" type="text" placeholder="e.g. Santos">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_sex">Sex</label>
                <select id="enroll_edit_sex">
                    <option value="">Select Sex</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_studentType">Student Type</label>
                <select id="enroll_edit_studentType">
                    <option value="">Select Student Type</option>
                    <option value="Regular">Regular</option>
                    <option value="Transferee">Transferee</option>
                    <option value="Irregular">Irregular</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_birthDate">Birth Date</label>
                <input id="enroll_edit_birthDate" type="date">
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_address">Address</label>
                <input id="enroll_edit_address" type="text" placeholder="e.g. Purok 1, Mangagoy, Bislig City">
            </div>

            <div class="f137-field">
                <label for="enroll_edit_mobileNumber">Mobile Number</label>
                <input id="enroll_edit_mobileNumber" type="text" placeholder="e.g. 09171234567" maxlength="20">
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_prevSchoolJuniorHs">Previous School — Junior High School</label>
                <input id="enroll_edit_prevSchoolJuniorHs" type="text" placeholder="e.g. Bislig City National High School">
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_prevSchoolSeniorHs">Previous School — Senior High School</label>
                <input id="enroll_edit_prevSchoolSeniorHs" type="text" placeholder="e.g. Stand Alone Senior High School">
            </div>

        </div>

        <div class="f137-mini-divider">Academic Info (term na ito)</div>
        <div class="f137-form-grid">

            <div class="f137-field f137-span-2">
                <label for="enroll_edit_program">Course / Program</label>
                <select id="enroll_edit_program" onchange="ascbEnrollProgramChanged('enroll_edit_program', 'enroll_edit_major', 'enroll_edit_subjectRows', 'enroll_edit_trimester')">
                    <?php foreach ($ascbProgramOptions as $code => $label): ?>
                    <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_major">Major</label>
                <input id="enroll_edit_major" type="text" placeholder="Awtomatikong lalabas kung may major ang napiling kurso" readonly>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_yearLevel">Year Level</label>
                <select id="enroll_edit_yearLevel">
                    <option value="">Select Year Level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_trimester">Trimester</label>
                <select id="enroll_edit_trimester">
                    <option value="">Select Trimester</option>
                    <option>1st Trimester</option>
                    <option>2nd Trimester</option>
                    <option>3rd Trimester</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_edit_schoolYear">School Year</label>
                <input id="enroll_edit_schoolYear" type="text" placeholder="e.g. 2025-2026">
            </div>

        </div>

        <div class="subjects-header" style="margin-top:2px;">
            <div class="subjects-header-text">
                <h3 style="margin:0 0 4px;">SUBJECTS</h3>
                <p style="margin:0;">Load subjects from the prospectus, o idagdag mo mismo. <strong>Grades are entered in Grade Management.</strong></p>
            </div>
            <div class="subjects-header-actions">
                <button type="button" class="btn btn-outline" onclick="ascbEnrollAddSubjectsForTerm('enroll_edit_subjectRows', 'enroll_edit_program', 'enroll_edit_yearLevel', 'enroll_edit_trimester')">
                    <span class="btn-icon">⬇</span> Load Subjects for Term
                </button>
                <button type="button" class="btn btn-add" onclick="ascbEnrollAddSubjectRow('enroll_edit_subjectRows')">
                    <span class="btn-icon">+</span> Add Subject
                </button>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="subject-input-table">
                <thead>
                    <tr>
                        <th width="22%">Course Code</th>
                        <th width="33%">Course Description</th>
                        <th width="15%">Units</th>
                        <th width="25%">Action</th>
                    </tr>
                </thead>
                <tbody id="enroll_edit_subjectRows"></tbody>
            </table>
        </div>

        <button type="button" class="btn btn-primary" onclick="ascbEnrollSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="enrollEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="enrollNewTermModal">
    <div class="f137-mini-card f137-mini-card-lg">
        <button type="button" class="f137-mini-close" onclick="ascbEnrollCloseNewTerm()">×</button>
        <h3>New Term Enrollment</h3>
        <input type="hidden" id="enroll_newterm_sourceId">
        <input type="hidden" id="enroll_newterm_studentId">

        <div class="f137-mini-note">
            Student ID: <strong id="enroll_newterm_studentIdDisplay">—</strong>
        </div>

        <!-- Basic Info: hindi na ipinapakita/ine-edit dito — kinokopya
             lang mula sa napiling estudyante papunta sa hidden fields
             (nasa ascbEnrollOpenNewTerm sa script.js), para hindi
             magulo. Gamitin ang "Update" kung may itatama sa basic
             info ng estudyante. -->
        <div class="f137-mini-note">
            Student: <strong id="enroll_newterm_nameDisplay">—</strong>
        </div>
        <input type="hidden" id="enroll_newterm_surname">
        <input type="hidden" id="enroll_newterm_firstName">
        <input type="hidden" id="enroll_newterm_middleName">
        <input type="hidden" id="enroll_newterm_sex">
        <input type="hidden" id="enroll_newterm_birthDate">
        <input type="hidden" id="enroll_newterm_address">
        <input type="hidden" id="enroll_newterm_mobileNumber">
        <input type="hidden" id="enroll_newterm_prevSchoolJuniorHs">
        <input type="hidden" id="enroll_newterm_prevSchoolSeniorHs">

        <div class="f137-mini-divider">NEW TERM</div>

        <div class="f137-form-grid">

            <div class="f137-field">
                <label for="enroll_newterm_studentType">Student Type</label>
                <select id="enroll_newterm_studentType">
                    <option value="">Select Student Type</option>
                    <option value="Regular">Regular</option>
                    <option value="Transferee">Transferee</option>
                    <option value="Irregular">Irregular</option>
                </select>
            </div>

            <div class="f137-field f137-span-2">
                <label for="enroll_newterm_program">Course / Program</label>
                <select id="enroll_newterm_program" onchange="ascbEnrollProgramChanged('enroll_newterm_program', 'enroll_newterm_major', 'enroll_newterm_subjectRows', 'enroll_newterm_trimester')">
                    <?php foreach ($ascbProgramOptions as $code => $label): ?>
                    <option value="<?php echo htmlspecialchars($code); ?>"><?php echo htmlspecialchars($label); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_major">Major</label>
                <input id="enroll_newterm_major" type="text" placeholder="Awtomatikong lalabas kung may major ang napiling kurso" readonly>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_yearLevel">Year Level</label>
                <select id="enroll_newterm_yearLevel">
                    <option value="">Select Year Level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_trimester">Trimester</label>
                <select id="enroll_newterm_trimester">
                    <option value="">Select Trimester</option>
                    <option>1st Trimester</option>
                    <option>2nd Trimester</option>
                    <option>3rd Trimester</option>
                </select>
            </div>

            <div class="f137-field">
                <label for="enroll_newterm_schoolYear">School Year</label>
                <input id="enroll_newterm_schoolYear" type="text" placeholder="e.g. 2025-2026">
            </div>

        </div>

        <div class="subjects-header">
            <div class="subjects-header-text">
                <h3 style="margin:0 0 4px;">SUBJECTS</h3>
                <p style="margin:0;">Load subjects from the prospectus, o idagdag mo mismo. <strong>Grades are entered in Grade Management.</strong></p>
            </div>
            <div class="subjects-header-actions">
                <button type="button" class="btn btn-outline" onclick="ascbEnrollAddSubjectsForTerm('enroll_newterm_subjectRows', 'enroll_newterm_program', 'enroll_newterm_yearLevel', 'enroll_newterm_trimester')">
                    <span class="btn-icon">⬇</span> Load Subjects for Term
                </button>
                <button type="button" class="btn btn-add" onclick="ascbEnrollAddSubjectRow('enroll_newterm_subjectRows')">
                    <span class="btn-icon">+</span> Add Subject
                </button>
            </div>
        </div>

        <div class="table-wrapper">
            <table class="subject-input-table">
                <thead>
                    <tr>
                        <th width="22%">Course Code</th>
                        <th width="33%">Course Description</th>
                        <th width="15%">Units</th>
                        <th width="25%">Action</th>
                    </tr>
                </thead>
                <tbody id="enroll_newterm_subjectRows"></tbody>
            </table>
        </div>

        <button type="button" class="btn btn-primary" onclick="ascbEnrollSubmitNewTerm()" style="margin-top: 12px;">Save New Term</button>
        <div class="records-status" id="enrollNewTermStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="soEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbSoCloseEdit()">×</button>
        <h3>Edit Approved SO</h3>
        <input type="hidden" id="so_edit_id">
        <input id="so_edit_name" type="text" placeholder="Name">
        <label for="so_edit_file" class="actions-inline-label" style="display:block; margin: 10px 0 6px;">
            Replace PDF file (optional — iwan lang na blangko para panatilihin ang luma)
        </label>
        <input id="so_edit_file" type="file" accept="application/pdf">
        <button type="button" class="btn btn-primary" onclick="ascbSoSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="soEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="userEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbUserCloseEdit()">×</button>
        <h3>Edit Account</h3>
        <input type="hidden" id="user_edit_id">
        <input id="user_edit_displayName" type="text" placeholder="Full Name" style="margin-bottom:10px;">
        <select id="user_edit_role" style="margin-bottom:10px;">
            <option value="ADMIN STAFF">ADMIN STAFF</option>
            <option value="SCHOOL REGISTRAR">SCHOOL REGISTRAR</option>
            <option value="UNIT HEAD">UNIT HEAD</option>
            <option value="DEAN">DEAN</option>
        </select>
        <select id="user_edit_departmentId" style="margin-bottom:10px;"><option value="">— Department (DEAN) —</option></select>
        <input id="user_edit_preparedByCode" type="text" placeholder="Prepared By Code (optional)" style="margin-bottom:10px;">
        <input id="user_edit_username" type="text" placeholder="Username" style="margin-bottom:10px;">
        <label for="user_edit_password" class="actions-inline-label" style="display:block; margin: 10px 0 6px;">
            New Password (optional — iwan lang na blangko para panatilihin ang luma)
        </label>
        <input id="user_edit_password" type="password" placeholder="Bagong password">
        <button type="button" class="btn btn-primary" onclick="ascbUserSubmitEdit()" style="margin-top: 12px;">Save Changes</button>
        <div class="records-status" id="userEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="progEditModal">
    <div class="f137-mini-card">
        <button type="button" class="f137-mini-close" onclick="ascbAdminProgCloseEdit()">×</button>
        <h3>Edit Program</h3>
        <input type="hidden" id="admProg_edit_id">
        <label for="admProg_edit_departmentId" class="actions-inline-label" style="display:block; margin-bottom:4px;">Department</label>
        <select id="admProg_edit_departmentId" style="margin-bottom:10px;"><option value="">— Select Department —</option></select>
        <label for="admProg_edit_code" class="actions-inline-label" style="display:block; margin-bottom:4px;">Course Code</label>
        <input id="admProg_edit_code" type="text" placeholder="e.g. BSHM" style="margin-bottom:10px;">
        <label for="admProg_edit_courseName" class="actions-inline-label" style="display:block; margin-bottom:4px;">Course Name</label>
        <input id="admProg_edit_courseName" type="text" placeholder="Course Name" style="margin-bottom:10px;">
        <label for="admProg_edit_major" class="actions-inline-label" style="display:block; margin-bottom:4px;">Major (optional)</label>
        <input id="admProg_edit_major" type="text" placeholder="Major" style="margin-bottom:10px;">
        <label for="admProg_edit_termType" class="actions-inline-label" style="display:block; margin-bottom:4px;">Term System</label>
        <select id="admProg_edit_termType" style="margin-bottom:10px;">
            <option value="Trimester">Trimester</option>
            <option value="Semester">Semester</option>
        </select>
        <label class="actions-inline-label" style="display:flex; align-items:center; gap:8px; margin-bottom:10px;">
            <input type="checkbox" id="admProg_edit_isActive"> Active (lumalabas sa Enrollment dropdown)
        </label>
        <button type="button" class="btn btn-primary" onclick="ascbAdminProgSubmitEdit()" style="margin-top:4px;">Save Changes</button>
        <div class="records-status" id="admProgEditStatus" style="display:none;"></div>
    </div>
</div>

<div class="f137-mini-modal" id="progSubjectsModal">
    <div class="f137-mini-card records-detail-card">
        <button type="button" class="f137-mini-close" onclick="ascbAdminProgSubjClose()">×</button>
        <h3 id="progSubjModalTitle">Manage Subjects</h3>
        <p id="progSubjModalSubtitle" style="margin:-6px 0 14px; color:var(--f137-muted, #667085); font-size:.9rem;"></p>

        <div class="f137-form-grid">
            <div class="f137-field">
                <label for="admProgSubj_yearLevel">Year Level</label>
                <select id="admProgSubj_yearLevel">
                    <option value="">Select Year Level</option>
                    <option>1st Year</option>
                    <option>2nd Year</option>
                    <option>3rd Year</option>
                    <option>4th Year</option>
                </select>
            </div>
            <div class="f137-field">
                <label for="admProgSubj_termLabel" id="admProgSubj_termLabelLabel">Trimester</label>
                <select id="admProgSubj_termLabel"></select>
            </div>
            <div class="f137-field">
                <label for="admProgSubj_code">Subject Code</label>
                <input id="admProgSubj_code" type="text" placeholder="e.g. HM 101">
            </div>
            <div class="f137-field">
                <label for="admProgSubj_units">Units</label>
                <input id="admProgSubj_units" type="number" step="0.5" min="0" placeholder="3">
            </div>
            <div class="f137-field f137-span-2">
                <label for="admProgSubj_description">Subject Description</label>
                <input id="admProgSubj_description" type="text" placeholder="e.g. Introduction to Hospitality Management">
            </div>
        </div>
        <input type="hidden" id="admProgSubj_editId">
        <div style="display:flex; gap:10px; flex-wrap:wrap;">
            <button type="button" class="btn btn-primary" id="admProgSubjAddBtn" onclick="ascbAdminProgSubjectSave()">
                <span class="btn-icon">+</span> Add Subject
            </button>
            <button type="button" class="btn btn-outline" id="admProgSubjCancelEditBtn" onclick="ascbAdminProgSubjectCancelEdit()" style="display:none;">
                Cancel Edit
            </button>
        </div>
        <div class="records-status" id="admProgSubjFormStatus" style="display:none;"></div>

        <div class="table-wrapper" style="margin-top:16px;">
            <table class="records-table" id="admProgSubjTable">
                <thead>
                    <tr>
                        <th>Year Level</th>
                        <th>Term</th>
                        <th>Code</th>
                        <th>Description</th>
                        <th>Units</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="admProgSubjTableBody"></tbody>
            </table>
        </div>
        <div class="records-status" id="admProgSubjListStatus">Loading…</div>
    </div>
</div>

<div class="f137-mini-modal" id="recordsDetailModal">
    <div class="f137-mini-card records-detail-card">
        <button type="button" class="f137-mini-close" onclick="ascbCloseRecordsDetail()">×</button>
        <h3 id="recordsDetailTitle">Details</h3>
        <div id="recordsDetailBody"></div>
    </div>
</div>

<div class="f137-mini-modal" id="enrollDetailModal">
    <div class="f137-mini-card records-detail-card">
        <button type="button" class="f137-mini-close" onclick="ascbEnrollCloseDetail()">×</button>
        <h3 id="enrollDetailTitle">Details</h3>
        <div id="enrollDetailBody"></div>
    </div>
</div>


    <div class="ascb-confirm-overlay" id="ascbLogoutModal">
        <div class="ascb-confirm-card">
            <div class="ascb-confirm-icon">🔒</div>
            <h3>Log Out</h3>
            <p>Are you sure you want to log out of the registrar system?</p>
            <div class="ascb-confirm-actions">
                <button type="button" class="btn btn-outline" onclick="ascbCancelLogout()">Cancel</button>
                <button type="button" class="btn btn-danger-solid" onclick="ascbLogout()">Yes, Logout</button>
            </div>
        </div>
    </div>

<script>
    /* Data mula sa MySQL database (config/db.php), inihanda ng
       dashboard.php — script.js gagamit nito sa halip na
       localStorage para sa Schools/Courses dropdown. */
    const ASCB_SCHOOLS = <?php echo json_encode($ascbSchools, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_COURSES = <?php echo json_encode(array_column($ascbCourses, 'name'), JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CURRENT_USER = <?php echo json_encode($ascbUser, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_PERMISSIONS = <?php echo json_encode($ascbPermissions, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CSRF_TOKEN = <?php echo json_encode(ascb_csrf_token(), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?>;

    /* Mga BAGONG Course/Program + Subjects na idinagdag ng admin
       sa "Programs & Subjects" (Admin panel) — pinagsasama ito sa
       structuredPrograms/programNames (hardcoded prospectus) sa
       script.js, kaya awtomatikong "callable" (magagamit) agad ang
       bagong course/major/subject/trimester/semester sa Enrollment
       module, walang kailangang i-edit na code. */
    const ASCB_CUSTOM_PROGRAMS = <?php echo json_encode($ascbCustomProgramsData['structured'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CUSTOM_PROGRAM_NAMES = <?php echo json_encode($ascbCustomProgramsData['names'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
    const ASCB_CUSTOM_PROGRAM_TERM_TYPES = <?php echo json_encode($ascbCustomProgramsData['termTypes'], JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); ?>;
</script>
<script src="script.js"></script>
<script>
    ascbRestoreLastView();
</script>

</body>
</html>
