<?php
/* =========================================================
   ASCB REGISTRAR SYSTEM — LOGIN PAGE
   Ngayon ay PHP + MySQL (database) na ang login sa halip na
   hardcoded array. Ang form sa ibaba ay direktang nagpo-POST
   dito mismo sa index.php.
   ========================================================= */

require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/security.php';
ascb_start_session();
ascb_send_security_headers();
require_once __DIR__ . '/config/db.php';
require_once __DIR__ . '/includes/activity_log.php';

// Kung naka-login na, deretso sa dashboard
if (!empty($_SESSION['ascb_user'])) {
    header('Location: dashboard.php');
    exit;
}

$loginError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = ascb_get($_POST, 'csrf_token', '');
    if (!ascb_verify_csrf($csrf)) {
        $loginError = 'Expired ang login form. I-refresh ang page at subukan muli.';
    }

    $username = trim(ascb_get($_POST, 'username', ''));
    $password = ascb_get($_POST, 'password', '');
    $remember = !empty($_POST['remember']);

    if ($loginError !== '') {
        // CSRF validation already failed.
    } elseif ($username === '' || $password === '') {
        $loginError = 'Invalid username or password. Please try again.';
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ? AND is_active = 1");
        $stmt->execute([$username]);

        $matchedUser = null;
        foreach ($stmt->fetchAll() as $row) {
            if (password_verify($password, $row['password_hash'])) {
                $matchedUser = $row;
                break;
            }
        }

        if (!$matchedUser) {
            usleep(350000); // slow repeated password guessing without revealing which field was wrong
            $loginError = 'Invalid username or password. Please try again.';
        } else {
            session_regenerate_id(true);

            $_SESSION['ascb_user'] = [
                'id'          => (int)$matchedUser['id'],
                'username'    => $matchedUser['username'],
                'displayName' => $matchedUser['display_name'],
                'role'        => $matchedUser['role'],
                'departmentId' => isset($matchedUser['department_id']) ? (int)$matchedUser['department_id'] : null,
                'departmentName' => null,
                'preparedBy'  => $matchedUser['prepared_by_code'],
            ];

            $_SESSION['ascb_remember'] = $remember ? 1 : 0;
            $_SESSION['ascb_last_activity'] = time();
            $_SESSION['ascb_csrf'] = ascb_random_token(32);

            ascb_log_activity($pdo, $_SESSION['ascb_user'], 'LOGIN', 'session', $matchedUser['display_name']);

            if ($remember) {
                // "Keep me signed in": 30-day cookie + SameSite/HttpOnly.
                ascb_extend_session_cookie(time() + 60 * 60 * 24 * 30);
            }

            header('Location: dashboard.php');
            exit;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="icon" type="image/png" href="ASCB_LOGO.png">
    <title>OFFICE OF THE REGISTRAR</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link rel="stylesheet" href="login.css">

    <script src="auth.js"></script>
</head>
<body>

    <div class="login-stage">
        <form class="login-card<?php echo $loginError ? ' shake' : ''; ?>" id="loginCard" method="POST" action="index.php" autocomplete="off">
            <input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(ascb_csrf_token(), ENT_QUOTES, 'UTF-8'); ?>">

            <div class="login-head">
                <img src="ASCB_LOGO.png" alt="ASCB Logo">
            </div>

            <div class="login-error<?php echo $loginError ? ' show' : ''; ?>" id="loginError">
                <?php echo htmlspecialchars($loginError); ?>
            </div>

            <div class="login-field">
                <label for="loginUsername">Username</label>
                <div class="login-input-wrap">
                    <input
                        type="text"
                        id="loginUsername"
                        name="username"
                        placeholder="Enter your username"
                        autocomplete="username"
                        required
                        autofocus
                    >
                </div>
            </div>

            <div class="login-field">
                <label for="loginPassword">Password</label>
                <div class="login-input-wrap">
                    <input
                        type="password"
                        id="loginPassword"
                        name="password"
                        placeholder="Enter your password"
                        autocomplete="current-password"
                        required
                    >
                    <button type="button" class="login-toggle-pw" id="loginTogglePw" onclick="ascbTogglePasswordVisibility()">Show</button>
                </div>
            </div>

            <div class="login-remember">
                <input type="checkbox" id="loginRemember" name="remember">
                <label for="loginRemember">Keep me signed in on this device</label>
            </div>

            <button type="submit" class="login-submit" id="loginSubmitBtn">Sign In</button>

            <div class="login-hint">
                Authorized Registrar Personnel only.
            </div>
        </form>
    </div>

    <div class="login-footer">
        &copy; Andres Soriano Colleges of Bislig, Inc. — Office of the Registrar 2026
    </div>

</body>
</html>
