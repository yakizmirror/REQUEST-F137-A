<?php
/* =========================================================
   API: RELEASING & RECEIVING OF DOCUMENTS
   ---------------------------------------------------------
   GET  -> ibinabalik ang listahan ng mga transactions
           (pinaka-bago muna), kasama ang naka-attach na files.

           Params: direction (RELEASED|RECEIVED, optional),
                   q (search text, optional),
                   limit (default 500, max 1000)

   POST -> multipart/form-data (HINDI JSON, dahil may
           kasamang file upload). Ang "action" field ang
           nagsasabi kung ano ang gagawin:

           action=create (o walang action field, para sa
                          lumang forms) :
               Fields: direction, documentName, partyName,
                       transactionDate, remarks,
                       documents[] (0 o higit pang PDF files)

           action=update :
               Fields: id, direction, documentName, partyName,
                       transactionDate, remarks,
                       documents[] (optional — mga BAGONG
                       PDF file na idadagdag sa entry, hindi
                       pinapalitan ang mga luma)

           action=delete :
               Field: id (buong transaction + lahat ng
               naka-attach na files nito ang matatanggal)

           action=delete_file :
               Field: file_id (isang naka-attach na file lang
               ang matatanggal, hindi ang buong transaction)
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$UPLOAD_DIR = __DIR__ . '/../uploads/documents/';
if (!is_dir($UPLOAD_DIR)) {
    @mkdir($UPLOAD_DIR, 0755, true);
}
if (!is_dir($UPLOAD_DIR) || !is_writable($UPLOAD_DIR)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Hindi writable ang upload folder sa server. I-check ang deployment folder permissions.'));
    exit;
}

$maxFiles     = 10;
$maxSizeBytes = ASCB_MAX_UPLOAD_MB * 1024 * 1024; // configurable; default 25 MB bawat file

$method = $_SERVER['REQUEST_METHOD'];


/* =========================================================
   Tulong na function: i-validate + i-save ang mga na-upload
   na PDF file mula sa isang array field (hal. "documents[]").
   Ibinabalik ang array ng array(original, stored, size) kung
   tagumpay, o direktang nagpapadala ng JSON error at
   nag-e-exit kung may problema sa kahit isang file.
   ========================================================= */
function ascbDocsHandleUploads($fieldName, $UPLOAD_DIR, $maxSizeBytes, $maxFiles) {

    $uploadedFiles = array();

    if (empty($_FILES[$fieldName]) || !is_array($_FILES[$fieldName]['name'])) {
        return $uploadedFiles;
    }

    $count = count($_FILES[$fieldName]['name']);
    if ($count > $maxFiles) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Max ' . $maxFiles . ' files lang bawat entry.'));
        exit;
    }

    for ($i = 0; $i < $count; $i++) {

        if ($_FILES[$fieldName]['error'][$i] === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($_FILES[$fieldName]['error'][$i] !== UPLOAD_ERR_OK) {
            $uploadErrCode = $_FILES[$fieldName]['error'][$i];
            $uploadErrMsgs = array(
                UPLOAD_ERR_INI_SIZE   => 'Lumagpas sa upload_max_filesize ng server (php.ini). Kailangang taasan ito ng system admin.',
                UPLOAD_ERR_FORM_SIZE  => 'Lumagpas sa max file size na tinakda sa form.',
                UPLOAD_ERR_PARTIAL    => 'Hindi natapos ang pag-upload ng file (na-interrupt sa gitna, baka slow connection o na-timeout).',
                UPLOAD_ERR_NO_TMP_DIR => 'Walang temporary folder sa server para sa upload.',
                UPLOAD_ERR_CANT_WRITE => 'Hindi ma-isulat ang file sa disk ng server (baka permission issue).',
                UPLOAD_ERR_EXTENSION  => 'Hinarang ang upload ng isang PHP extension sa server.',
            );
            $uploadErrText = isset($uploadErrMsgs[$uploadErrCode])
                ? $uploadErrMsgs[$uploadErrCode]
                : 'Hindi kilalang error (code ' . $uploadErrCode . ').';

            http_response_code(400);
            echo json_encode(array(
                'ok'    => false,
                'error' => 'May error sa pag-upload ng file (' . $_FILES[$fieldName]['name'][$i] . '): ' . $uploadErrText,
            ));
            exit;
        }

        $tmpPath      = $_FILES[$fieldName]['tmp_name'][$i];
        $originalName = $_FILES[$fieldName]['name'][$i];
        $size         = $_FILES[$fieldName]['size'][$i];

        if ($size > $maxSizeBytes) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => $originalName . ' ay masyadong malaki (max ' . ASCB_MAX_UPLOAD_MB . 'MB).'));
            exit;
        }

        $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

        $mime = '';
        if (function_exists('finfo_open')) {
            $finfo = finfo_open(FILEINFO_MIME_TYPE);
            if ($finfo) {
                $mime = finfo_file($finfo, $tmpPath);
                finfo_close($finfo);
            }
        }

        if ($ext !== 'pdf' || ($mime !== '' && $mime !== 'application/pdf')) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => $originalName . ' ay hindi PDF file.'));
            exit;
        }

        $storedName  = 'doc_' . ascb_random_token(16) . '.pdf';
        $destination = $UPLOAD_DIR . $storedName;

        if (!move_uploaded_file($tmpPath, $destination)) {
            http_response_code(500);
            echo json_encode(array('ok' => false, 'error' => 'Hindi na-save ang ' . $originalName . '.'));
            exit;
        }

        $uploadedFiles[] = array(
            'original' => $originalName,
            'stored'   => $storedName,
            'size'     => (int) $size,
        );
    }

    return $uploadedFiles;
}


/* ========================================== GET — LIST */

if ($method === 'GET') {

    $direction = ascb_get($_GET, 'direction', '');
    $q         = trim(ascb_get($_GET, 'q', ''));
    $limit     = (int) ascb_get($_GET, 'limit', 500);
    if ($limit <= 0 || $limit > 1000) {
        $limit = 500;
    }

    $sql = "SELECT t.*, u.display_name AS handled_by_name
            FROM document_transactions t
            LEFT JOIN users u ON u.id = t.handled_by_user_id";
    $where = array();
    $params = array();

    if ($direction === 'RELEASED' || $direction === 'RECEIVED') {
        $where[] = "t.direction = ?";
        $params[] = $direction;
    }
    if ($q !== '') {
        $where[] = "(t.document_name LIKE ? OR t.party_name LIKE ?)";
        $like = '%' . $q . '%';
        $params[] = $like;
        $params[] = $like;
    }
    if (!empty($where)) {
        $sql .= " WHERE " . implode(" AND ", $where);
    }
    $sql .= " ORDER BY t.created_at DESC LIMIT " . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    if ($rows) {
        $ids = array_column($rows, 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        $fileStmt = $pdo->prepare(
            "SELECT id, transaction_id, original_filename, filesize_bytes
             FROM document_transaction_files
             WHERE transaction_id IN ($placeholders)
             ORDER BY id ASC"
        );
        $fileStmt->execute($ids);

        $filesByTx = array();
        foreach ($fileStmt->fetchAll() as $f) {
            $txId = $f['transaction_id'];
            if (!isset($filesByTx[$txId])) {
                $filesByTx[$txId] = array();
            }
            $filesByTx[$txId][] = array(
                'id'   => (int) $f['id'],
                'name' => $f['original_filename'],
                'size' => (int) $f['filesize_bytes'],
            );
        }

        foreach ($rows as &$row) {
            $row['files'] = isset($filesByTx[$row['id']]) ? $filesByTx[$row['id']] : array();
        }
        unset($row);
    }

    echo json_encode(array('ok' => true, 'rows' => $rows), JSON_UNESCAPED_UNICODE);
    exit;
}


/* ========================================== POST — CREATE / UPDATE / DELETE */

if ($method === 'POST') {

    $action = ascb_get($_POST, 'action', 'create');


    /* ----------------------------------------- DELETE (buong entry) */
    if ($action === 'delete') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM document_transactions WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang entry.'));
            exit;
        }

        $fileStmt = $pdo->prepare("SELECT * FROM document_transaction_files WHERE transaction_id = ?");
        $fileStmt->execute(array($id));
        $files = $fileStmt->fetchAll();

        $pdo->prepare("DELETE FROM document_transaction_files WHERE transaction_id = ?")->execute(array($id));
        $pdo->prepare("DELETE FROM document_transactions WHERE id = ?")->execute(array($id));

        foreach ($files as $f) {
            $path = $UPLOAD_DIR . $f['stored_filename'];
            if (is_file($path)) {
                @unlink($path);
            }
        }

        echo json_encode(array('ok' => true));
        exit;
    }


    /* ----------------------------------------- DELETE_FILE (isang attachment lang) */
    if ($action === 'delete_file') {

        $fileId = (int) ascb_get($_POST, 'file_id', 0);
        if ($fileId <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid file id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM document_transaction_files WHERE id = ?");
        $stmt->execute(array($fileId));
        $file = $stmt->fetch();

        if (!$file) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang file.'));
            exit;
        }

        $pdo->prepare("DELETE FROM document_transaction_files WHERE id = ?")->execute(array($fileId));

        $path = $UPLOAD_DIR . $file['stored_filename'];
        if (is_file($path)) {
            @unlink($path);
        }

        echo json_encode(array('ok' => true));
        exit;
    }


    /* ----------------------------------------- UPDATE */
    if ($action === 'update') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM document_transactions WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang entry.'));
            exit;
        }

        $direction       = ascb_get($_POST, 'direction', '');
        $documentName    = trim(ascb_get($_POST, 'documentName', ''));
        $partyName       = trim(ascb_get($_POST, 'partyName', ''));
        $transactionDate = ascb_get($_POST, 'transactionDate', '');
        $remarks         = trim(ascb_get($_POST, 'remarks', ''));

        if ($direction !== 'RELEASED' && $direction !== 'RECEIVED') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Piliin ang Released o Received.'));
            exit;
        }
        if ($documentName === '' || $partyName === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng Document Name at pangalan ng kausap.'));
            exit;
        }

        // Bagong file/s (optional) — idadagdag lang, hindi pinapalitan ang mga luma.
        $uploadedFiles = ascbDocsHandleUploads('documents', $UPLOAD_DIR, $maxSizeBytes, $maxFiles);

        try {
            $pdo->beginTransaction();

            $stmt = $pdo->prepare(
                "UPDATE document_transactions
                    SET direction = ?, document_name = ?, party_name = ?, transaction_date = ?, remarks = ?
                  WHERE id = ?"
            );
            $stmt->execute(array(
                $direction,
                $documentName,
                $partyName,
                $transactionDate !== '' ? $transactionDate : null,
                $remarks !== '' ? $remarks : null,
                $id,
            ));

            if (!empty($uploadedFiles)) {
                $fileStmt = $pdo->prepare(
                    "INSERT INTO document_transaction_files
                        (transaction_id, original_filename, stored_filename, filesize_bytes)
                     VALUES (?,?,?,?)"
                );
                foreach ($uploadedFiles as $f) {
                    $fileStmt->execute(array($id, $f['original'], $f['stored'], $f['size']));
                }
            }

            $pdo->commit();

        } catch (Exception $e) {
            $pdo->rollBack();
            foreach ($uploadedFiles as $f) {
                @unlink($UPLOAD_DIR . $f['stored']);
            }
            http_response_code(500);
            echo json_encode(array('ok' => false, 'error' => 'Hindi na-save sa database.'));
            exit;
        }

        echo json_encode(array('ok' => true));
        exit;
    }


    /* ----------------------------------------- CREATE (default) */

    $direction       = ascb_get($_POST, 'direction', '');
    $documentName    = trim(ascb_get($_POST, 'documentName', ''));
    $partyName       = trim(ascb_get($_POST, 'partyName', ''));
    $transactionDate = ascb_get($_POST, 'transactionDate', '');
    $remarks         = trim(ascb_get($_POST, 'remarks', ''));

    if ($direction !== 'RELEASED' && $direction !== 'RECEIVED') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Piliin ang Released o Received.'));
        exit;
    }
    if ($documentName === '' || $partyName === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Kailangan ng Document Name at pangalan ng kausap.'));
        exit;
    }

    $uploadedFiles = ascbDocsHandleUploads('documents', $UPLOAD_DIR, $maxSizeBytes, $maxFiles);

    try {
        $pdo->beginTransaction();

        $stmt = $pdo->prepare(
            "INSERT INTO document_transactions
                (direction, document_name, party_name, transaction_date, remarks, handled_by_user_id)
             VALUES (?,?,?,?,?,?)"
        );
        $stmt->execute(array(
            $direction,
            $documentName,
            $partyName,
            $transactionDate !== '' ? $transactionDate : null,
            $remarks !== '' ? $remarks : null,
            ascb_get($ascbUser, 'id', null),
        ));

        $txId = $pdo->lastInsertId();

        if (!empty($uploadedFiles)) {
            $fileStmt = $pdo->prepare(
                "INSERT INTO document_transaction_files
                    (transaction_id, original_filename, stored_filename, filesize_bytes)
                 VALUES (?,?,?,?)"
            );
            foreach ($uploadedFiles as $f) {
                $fileStmt->execute(array($txId, $f['original'], $f['stored'], $f['size']));
            }
        }

        $pdo->commit();

    } catch (Exception $e) {
        $pdo->rollBack();
        foreach ($uploadedFiles as $f) {
            @unlink($UPLOAD_DIR . $f['stored']);
        }
        http_response_code(500);
        echo json_encode(array('ok' => false, 'error' => 'Hindi na-save sa database.'));
        exit;
    }

    echo json_encode(array('ok' => true, 'id' => $txId));
    exit;
}


/* ========================================== OTHER METHODS */

http_response_code(405);
echo json_encode(array('ok' => false, 'error' => 'Method not allowed.'));
