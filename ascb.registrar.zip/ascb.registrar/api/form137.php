<?php
/* =========================================================
   API: FORM 137-A REQUESTS
   Nag-lo-log ng bawat Form 137-A request letter sa DB.
   Tinatawag ito ng script.js (generateForm137) kapag
   nag-preview/submit na ng request.

   POST body (JSON): {
     requestDate, school, schoolAddress,
     firstRequest, secondRequest, urgentRequest,
     bearerRequest, copyForASCB,
     students: [{name, course, schoolYear, yearSection}, ...]
   }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$decoded = json_decode(file_get_contents('php://input'), true);
$data = is_array($decoded) ? $decoded : array();

if (empty($data['school']) || empty($data['students']) || !is_array($data['students'])) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Missing school or student list.'));
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO form137_requests
        (request_date, school_name, school_address, first_request, second_request,
         urgent_request, bearer_request, copy_for_ascb, students_json, requested_by_user_id)
     VALUES (?,?,?,?,?,?,?,?,?,?)"
);

$stmt->execute(array(
    !empty($data['requestDate']) ? $data['requestDate'] : null,
    ascb_get($data, 'school', ''),
    ascb_get($data, 'schoolAddress', ''),
    !empty($data['firstRequest']) ? 1 : 0,
    !empty($data['secondRequest']) ? 1 : 0,
    !empty($data['urgentRequest']) ? 1 : 0,
    !empty($data['bearerRequest']) ? 1 : 0,
    !empty($data['copyForASCB']) ? 1 : 0,
    json_encode($data['students'], JSON_UNESCAPED_UNICODE),
    ascb_get($ascbUser, 'id', null),
));

echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
