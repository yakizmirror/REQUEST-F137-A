<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];
$role = ascb_get($ascbUser, 'role', '');

function ascb_grade_valid($grade) {
    $grade = trim((string)$grade);
    if ($grade === '') return true;
    if (preg_match('/^(INC|DRP|5(?:\.0)?|[0-4](?:\.\d{1,2})?)$/i', $grade)) {
        if (is_numeric($grade)) {
            $n = (float)$grade;
            return $n >= 1 && $n <= 5;
        }
        return in_array(strtoupper($grade), ['INC','DRP'], true);
    }
    return false;
}

if ($method === 'GET') {
    $q = trim(ascb_get($_GET, 'q', ''));
    $studentId = trim(ascb_get($_GET, 'student_id', ''));
    $sql = "SELECT e.id AS enrollment_id, e.student_id, e.surname, e.first_name, e.middle_name,
                   e.course, e.major, e.program_code, e.year_level, e.trimester, e.school_year,
                   e.status, e.created_at,
                   es.id AS enrollment_subject_id, es.course_code, es.description, es.units,
                   g.grade, g.updated_at AS grade_updated_at
            FROM enrollees e
            LEFT JOIN enrollment_subjects es ON es.enrollment_id = e.id
            LEFT JOIN grades g ON g.enrollment_subject_id = es.id
            WHERE e.archived_at IS NULL AND e.status <> 'rejected'";
    $params = [];
    if ($role === 'DEAN') { $deptId=ascb_require_dean_department($pdo,$ascbUser); $sql .= " AND EXISTS (SELECT 1 FROM programs dp WHERE dp.code=e.program_code AND dp.department_id=?)"; $params[]=$deptId; }
    if ($studentId !== '') { $sql .= " AND e.student_id = ?"; $params[] = $studentId; }
    if ($q !== '') {
        $sql .= " AND (e.student_id LIKE ? OR e.surname LIKE ? OR e.first_name LIKE ? OR e.middle_name LIKE ? OR e.course LIKE ? OR e.major LIKE ?)";
        $like = '%'.$q.'%';
        array_push($params, $like,$like,$like,$like,$like,$like);
    }
    $sql .= " ORDER BY e.surname, e.first_name, e.created_at, es.id";
    $stmt = $pdo->prepare($sql); $stmt->execute($params);
    $rows = $stmt->fetchAll();
    echo json_encode(['ok'=>true,'rows'=>$rows], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($method === 'POST') {
    if (!ascb_can($role, 'manage_grades')) {
        http_response_code(403); echo json_encode(['ok'=>false,'error'=>'Wala kang permission na mag-input o mag-update ng grades.']); exit;
    }
    $input = json_decode(file_get_contents('php://input'), true);
    $input = is_array($input) ? $input : [];
    $action = trim((string)($input['action'] ?? 'save'));
    if ($action !== 'save') { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid grade action.']); exit; }
    $enrollmentId = (int)($input['enrollmentId'] ?? 0);
    $grades = $input['grades'] ?? [];
    if ($enrollmentId <= 0 || !is_array($grades)) { http_response_code(400); echo json_encode(['ok'=>false,'error'=>'Invalid grade data.']); exit; }

    $check = $pdo->prepare("SELECT id, student_id, surname, first_name, trimester, school_year FROM enrollees WHERE id = ? AND archived_at IS NULL AND status <> 'rejected'");
    $check->execute([$enrollmentId]); $enrollment = $check->fetch();
    if (!$enrollment) { http_response_code(404); echo json_encode(['ok'=>false,'error'=>'Hindi nahanap ang enrollment term.']); exit; }

    try {
        $pdo->beginTransaction();
        $subjectCheck = $pdo->prepare("SELECT id FROM enrollment_subjects WHERE id = ? AND enrollment_id = ?");
        $find = $pdo->prepare("SELECT id, grade FROM grades WHERE enrollment_subject_id = ? LIMIT 1");
        $insert = $pdo->prepare("INSERT INTO grades (enrollment_subject_id, grade, entered_by_user_id, entered_at) VALUES (?, ?, ?, ?)");
        $update = $pdo->prepare("UPDATE grades SET grade = ?, updated_by_user_id = ?, updated_at = ? WHERE id = ?");
        $now = date('Y-m-d H:i:s');
        $changed = 0;
        foreach ($grades as $item) {
            $subjectId = (int)($item['subjectId'] ?? 0);
            $grade = trim((string)($item['grade'] ?? ''));
            if ($subjectId <= 0 || !ascb_grade_valid($grade)) {
                throw new Exception('Invalid grade. Use 1.00–5.00, INC, DRP, or leave blank.');
            }
            $subjectCheck->execute([$subjectId, $enrollmentId]);
            if (!$subjectCheck->fetchColumn()) throw new Exception('Invalid subject for this enrollment.');
            $find->execute([$subjectId]); $old = $find->fetch();
            if ($old) {
                if ((string)$old['grade'] !== $grade) { $update->execute([$grade !== '' ? $grade : null, (int)$ascbUser['id'], $now, (int)$old['id']]); $changed++; }
            } elseif ($grade !== '') {
                $insert->execute([$subjectId, $grade, (int)$ascbUser['id'], $now]); $changed++;
            }
        }
        $pdo->commit();
        ascb_log_activity($pdo, $ascbUser, 'GRADE_UPDATE', 'enrollment', $enrollment['surname'].', '.$enrollment['first_name'].' ('.$enrollment['student_id'].')', 'Updated '.$changed.' grade(s) for '.$enrollment['trimester'].' / '.$enrollment['school_year']);
        echo json_encode(['ok'=>true,'changed'=>$changed]); exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        http_response_code(400); echo json_encode(['ok'=>false,'error'=>$e->getMessage()]); exit;
    }
}

http_response_code(405); echo json_encode(['ok'=>false,'error'=>'Method not allowed.']);
