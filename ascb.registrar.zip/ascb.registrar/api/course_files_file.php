<?php
/* =========================================================
   API: DOWNLOAD A COURSE FILE (Excel)
   ---------------------------------------------------------
   Streams pababa (force download) ang totoong Excel file ng
   isang Course File entry. Naka-login lang (via api_guard.php)
   ang pwedeng makakuha nito — hindi direkta ma-access ang mga
   file sa uploads/course_files/ dahil naka-deny ito sa
   .htaccess.

   GET param: id = ID ng row sa course_files
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$id = (int) ascb_get($_GET, 'id', 0);

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM course_files WHERE id = ?");
$stmt->execute(array($id));
$row = $stmt->fetch();

if (!$row) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'Entry not found.'));
    exit;
}

$path = __DIR__ . '/../uploads/course_files/' . $row['stored_filename'];

if (!is_file($path)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'File missing on server.'));
    exit;
}

$ext = strtolower(pathinfo($row['stored_filename'], PATHINFO_EXTENSION));

$mimeByExt = array(
    'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    'xls'  => 'application/vnd.ms-excel',
    'csv'  => 'text/csv',
);
$contentType = isset($mimeByExt[$ext]) ? $mimeByExt[$ext] : 'application/octet-stream';

/* api_guard.php nagset na ng Content-Type: application/json —
   i-override natin dito dahil binary/Excel file ang ipapadala.
   "attachment" (hindi "inline") dahil pina-download ang file na
   ito, hindi pinapanood sa loob ng browser. */
header('Content-Type: ' . $contentType);
$downloadName = str_replace(array("\r", "\n", '"'), '', basename($row['original_filename']));
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
