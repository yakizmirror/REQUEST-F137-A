<?php
/* =========================================================
   API: RECORDS
   Ibinabalik ang listahan ng mga naka-log na Certificates o
   Form 137-A requests (pinaka-bago muna), para sa Records
   view sa dashboard.php.

   GET params:
     type   = "certificates" (default) | "form137"
     q      = optional search text (student / OR # / school)
     limit  = optional, default 500, max 1000
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$type  = ascb_get($_GET, 'type', 'certificates');
$q     = trim(ascb_get($_GET, 'q', ''));
$limit = (int) ascb_get($_GET, 'limit', 500);
if ($limit <= 0 || $limit > 1000) {
    $limit = 500;
}

if ($type === 'form137') {

    $sql = "SELECT f.*, u.display_name AS requested_by_name
            FROM form137_requests f
            LEFT JOIN users u ON u.id = f.requested_by_user_id";
    $params = array();

    if ($q !== '') {
        $sql .= " WHERE f.school_name LIKE ? OR f.students_json LIKE ?";
        $like = '%' . $q . '%';
        $params[] = $like;
        $params[] = $like;
    }

    $sql .= " ORDER BY f.created_at DESC LIMIT " . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $decodedStudents = json_decode($row['students_json'], true);
        $row['students'] = is_array($decodedStudents) ? $decodedStudents : array();
        unset($row['students_json']);
    }
    unset($row);

} else {

    $type = 'certificates';

    $sql = "SELECT c.*, u.display_name AS issued_by_name
            FROM certificates c
            LEFT JOIN users u ON u.id = c.issued_by_user_id";
    $params = array();

    if ($q !== '') {
        $sql .= " WHERE c.student_name LIKE ? OR c.student_id LIKE ? OR c.or_number LIKE ?";
        $like = '%' . $q . '%';
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    $sql .= " ORDER BY c.created_at DESC LIMIT " . $limit;

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();

    foreach ($rows as &$row) {
        $decodedSubjects = json_decode($row['subjects_json'], true);
        $row['subjects'] = is_array($decodedSubjects) ? $decodedSubjects : array();
        unset($row['subjects_json']);
    }
    unset($row);
}

echo json_encode(array('ok' => true, 'type' => $type, 'rows' => $rows), JSON_UNESCAPED_UNICODE);
