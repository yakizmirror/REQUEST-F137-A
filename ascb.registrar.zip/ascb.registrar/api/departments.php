<?php
require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';
$input=json_decode(file_get_contents('php://input'),true); if(!is_array($input))$input=array();
$action=ascb_get($input,'action','list'); $role=ascb_get($ascbUser,'role','');
if(!ascb_has_column($pdo,'programs','department_id')){
  // Retry the automatic schema upgrade once, live, in case the earlier
  // attempt (on connect) hit a transient error.
  if (function_exists('ascb_ensure_department_schema')) { ascb_ensure_department_schema($pdo); }
  if(!ascb_has_column($pdo,'programs','department_id')){
    http_response_code(503);
    $detail = !empty($GLOBALS['ascb_department_schema_error']) ? $GLOBALS['ascb_department_schema_error'] : 'Hindi alam ang dahilan; i-check ang PHP error log ng server.';
    echo json_encode(array('ok'=>false,'error'=>'Hindi na-set up ang Departments/Backup tables. Detalye: '.$detail.' — Kung ALTER/CREATE privilege ang dahilan, i-check ang MySQL user ng database, o patakbuhin ang database/migrate_departments_dean_backup_module.php.'));
    exit;
  }
}
if($action==='list'){
  $rows=$pdo->query("SELECT d.id,d.code,d.name,d.is_active,d.created_at,(SELECT COUNT(*) FROM programs p WHERE p.department_id=d.id) program_count,(SELECT COUNT(*) FROM users u WHERE u.department_id=d.id AND u.role='DEAN' AND u.is_active=1) dean_count FROM departments d ORDER BY d.name")->fetchAll();
  echo json_encode(array('ok'=>true,'departments'=>$rows));exit;
}
if(!ascb_can($role,'manage_departments')){http_response_code(403);echo json_encode(array('ok'=>false,'error'=>'UNIT HEAD o SCHOOL REGISTRAR lang ang pwedeng mag-manage ng Departments.'));exit;}
if($action==='add'||$action==='update'){
  $id=(int)ascb_get($input,'id',0);$code=strtoupper(trim(ascb_get($input,'code','')));$name=trim(ascb_get($input,'name',''));$active=ascb_get($input,'isActive',1)?1:0;
  if($code===''||$name===''){http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'Kailangan ang Department Code at Name.'));exit;}
  try{
   if($action==='add'){$s=$pdo->prepare("INSERT INTO departments(code,name,is_active) VALUES(?,?,1)");$s->execute(array($code,$name));$id=$pdo->lastInsertId();ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_ADD','department',$code.' — '.$name);}
   else{$s=$pdo->prepare("UPDATE departments SET code=?,name=?,is_active=? WHERE id=?");$s->execute(array($code,$name,$active,$id));ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_UPDATE','department',$code.' — '.$name);}
   echo json_encode(array('ok'=>true,'id'=>$id));
  }catch(PDOException $e){http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'Duplicate Department Code/Name o invalid data.'));}exit;
}
if($action==='delete'){
 $id=(int)ascb_get($input,'id',0);$c=$pdo->prepare("SELECT COUNT(*) FROM programs WHERE department_id=?");$c->execute(array($id));if((int)$c->fetchColumn()>0){http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'May Programs pa sa Department na ito. Ilipat muna ang mga Program.'));exit;}
 $s=$pdo->prepare("DELETE FROM departments WHERE id=?");$s->execute(array($id));ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_DELETE','department','#'.$id);echo json_encode(array('ok'=>true));exit;
}
http_response_code(400);echo json_encode(array('ok'=>false,'error'=>'Unknown action.'));
