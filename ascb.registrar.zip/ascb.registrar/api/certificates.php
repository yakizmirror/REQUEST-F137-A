<?php
/* =========================================================
   API: CERTIFICATES
   Nag-lo-log ng bawat na-generate na certificate sa DB.
   Tinatawag ito ng script.js (generateCertificate) sa
   sandaling matagumpay na nabuo ang preview — hindi ito
   humaharang sa pag-print, log lang ito sa background.

   POST body (JSON): {
     certificateType, studentName, studentId, program,
     yearLevel, trimester, academicYear, enrollmentDate,
     status, orNumber, totalUnits, gwa, preparedBy,
     subjects: [{code, description, grade, units}, ...]
   }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$decoded = json_decode(file_get_contents('php://input'), true);
$data = is_array($decoded) ? $decoded : array();

if (empty($data['studentName']) || empty($data['studentId'])) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Missing student name or student ID.'));
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO certificates
        (certificate_type, student_name, student_id, program, year_level, trimester,
         academic_year, enrollment_date, status, or_number, total_units, gwa,
         subjects_json, prepared_by, issued_by_user_id)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
);

$stmt->execute(array(
    ascb_get($data, 'certificateType', ''),
    ascb_get($data, 'studentName', ''),
    ascb_get($data, 'studentId', ''),
    ascb_get($data, 'program', ''),
    ascb_get($data, 'yearLevel', ''),
    ascb_get($data, 'trimester', ''),
    ascb_get($data, 'academicYear', ''),
    !empty($data['enrollmentDate']) ? $data['enrollmentDate'] : null,
    ascb_get($data, 'status', ''),
    ascb_get($data, 'orNumber', ''),
    (isset($data['totalUnits']) && $data['totalUnits'] !== '') ? $data['totalUnits'] : null,
    (isset($data['gwa']) && $data['gwa'] !== '') ? $data['gwa'] : null,
    json_encode(ascb_get($data, 'subjects', array()), JSON_UNESCAPED_UNICODE),
    ascb_get($data, 'preparedBy', ascb_get($ascbUser, 'preparedBy', '')),
    ascb_get($ascbUser, 'id', null),
));

echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
