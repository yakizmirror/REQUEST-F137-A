<?php
/* =========================================================
   API: SERVE A DOCUMENT FILE
   ---------------------------------------------------------
   Streams ang totoong PDF file ng isang naka-log na document
   transaction. Naka-login lang (via api_guard.php) ang
   pwedeng makakuha nito — hindi direkta ma-access ang mga PDF
   sa uploads/documents/ dahil naka-deny ito sa .htaccess.

   GET param: id = ID ng row sa document_transaction_files
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$fileId = (int) ascb_get($_GET, 'id', 0);

if ($fileId <= 0) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Invalid file id.'));
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM document_transaction_files WHERE id = ?");
$stmt->execute(array($fileId));
$file = $stmt->fetch();

if (!$file) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'File not found.'));
    exit;
}

$path = __DIR__ . '/../uploads/documents/' . $file['stored_filename'];

if (!is_file($path)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'File missing on server.'));
    exit;
}

/* api_guard.php nagset na ng Content-Type: application/json —
   i-override natin dito dahil PDF binary ang ipapadala. */
header('Content-Type: application/pdf');
$downloadName = str_replace(array("\r", "\n", '"'), '', basename($file['original_filename']));
header('Content-Disposition: inline; filename="' . $downloadName . '"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
