<?php
/* =========================================================
   API: ACTIVITY LOG (Admin panel — History)
   ---------------------------------------------------------
   POST body (JSON): { "action": "list", "q": "...", "limit": 200 }

   Kailangan: view_activity_log permission (UNIT HEAD o
   SCHOOL REGISTRAR). Ibinabalik ang pinaka-bagong 200 entries
   by default (max 1000), pinaka-bago muna.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../config/db.php';

if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'view_activity_log')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'Wala kang access sa Activity Log.'));
    exit;
}

$decoded = json_decode(file_get_contents('php://input'), true);
$input = is_array($decoded) ? $decoded : array();
$action = ascb_get($input, 'action', 'list');

if ($action !== 'list') {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
    exit;
}

$q     = trim(ascb_get($input, 'q', ''));
$limit = (int) ascb_get($input, 'limit', 200);
if ($limit <= 0 || $limit > 1000) {
    $limit = 200;
}

$sql = "SELECT * FROM activity_log";
$params = array();

if ($q !== '') {
    $sql .= " WHERE display_name LIKE ? OR action LIKE ? OR entity_label LIKE ? OR details LIKE ?";
    $like = '%' . $q . '%';
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
    $params[] = $like;
}

$sql .= " ORDER BY created_at DESC, id DESC LIMIT " . $limit;

try {
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll();
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(array(
        'ok'    => false,
        'error' => 'Hindi pa na-setup ang Activity Log table. Patakbuhin muna ang database/migrate_admin_module.php.'
    ), JSON_UNESCAPED_UNICODE);
    exit;
}

echo json_encode(array('ok' => true, 'rows' => $rows), JSON_UNESCAPED_UNICODE);
