<?php
/* =========================================================
   API: COURSES
   POST body (JSON): { "action": "add", "name": "..." }
                   or { "action": "delete", "name": "..." }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$decoded = json_decode(file_get_contents('php://input'), true);
$input = is_array($decoded) ? $decoded : array();
$action = ascb_get($input, 'action', '');

if ($action === 'add') {
    $name = trim(ascb_get($input, 'name', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Enter the course name.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM courses WHERE LOWER(name) = LOWER(?)");
    $check->execute(array($name));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This course is already saved.'));
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO courses (name) VALUES (?)");
    $stmt->execute(array($name));

    ascb_log_activity($pdo, $ascbUser, 'COURSE_ADD', 'course', $name);

    echo json_encode(array('ok' => true, 'course' => array('id' => $pdo->lastInsertId(), 'name' => $name)));
    exit;
}

if ($action === 'delete') {

    if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_lookups')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'Wala kang access na mag-delete ng course.'));
        exit;
    }

    $name = trim(ascb_get($input, 'name', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing course name.'));
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM courses WHERE name = ?");
    $stmt->execute(array($name));

    ascb_log_activity($pdo, $ascbUser, 'COURSE_DELETE', 'course', $name);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'list') {
    $rows = $pdo->query("SELECT id, name FROM courses ORDER BY name")->fetchAll();
    echo json_encode(array('ok' => true, 'courses' => $rows));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
