<?php
/* =========================================================
   API: SCHOOLS
   POST body (JSON): { "action": "add", "name": "...", "address": "..." }
                   or { "action": "delete", "name": "..." }
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$decoded = json_decode(file_get_contents('php://input'), true);
$input = is_array($decoded) ? $decoded : array();
$action = ascb_get($input, 'action', '');

if ($action === 'add') {
    $name    = trim(ascb_get($input, 'name', ''));
    $address = trim(ascb_get($input, 'address', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Enter the school name.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM schools WHERE LOWER(name) = LOWER(?)");
    $check->execute(array($name));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'This school is already saved.'));
        exit;
    }

    $stmt = $pdo->prepare("INSERT INTO schools (name, address) VALUES (?, ?)");
    $stmt->execute(array($name, $address));

    ascb_log_activity($pdo, $ascbUser, 'SCHOOL_ADD', 'school', $name);

    echo json_encode(array(
        'ok'     => true,
        'school' => array('id' => $pdo->lastInsertId(), 'name' => $name, 'address' => $address),
    ));
    exit;
}

if ($action === 'delete') {

    /* Sensitibo ito (permanenteng pagbura ng dropdown option na
       posibleng ginagamit na sa mga naka-log nang records) — kaya
       limitado lang sa UNIT HEAD / SCHOOL REGISTRAR. Ang pag-ADD
       sa itaas ay bukas pa rin sa lahat, tulad ng dati. */
    if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_lookups')) {
        http_response_code(403);
        echo json_encode(array('ok' => false, 'error' => 'Wala kang access na mag-delete ng school.'));
        exit;
    }

    $name = trim(ascb_get($input, 'name', ''));

    if ($name === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Missing school name.'));
        exit;
    }

    $stmt = $pdo->prepare("DELETE FROM schools WHERE name = ?");
    $stmt->execute(array($name));

    ascb_log_activity($pdo, $ascbUser, 'SCHOOL_DELETE', 'school', $name);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'list') {
    $rows = $pdo->query("SELECT id, name, address FROM schools ORDER BY name")->fetchAll();
    echo json_encode(array('ok' => true, 'schools' => $rows));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
