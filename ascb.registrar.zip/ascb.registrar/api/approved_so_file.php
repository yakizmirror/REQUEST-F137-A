<?php
/* =========================================================
   API: SERVE AN APPROVED SO PDF FILE
   ---------------------------------------------------------
   Streams ang totoong PDF file ng isang Approved SO entry.
   Naka-login lang (via api_guard.php) ang pwedeng makakuha
   nito — hindi direkta ma-access ang mga PDF sa
   uploads/approved_so/ dahil naka-deny ito sa .htaccess.

   GET param: id = ID ng row sa approved_so
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$id = (int) ascb_get($_GET, 'id', 0);

if ($id <= 0) {
    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
    exit;
}

$stmt = $pdo->prepare("SELECT * FROM approved_so WHERE id = ?");
$stmt->execute(array($id));
$row = $stmt->fetch();

if (!$row) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'Entry not found.'));
    exit;
}

$path = __DIR__ . '/../uploads/approved_so/' . $row['stored_filename'];

if (!is_file($path)) {
    http_response_code(404);
    echo json_encode(array('ok' => false, 'error' => 'File missing on server.'));
    exit;
}

/* api_guard.php nagset na ng Content-Type: application/json —
   i-override natin dito dahil PDF binary ang ipapadala. */
header('Content-Type: application/pdf');
$downloadName = str_replace(array("\r", "\n", '"'), '', basename($row['original_filename']));
header('Content-Disposition: inline; filename="' . $downloadName . '"');
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
readfile($path);
exit;
