<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';
$role=ascb_get($ascbUser,'role','');
if(!in_array($role,array('DEAN','UNIT HEAD','SCHOOL REGISTRAR'),true)){http_response_code(403);exit('Forbidden');}
$departmentId=(int)ascb_get($_GET,'department_id',0);$sy=trim(ascb_get($_GET,'school_year',''));$term=trim(ascb_get($_GET,'term',''));
if($role==='DEAN'){$departmentId=ascb_require_dean_department($pdo,$ascbUser);} if(!$departmentId){http_response_code(400);exit('Department required');}
$d=$pdo->prepare("SELECT code,name FROM departments WHERE id=?");$d->execute(array($departmentId));$dep=$d->fetch();if(!$dep){http_response_code(404);exit('Department not found');}

/* Department is now snapshotted on each enrollment. Keep a LEFT JOIN to
   programs for display so a historical enrollment is not lost just because
   the program mapping was changed/deactivated later. The fallback condition
   supports older rows while the schema upgrade/backfill is catching up. */
$where=array('(e.department_id=? OR (e.department_id IS NULL AND p.department_id=?))');
$params=array($departmentId,$departmentId);
if($sy!==''){$where[]='e.school_year=?';$params[]=$sy;}
if($term!==''){$where[]='e.trimester=?';$params[]=$term;}

$sql="SELECT e.id enrollment_id,e.student_id,CONCAT(e.surname,', ',e.first_name,IF(e.middle_name IS NULL OR e.middle_name='','',CONCAT(' ',e.middle_name))) student_name,e.student_type,e.program_code,e.course,e.major,e.year_level,e.trimester,e.school_year,e.status,e.subjects_json,p.code program_db_code,p.course_name program_db_name,p.major program_db_major FROM enrollees e LEFT JOIN programs p ON UPPER(TRIM(p.code))=UPPER(TRIM(e.program_code)) WHERE e.archived_at IS NULL AND e.status<>'rejected' AND ".implode(' AND ',$where)." ORDER BY e.surname,e.first_name,e.school_year,e.trimester";
$s=$pdo->prepare($sql);$s->execute($params);$enrollees=$s->fetchAll();

/* Step 2: subjects/grades. One enrollee still produces at least one row,
   even when no subjects have been saved yet. */
$rows=array();
if($enrollees){
  $ids=array_column($enrollees,'enrollment_id');
  $in=implode(',',array_fill(0,count($ids),'?'));
  $es=$pdo->prepare("SELECT es.enrollment_id,es.course_code,es.description,es.units,g.grade FROM enrollment_subjects es LEFT JOIN grades g ON g.enrollment_subject_id=es.id WHERE es.enrollment_id IN ($in) ORDER BY es.id");
  $es->execute($ids);
  $byEnrollment=array();
  foreach($es->fetchAll() as $r){ $byEnrollment[$r['enrollment_id']][]=$r; }

  foreach($enrollees as $e){
    $programCode = $e['program_code'] ?: $e['program_db_code'];
    $courseName = $e['course'] ?: $e['program_db_name'];
    $major = $e['major'] ?: $e['program_db_major'];
    $base=array('student_id'=>$e['student_id'],'student_name'=>$e['student_name'],'student_type'=>$e['student_type'],'program_code'=>$programCode,'course_name'=>$courseName,'major'=>$major,'year_level'=>$e['year_level'],'trimester'=>$e['trimester'],'school_year'=>$e['school_year'],'status'=>$e['status']);
    if(!empty($byEnrollment[$e['enrollment_id']])){
      $first=true;
      foreach($byEnrollment[$e['enrollment_id']] as $sub){
        // Show student/enrollment information only on the first subject row.
        // Subsequent subject rows intentionally leave those columns blank.
        $rowBase=$first ? $base : array(
          'student_id'=>'','student_name'=>'','student_type'=>'','program_code'=>'',
          'course_name'=>'','major'=>'','year_level'=>'','trimester'=>'','school_year'=>'','status'=>''
        );
        $rows[]=$rowBase+array('subject_code'=>$sub['course_code'],'subject_description'=>$sub['description'],'units'=>$sub['units'],'grade'=>$sub['grade']);
        $first=false;
      }
    } elseif(!empty($e['subjects_json'])){
      $legacy=json_decode($e['subjects_json'],true);
      if(is_array($legacy) && count($legacy)){
        $first=true;
        foreach($legacy as $lsub){
          $rowBase=$first ? $base : array(
            'student_id'=>'','student_name'=>'','student_type'=>'','program_code'=>'',
            'course_name'=>'','major'=>'','year_level'=>'','trimester'=>'','school_year'=>'','status'=>''
          );
          $rows[]=$rowBase+array('subject_code'=>ascb_get($lsub,'code',''),'subject_description'=>ascb_get($lsub,'description',''),'units'=>ascb_get($lsub,'units',''),'grade'=>ascb_get($lsub,'grade',''));
          $first=false;
        }
      } else {
        $rows[]=$base+array('subject_code'=>'','subject_description'=>'','units'=>'','grade'=>'');
      }
    } else {
      $rows[]=$base+array('subject_code'=>'','subject_description'=>'','units'=>'','grade'=>'');
    }
  }
}

$filename='ASCB_'.preg_replace('/[^A-Za-z0-9_-]+/','_',$dep['code']).'_'.($sy?:'ALL_SY').'_'.($term?preg_replace('/\s+/','_',$term):'ALL_TERMS').'_'.date('Y-m-d').'.xls';
header('Content-Type: application/vnd.ms-excel; charset=UTF-8');header('Content-Disposition: attachment; filename="'.$filename.'"');header('Cache-Control: max-age=0');
function x($v){return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
echo "\xEF\xBB\xBF";echo '<html><head><meta charset="UTF-8"></head><body><h2>ASCB Department Student Data Export</h2><p><b>Department:</b> '.x($dep['name']).' ('.x($dep['code']).')</p><p><b>School Year:</b> '.x($sy?:'All').' &nbsp; <b>Term:</b> '.x($term?:'All').'</p><table border="1"><thead><tr>';
$heads=array('Student ID','Student Name','Student Type','Program Code','Program','Major','Year Level','Term','School Year','Subject Code','Subject Description','Units','Grade');foreach($heads as $h)echo '<th>'.x($h).'</th>';echo '</tr></thead><tbody>';
foreach($rows as $r){echo '<tr>';foreach(array('student_id','student_name','student_type','program_code','course_name','major','year_level','trimester','school_year','subject_code','subject_description','units','grade') as $k)echo '<td>'.x($r[$k]).'</td>';echo '</tr>';}
if(!$rows){
  $pc=$pdo->prepare("SELECT COUNT(*) FROM programs WHERE department_id=?");$pc->execute(array($departmentId));$programCount=(int)$pc->fetchColumn();
  echo '<tr><td colspan="13"><b>No student records found.</b> '.x($programCount ? 'The Department has assigned Programs, but no matching active enrollment records were found for the selected filters.' : 'No Programs are assigned to this Department yet. Assign the Programs used by your enrolled students, then export again.').'</td></tr>';
}
echo '</tbody></table></body></html>';
try{$b=$pdo->prepare("INSERT INTO backup_history(backup_type,department_id,school_year,term_label,filename,created_by_user_id) VALUES('DEPARTMENT_EXCEL',?,?,?,?,?)");$b->execute(array($departmentId,$sy?:null,$term?:null,$filename,(int)ascb_get($ascbUser,'id',0)));ascb_log_activity($pdo,$ascbUser,'DEPARTMENT_EXCEL_EXPORT','department',$dep['name'],$filename);}catch(Exception $e){}

