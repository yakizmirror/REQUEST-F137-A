<?php
require_once __DIR__ . '/../includes/auth_check.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';
$role=ascb_get($ascbUser,'role','');if(!in_array($role,array('UNIT HEAD','SCHOOL REGISTRAR'),true)){http_response_code(403);exit('Forbidden');}
$filename='ASCB_FULL_BACKUP_'.date('Y-m-d_His').'.sql';header('Content-Type: application/sql; charset=UTF-8');header('Content-Disposition: attachment; filename="'.$filename.'"');
echo "-- ASCB Registrar Full Database Backup\n-- Generated: ".date('c')."\nSET FOREIGN_KEY_CHECKS=0;\n\n";
$tables=$pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
foreach($tables as $table){$safe=str_replace('`','``',$table);$cr=$pdo->query("SHOW CREATE TABLE `$safe`")->fetch(PDO::FETCH_NUM);echo "DROP TABLE IF EXISTS `$safe`;\n".$cr[1].";\n\n";$rows=$pdo->query("SELECT * FROM `$safe`");while($r=$rows->fetch(PDO::FETCH_ASSOC)){if(!$r)continue;$cols=array_map(function($c){return '`'.str_replace('`','``',$c).'`';},array_keys($r));$vals=array_map(function($v)use($pdo){return $v===null?'NULL':$pdo->quote((string)$v);},array_values($r));echo 'INSERT INTO `'.$safe.'` ('.implode(',',$cols).') VALUES ('.implode(',',$vals).');' . "\n";}echo "\n";}
echo "SET FOREIGN_KEY_CHECKS=1;\n";try{$b=$pdo->prepare("INSERT INTO backup_history(backup_type,filename,created_by_user_id) VALUES('FULL_SQL',?,?)");$b->execute(array($filename,(int)ascb_get($ascbUser,'id',0)));ascb_log_activity($pdo,$ascbUser,'FULL_DATABASE_BACKUP','database','ascb_registrar',$filename);}catch(Exception $e){}
