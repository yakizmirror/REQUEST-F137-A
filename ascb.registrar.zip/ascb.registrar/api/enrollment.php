<?php
/* =========================================================
   API: ENROLLMENT
   ---------------------------------------------------------
   Bawat entry = basic info ng estudyante: Surname, Given Name,
   Middle Name, Sex, Student Type (Regular/Transferee/Irregular),
   Birth Date, Address, Mobile Number, Previous
   School (Junior High) at Previous School (Senior High),
   Course/Program (+ Major kung meron), Year Level, Trimester,
   at ang mga Subjects na na-load mula sa prospectus (script.js).

   Bawat estudyante ay may "student_id" (auto-generated, hal.
   "2026-00001"): taon ng UNANG enrollment niya + 5-digit
   running number. Pareho ito sa lahat ng term/record niya
   (ginagamit ng "New Term" ang student_id ng lumang record
   sa halip na gumawa ng bago), at hindi na nagbabago sa
   "Update"/edit.

   APPROVAL WORKFLOW ("status"):
     - Kapag ADMIN STAFF ang nag-create/update ng record, awtomatikong
       "pending" ito — kailangan pang aprubahan ng UNIT HEAD.
     - Kapag UNIT HEAD o SCHOOL REGISTRAR ang nag-create/update,
       awtomatikong "approved" agad.
     - Tanging UNIT HEAD lang (permission 'approve_enrollment') ang
       pwedeng gumamit ng action=approve / action=reject.

   GET  -> ibinabalik ang listahan ng mga enrollee (pinaka-bago
           muna). Params: q (search text, optional — humahanap
           sa surname/first name/middle name/course/major/mga
           previous school/student ID/mobile number), status
           (optional — "pending"/"approved", o "rejected" kapag
           scope=archived), scope (optional — "active" [default],
           "rejected", o "archived"; tingnan ang REJECTED /
           ARCHIVE sa ibaba).

   POST -> JSON body. Ang "action" field ang nagsasabi kung
           create / update / delete / restore / approve / reject:

           action=create : surname, firstName (required);
                            middleName, sex, studentType, birthDate, address,
                            mobileNumber, prevSchoolJuniorHs,
                            prevSchoolSeniorHs, programCode, course,
                            major, yearLevel, trimester, schoolYear,
                            subjects (array ng {code, description,
                            units, grade}) (optional);
                            studentId (optional — ipasa lang ito
                            kapag "New Term" ng ISANG estudyanteng
                            meron nang student_id, para hindi
                            gumawa ng bago)
           action=update : id (required) + enrollment fields gaya
                            ng create (student_id ay HINDI nababago dito) —
                            UNIT HEAD lang. Grades are NOT updated here.
                            (permission 'update_enrollment')
           action=delete : id (required), reason (optional).
                            Kung HINDI pa naka-archive ang record,
                            ini-ARCHIVE lang ito (hindi tuluyang
                            binubura). Kung NAKA-ARCHIVE NA ito,
                            saka lang ito TULUYANG binubura sa
                            database (permanent delete).
           action=restore: id (required) — ibinabalik mula sa
                            Archive papunta sa normal na listahan.
           action=approve: id (required) — UNIT HEAD lang
           action=reject : id (required), remarks (optional) —
                            UNIT HEAD lang

   REJECTED / ARCHIVE:
     - Kapag "rejected" na ang isang record, HINDI na ito lumalabas
       sa Grade Evaluation o sa normal na Enrollment / New Term
       list (scope=active) — makikita na lang ito sa "Rejected
       Students" menu (scope=rejected), hanggang aksyunan pa
       (Update, o Delete/Archive).
     - Kapag "na-delete" ang isang enrollee kahit saan (Enrollment,
       New Term, o Rejected Students), hindi ito tuluyang nabubura
       sa database — inililipat lang ito sa "Archive" menu
       (scope=archived), para sa mga estudyanteng nag-drop o
       tinanggal sa listahan.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$method = $_SERVER['REQUEST_METHOD'];


/* Bumubuo ng bagong Student ID: taon (ngayon) + 5-digit running
   number, hal. "2026-00001". Kinukuha ang pinakamalaking number
   na ginamit na para sa taon na iyon (kahit may na-delete nang
   record) para hindi kailanman magkapareho ang dalawang estudyante. */
function ascb_enrollment_generate_student_id($pdo) {
    $year = date('Y');
    $prefix = $year . '-';

    $stmt = $pdo->prepare(
        "SELECT student_id FROM enrollees
          WHERE student_id LIKE ?
          ORDER BY CAST(SUBSTRING(student_id, 6) AS UNSIGNED) DESC
          LIMIT 1"
    );
    $stmt->execute(array($prefix . '%'));
    $last = $stmt->fetchColumn();

    $next = 1;
    if ($last && preg_match('/^' . preg_quote($prefix, '/') . '(\d+)$/', $last, $m)) {
        $next = ((int) $m[1]) + 1;
    }

    return $prefix . str_pad($next, 5, '0', STR_PAD_LEFT);
}

/* Kung "New Term" ito (may ipinasang studentId), i-verify muna na
   totoong existing student ID ito bago gamitin — para hindi basta
   makakapasok ng kahit anong string bilang student_id. Kung wala
   o hindi valid, gagawa na lang ng bago (parang bagong estudyante). */
function ascb_enrollment_resolve_student_id($pdo, $providedStudentId) {
    $providedStudentId = trim((string) $providedStudentId);

    if ($providedStudentId !== '') {
        $check = $pdo->prepare("SELECT COUNT(*) FROM enrollees WHERE student_id = ?");
        $check->execute(array($providedStudentId));
        if ((int) $check->fetchColumn() > 0) {
            return $providedStudentId;
        }
    }

    return ascb_enrollment_generate_student_id($pdo);
}

/* Kung ADMIN STAFF ang nag-input, dapat "pending" muna ito
   (naghihintay ng approval ng UNIT HEAD). Ang UNIT HEAD at
   SCHOOL REGISTRAR ay awtomatikong "approved" agad ang input. */
function ascb_enrollment_default_status($role) {
    return ($role === 'ADMIN STAFF') ? 'pending' : 'approved';
}

/* Keep the normalized subject table synchronized with Enrollment.
   Grades are deliberately untouched here. Existing subject IDs are
   reused so a grade never disappears when an enrollment is edited. */
function ascb_sync_enrollment_subjects($pdo, $enrollmentId, $subjects) {
    $find = $pdo->prepare("SELECT id FROM enrollment_subjects WHERE enrollment_id = ? AND ((course_code IS NOT NULL AND course_code = ?) OR (course_code IS NULL AND ? = '')) AND description = ? LIMIT 1");
    $insert = $pdo->prepare("INSERT INTO enrollment_subjects (enrollment_id, course_code, description, units) VALUES (?, ?, ?, ?)");
    $update = $pdo->prepare("UPDATE enrollment_subjects SET units = ?, description = ? WHERE id = ?");
    foreach ((array)$subjects as $subject) {
        $code = trim((string)($subject['code'] ?? ''));
        $description = trim((string)($subject['description'] ?? ''));
        if ($code === '' && $description === '') continue;
        if ($description === '') $description = '(No description)';
        $units = is_numeric($subject['units'] ?? null) ? (float)$subject['units'] : 0;
        $find->execute([(int)$enrollmentId, $code, $code, $description]);
        $id = $find->fetchColumn();
        if ($id) $update->execute([$units, $description, (int)$id]);
        else $insert->execute([(int)$enrollmentId, $code !== '' ? $code : null, $description, $units]);
    }
}


/* Resolve and snapshot the Department attached to the selected Program.
   The enrollment keeps this value so historical Department exports remain
   stable even if a Program is later moved to another Department. */
function ascb_enrollment_department_id($pdo, $programCode) {
    $programCode = trim((string)$programCode);
    if ($programCode === '' || !ascb_has_column($pdo, 'enrollees', 'department_id')) return null;
    $st = $pdo->prepare("SELECT department_id FROM programs WHERE UPPER(TRIM(code))=UPPER(TRIM(?)) LIMIT 1");
    $st->execute(array($programCode));
    $v = $st->fetchColumn();
    return ($v !== false && $v !== null) ? (int)$v : null;
}

/* ========================================== GET — LIST */

if ($method === 'GET') {

    $q = trim(ascb_get($_GET, 'q', ''));
    $statusFilter = trim(ascb_get($_GET, 'status', ''));

    // "scope" ang nagtatakda kung ANONG grupo ng enrollees ang
    // ibabalik ng listahan na ito:
    //   'active'   (default) — hindi pa na-archive AT hindi "rejected".
    //                Ito ang ginagamit ng Enrollment / New Term list
    //                at ng Grade Evaluation — kaya AWTOMATIKONG hindi
    //                lumalabas dito (at sa Grade Evaluation) ang mga
    //                "rejected" na record.
    //   'rejected' — hindi pa na-archive AT "rejected" ang status.
    //                Ginagamit ng bagong "Rejected Students" menu.
    //   'archived' — na-archive na (dating "delete" na ginawang
    //                archive na lang sa halip na tunay na tanggalin
    //                sa database). Ginagamit ng bagong "Archive" menu
    //                (mga estudyanteng nag-drop o tinanggal sa listahan).
    $scope = trim(ascb_get($_GET, 'scope', 'active'));
    if (!in_array($scope, array('active', 'rejected', 'archived'), true)) {
        $scope = 'active';
    }

    $sql = "SELECT e.*, u.display_name AS enrolled_by_name,
                   a.display_name AS approved_by_name,
                   ar.display_name AS archived_by_name
            FROM enrollees e
            LEFT JOIN users u ON u.id = e.enrolled_by_user_id
            LEFT JOIN users a ON a.id = e.approved_by_user_id
            LEFT JOIN users ar ON ar.id = e.archived_by_user_id";
    $params = array();
    $where = array();

    // DEAN: read-only at sariling Department lamang.
    if (ascb_get($ascbUser, 'role', '') === 'DEAN') {
        $deptId = ascb_require_dean_department($pdo, $ascbUser);
        $where[] = "e.department_id = ?";
        $params[] = $deptId;
    }

    if ($q !== '') {
        $qNorm = str_replace(array("\xC2\xA0", "\t", "\r", "\n"), ' ', $q);
        $qNorm = preg_replace('/\s+/', ' ', $qNorm);
        $qNorm = trim($qNorm);

        $qEscaped = str_replace(array('\\', '%', '_'), array('\\\\', '\%', '\_'), $qNorm);
        $like = '%' . $qEscaped . '%';

        $where[] = "(TRIM(e.surname) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.first_name) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.middle_name) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.student_id) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.mobile_number) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.prev_school_junior_hs) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.prev_school_senior_hs) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.course) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(e.major) LIKE ? ESCAPE '\\\\')";
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
        $params[] = $like;
    }

    if ($scope === 'archived') {
        $where[] = "e.archived_at IS NOT NULL";
        if (in_array($statusFilter, array('pending', 'approved', 'rejected'), true)) {
            $where[] = "e.status = ?";
            $params[] = $statusFilter;
        }
    } elseif ($scope === 'rejected') {
        $where[] = "e.archived_at IS NULL";
        $where[] = "e.status = 'rejected'";
    } else { // 'active'
        $where[] = "e.archived_at IS NULL";
        $where[] = "e.status != 'rejected'";
        if (in_array($statusFilter, array('pending', 'approved'), true)) {
            $where[] = "e.status = ?";
            $params[] = $statusFilter;
        }
    }

    if (!empty($where)) {
        $sql .= " WHERE " . implode(' AND ', $where);
    }

    $sql .= " ORDER BY e.created_at DESC, e.id DESC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        foreach ($rows as &$row) {
            $decodedSubjects = json_decode(ascb_get($row, 'subjects_json', ''), true);
            $row['subjects'] = is_array($decodedSubjects) ? $decodedSubjects : array();
            unset($row['subjects_json']);
        }
        unset($row);
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'May error sa pagkuha ng listahan mula sa database.'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(array('ok' => true, 'rows' => $rows, 'count' => count($rows)), JSON_UNESCAPED_UNICODE);
    exit;
}


/* ========================================== POST — CREATE / UPDATE / DELETE */

if ($method === 'POST') {

    if (ascb_get($ascbUser, 'role', '') === 'DEAN') { http_response_code(403); echo json_encode(array('ok'=>false,'error'=>'Read-only ang Dean account. Hindi ito maaaring magbago ng official enrollment records.')); exit; }

    $decoded = json_decode(file_get_contents('php://input'), true);
    $input = is_array($decoded) ? $decoded : array();
    $action = ascb_get($input, 'action', 'create');

    /* ----------------------------------------- CREATE / UPDATE */
    if ($action === 'create' || $action === 'update') {

        // Update ng enrollment record (student/term/subject assignment only).
        // Ang grades ay hiwalay nang minamanage sa api/grades.php.
        // ay UNIT HEAD lang — hindi na dapat ito magawa ng ADMIN
        // STAFF. Ang pag-enroll ng BAGONG estudyante (create) at
        // New Term (create rin, may studentId lang) ay bukas pa rin.
        if ($action === 'update' && !ascb_can(ascb_get($ascbUser, 'role', ''), 'update_enrollment')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'Wala kang access na mag-update ng enrollment record. Unit Head lang ang pwede dito.'));
            exit;
        }

        $surname            = trim(ascb_get($input, 'surname', ''));
        $firstName          = trim(ascb_get($input, 'firstName', ''));
        $middleName         = trim(ascb_get($input, 'middleName', ''));
        $sex                = trim(ascb_get($input, 'sex', ''));
        $studentType        = trim(ascb_get($input, 'studentType', ''));
        $birthDate          = trim(ascb_get($input, 'birthDate', ''));
        $address            = trim(ascb_get($input, 'address', ''));
        $mobileNumber       = trim(ascb_get($input, 'mobileNumber', ''));
        $prevSchoolJuniorHs = trim(ascb_get($input, 'prevSchoolJuniorHs', ''));
        $prevSchoolSeniorHs = trim(ascb_get($input, 'prevSchoolSeniorHs', ''));
        $programCode        = trim(ascb_get($input, 'programCode', ''));
        $course             = trim(ascb_get($input, 'course', ''));
        $major              = trim(ascb_get($input, 'major', ''));
        $yearLevel          = trim(ascb_get($input, 'yearLevel', ''));
        $trimester          = trim(ascb_get($input, 'trimester', ''));
        $schoolYear         = trim(ascb_get($input, 'schoolYear', ''));

        $subjectsInput = ascb_get($input, 'subjects', array());
        $subjects = array();
        if (is_array($subjectsInput)) {
            foreach ($subjectsInput as $s) {
                $code = trim(ascb_get($s, 'code', ''));
                $description = trim(ascb_get($s, 'description', ''));
                if ($code === '' && $description === '') {
                    continue;
                }
                $subjects[] = array(
                    'code'        => $code,
                    'description' => $description,
                    'units'       => (isset($s['units']) && $s['units'] !== '') ? $s['units'] : 0,
                );
            }
        }
        $subjectsJson = json_encode($subjects, JSON_UNESCAPED_UNICODE);

        if ($surname === '' || $firstName === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng Surname at Given Name.'));
            exit;
        }

        if ($mobileNumber !== '' && ascb_text_too_long($mobileNumber, 20)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Masyadong mahaba ang Mobile Number (max 20 characters).'));
            exit;
        }

        if ($sex !== '' && !in_array($sex, array('Male', 'Female'), true)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid Sex.'));
            exit;
        }

        if ($studentType !== '' && !in_array($studentType, array('Regular', 'Transferee', 'Irregular'), true)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid Student Type.'));
            exit;
        }

        // birth_date: itago lang kung valid na petsa, blangko/NULL kung wala o hindi valid
        $birthDateValue = null;
        if ($birthDate !== '') {
            $d = DateTime::createFromFormat('Y-m-d', $birthDate);
            if ($d && $d->format('Y-m-d') === $birthDate) {
                $birthDateValue = $birthDate;
            }
        }

        if ($action === 'create') {

            $studentId = ascb_enrollment_resolve_student_id($pdo, ascb_get($input, 'studentId', ''));

            $status = ascb_enrollment_default_status(ascb_get($ascbUser, 'role', ''));
            $approvedByUserId = ($status === 'approved') ? ascb_get($ascbUser, 'id', null) : null;
            $approvedAt = ($status === 'approved') ? date('Y-m-d H:i:s') : null;

            $stmt = $pdo->prepare(
                "INSERT INTO enrollees
                    (student_id, surname, first_name, middle_name, sex, student_type, birth_date, address, mobile_number,
                     prev_school_junior_hs, prev_school_senior_hs,
                     program_code, department_id, course, major, year_level, trimester, school_year, subjects_json,
                     enrolled_by_user_id, status, approved_by_user_id, approved_at)
                 VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)"
            );
            $stmt->execute(array(
                $studentId,
                $surname,
                $firstName,
                $middleName !== '' ? $middleName : null,
                $sex !== '' ? $sex : null,
                $studentType !== '' ? $studentType : null,
                $birthDateValue,
                $address !== '' ? $address : null,
                $mobileNumber !== '' ? $mobileNumber : null,
                $prevSchoolJuniorHs !== '' ? $prevSchoolJuniorHs : null,
                $prevSchoolSeniorHs !== '' ? $prevSchoolSeniorHs : null,
                $programCode !== '' ? $programCode : null,
                ascb_enrollment_department_id($pdo, $programCode),
                $course !== '' ? $course : null,
                $major !== '' ? $major : null,
                $yearLevel !== '' ? $yearLevel : null,
                $trimester !== '' ? $trimester : null,
                $schoolYear !== '' ? $schoolYear : null,
                $subjectsJson,
                ascb_get($ascbUser, 'id', null),
                $status,
                $approvedByUserId,
                $approvedAt,
            ));

            $newId = $pdo->lastInsertId();
            ascb_sync_enrollment_subjects($pdo, $newId, $subjects);

            ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_ADD', 'enrollee', $surname . ', ' . $firstName . ' (' . $studentId . ')',
                ($status === 'pending') ? 'Naghihintay ng approval ng Unit Head.' : null);

            echo json_encode(array('ok' => true, 'id' => $newId, 'studentId' => $studentId, 'status' => $status));
            exit;

        } else {

            $id = (int) ascb_get($input, 'id', 0);
            if ($id <= 0) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
                exit;
            }

            $check = $pdo->prepare("SELECT id FROM enrollees WHERE id = ?");
            $check->execute(array($id));
            if (!$check->fetch()) {
                http_response_code(404);
                echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang enrollee.'));
                exit;
            }

            // Anumang pag-edit ng enrollment ay kinukuha muli ang status: kung ADMIN
            // STAFF ang nag-edit, babalik itong "pending" (kailangan
            // ulit ng approval ng UNIT HEAD, kahit approved na ito
            // dati) — kung UNIT HEAD o SCHOOL REGISTRAR, "approved" agad.
            $status = ascb_enrollment_default_status(ascb_get($ascbUser, 'role', ''));
            $approvedByUserId = ($status === 'approved') ? ascb_get($ascbUser, 'id', null) : null;
            $approvedAt = ($status === 'approved') ? date('Y-m-d H:i:s') : null;

            $stmt = $pdo->prepare(
                "UPDATE enrollees
                    SET surname = ?, first_name = ?, middle_name = ?, sex = ?, student_type = ?, birth_date = ?,
                        address = ?, mobile_number = ?, prev_school_junior_hs = ?, prev_school_senior_hs = ?,
                        program_code = ?, department_id = ?, course = ?, major = ?, year_level = ?,
                        trimester = ?, school_year = ?, subjects_json = ?,
                        status = ?, approved_by_user_id = ?, approved_at = ?, approval_remarks = NULL
                  WHERE id = ?"
            );
            $stmt->execute(array(
                $surname,
                $firstName,
                $middleName !== '' ? $middleName : null,
                $sex !== '' ? $sex : null,
                $studentType !== '' ? $studentType : null,
                $birthDateValue,
                $address !== '' ? $address : null,
                $mobileNumber !== '' ? $mobileNumber : null,
                $prevSchoolJuniorHs !== '' ? $prevSchoolJuniorHs : null,
                $prevSchoolSeniorHs !== '' ? $prevSchoolSeniorHs : null,
                $programCode !== '' ? $programCode : null,
                ascb_enrollment_department_id($pdo, $programCode),
                $course !== '' ? $course : null,
                $major !== '' ? $major : null,
                $yearLevel !== '' ? $yearLevel : null,
                $trimester !== '' ? $trimester : null,
                $schoolYear !== '' ? $schoolYear : null,
                $subjectsJson,
                $status,
                $approvedByUserId,
                $approvedAt,
                $id,
            ));
            ascb_sync_enrollment_subjects($pdo, $id, $subjects);

            ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_UPDATE', 'enrollee', $surname . ', ' . $firstName,
                ($status === 'pending') ? 'Naibalik sa "pending" — naghihintay ulit ng approval ng Unit Head.' : null);

            echo json_encode(array('ok' => true, 'status' => $status));
            exit;
        }
    }

    /* ----------------------------------------- APPROVE / REJECT */
    if ($action === 'approve' || $action === 'reject') {

        if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'approve_enrollment')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'Wala kang access na mag-approve/reject ng enrollment record. Unit Head lang ang pwede dito.'));
            exit;
        }

        $id = (int) ascb_get($input, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang enrollee.'));
            exit;
        }

        $remarks = trim(ascb_get($input, 'remarks', ''));
        if ($remarks !== '' && ascb_text_too_long($remarks, 255)) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Masyadong mahaba ang remarks (max 255 characters).'));
            exit;
        }

        $newStatus = ($action === 'approve') ? 'approved' : 'rejected';

        $stmt = $pdo->prepare(
            "UPDATE enrollees
                SET status = ?, approved_by_user_id = ?, approved_at = ?, approval_remarks = ?
              WHERE id = ?"
        );
        $stmt->execute(array(
            $newStatus,
            ascb_get($ascbUser, 'id', null),
            date('Y-m-d H:i:s'),
            $remarks !== '' ? $remarks : null,
            $id,
        ));

        ascb_log_activity(
            $pdo, $ascbUser,
            ($action === 'approve') ? 'ENROLLEE_APPROVE' : 'ENROLLEE_REJECT',
            'enrollee',
            $existing['surname'] . ', ' . $existing['first_name'] . ' (' . $existing['student_id'] . ')',
            $remarks !== '' ? $remarks : null
        );

        echo json_encode(array('ok' => true, 'status' => $newStatus));
        exit;
    }

    /* ----------------------------------------- DELETE
       ("Delete" mula sa Enrollment / New Term / Rejected Students
       list) — HINDI agad tuluyang binubura sa database ang record.
       Ang una itong "Delete" ay nag-a-ARCHIVE lang (para sa mga
       estudyanteng nag-drop o tinanggal sa listahan — makikita pa
       rin sila sa "Archive" menu). Tanging kapag NAKA-ARCHIVE NA
       ang record at "Delete" ulit ito (mula mismo sa Archive view,
       gaya ng "Delete Permanently") saka lang ito TULUYANG
       binubura sa database. */
    if ($action === 'delete') {

        if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_lookups')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'Wala kang access na mag-delete ng enrollment record.'));
            exit;
        }

        $id = (int) ascb_get($input, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang enrollee.'));
            exit;
        }

        $alreadyArchived = !empty($existing['archived_at']);

        if (!$alreadyArchived) {

            $reason = trim(ascb_get($input, 'reason', ''));
            if ($reason !== '' && ascb_text_too_long($reason, 255)) {
                http_response_code(400);
                echo json_encode(array('ok' => false, 'error' => 'Masyadong mahaba ang dahilan (max 255 characters).'));
                exit;
            }

            $stmt = $pdo->prepare(
                "UPDATE enrollees
                    SET archived_at = ?, archived_by_user_id = ?, archive_reason = ?
                  WHERE id = ?"
            );
            $stmt->execute(array(
                date('Y-m-d H:i:s'),
                ascb_get($ascbUser, 'id', null),
                $reason !== '' ? $reason : null,
                $id,
            ));

            ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_ARCHIVE', 'enrollee',
                $existing['surname'] . ', ' . $existing['first_name'] . ' (' . $existing['student_id'] . ')',
                $reason !== '' ? $reason : null);

            echo json_encode(array('ok' => true, 'archived' => true));
            exit;
        }

        // Naka-archive na ito — ngayon lang tuluyang mabubura sa database.
        $stmt = $pdo->prepare("DELETE FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));

        ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_DELETE', 'enrollee', $existing['surname'] . ', ' . $existing['first_name']);

        echo json_encode(array('ok' => true, 'archived' => false));
        exit;
    }

    /* ----------------------------------------- RESTORE
       Ibinabalik ang isang naka-archive na record sa normal na
       listahan (Enrollment / New Term, o Rejected Students kung
       "rejected" pa rin ang status nito) — binubura lang ang
       archived_at / archived_by_user_id / archive_reason, hindi
       nagbabago ang status/subjects/atbp. */
    if ($action === 'restore') {

        if (!ascb_can(ascb_get($ascbUser, 'role', ''), 'delete_lookups')) {
            http_response_code(403);
            echo json_encode(array('ok' => false, 'error' => 'Wala kang access na mag-restore ng naka-archive na record.'));
            exit;
        }

        $id = (int) ascb_get($input, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM enrollees WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang enrollee.'));
            exit;
        }

        $stmt = $pdo->prepare(
            "UPDATE enrollees
                SET archived_at = NULL, archived_by_user_id = NULL, archive_reason = NULL
              WHERE id = ?"
        );
        $stmt->execute(array($id));

        ascb_log_activity($pdo, $ascbUser, 'ENROLLEE_RESTORE', 'enrollee',
            $existing['surname'] . ', ' . $existing['first_name'] . ' (' . $existing['student_id'] . ')');

        echo json_encode(array('ok' => true));
        exit;
    }

    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
    exit;
}


/* ========================================== OTHER METHODS */

http_response_code(405);
echo json_encode(array('ok' => false, 'error' => 'Method not allowed.'));
