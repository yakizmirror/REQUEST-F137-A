<?php
/* =========================================================
   API: APPROVED SO
   ---------------------------------------------------------
   Bawat entry = pangalan + isang PDF file. Pwedeng i-add,
   i-update (palitan ang pangalan at/o ang PDF), at i-delete.

   GET  -> ibinabalik ang listahan ng mga Approved SO entries
           (pinaka-bago muna).

           Params: q (search text, optional)
                   Walang limit — palaging ibabalik lahat ng
                   tugma sa database.

   POST -> multipart/form-data (HINDI JSON, dahil may
           kasamang file upload). Ang "action" field ang
           nagsasabi kung create / update / delete:

           action=create : fields name, file (1 PDF, required)
           action=update : fields id, name, file (optional —
                            kung may bagong file, papalitan
                            ang luma)
           action=delete : field id
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$UPLOAD_DIR = __DIR__ . '/../uploads/approved_so/';
if (!is_dir($UPLOAD_DIR)) {
    @mkdir($UPLOAD_DIR, 0755, true);
}
if (!is_dir($UPLOAD_DIR) || !is_writable($UPLOAD_DIR)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Hindi writable ang upload folder sa server. I-check ang deployment folder permissions.'));
    exit;
}

$maxSizeBytes = ASCB_MAX_UPLOAD_MB * 1024 * 1024; // configurable; default 25 MB

$method = $_SERVER['REQUEST_METHOD'];


/* =========================================================
   Tulong na function: i-validate + i-save ang isang na-upload
   na PDF file. Ibinabalik ang array(original, stored, size)
   kung tagumpay, o direktang nagpapadala ng JSON error at
   nag-e-exit kung mayroong problema.
   ========================================================= */
function ascbSoHandleUpload($fieldName, $UPLOAD_DIR, $maxSizeBytes) {

    if (empty($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // walang na-upload na file
    }

    if ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        $uploadErrCode = $_FILES[$fieldName]['error'];
        $uploadErrMsgs = array(
            UPLOAD_ERR_INI_SIZE   => 'Lumagpas sa upload_max_filesize ng server (php.ini). Kailangang taasan ito ng system admin.',
            UPLOAD_ERR_FORM_SIZE  => 'Lumagpas sa max file size na tinakda sa form.',
            UPLOAD_ERR_PARTIAL    => 'Hindi natapos ang pag-upload ng file (na-interrupt sa gitna, baka slow connection o na-timeout).',
            UPLOAD_ERR_NO_TMP_DIR => 'Walang temporary folder sa server para sa upload.',
            UPLOAD_ERR_CANT_WRITE => 'Hindi ma-isulat ang file sa disk ng server (baka permission issue).',
            UPLOAD_ERR_EXTENSION  => 'Hinarang ang upload ng isang PHP extension sa server.',
        );
        $uploadErrText = isset($uploadErrMsgs[$uploadErrCode])
            ? $uploadErrMsgs[$uploadErrCode]
            : 'Hindi kilalang error (code ' . $uploadErrCode . ').';

        http_response_code(400);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'May error sa pag-upload ng file (' . $_FILES[$fieldName]['name'] . '): ' . $uploadErrText,
        ));
        exit;
    }

    $tmpPath      = $_FILES[$fieldName]['tmp_name'];
    $originalName = $_FILES[$fieldName]['name'];
    $size         = $_FILES[$fieldName]['size'];

    if ($size > $maxSizeBytes) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => $originalName . ' ay masyadong malaki (max ' . ASCB_MAX_UPLOAD_MB . 'MB).'));
        exit;
    }

    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    $mime = '';
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $tmpPath);
            finfo_close($finfo);
        }
    }

    if ($ext !== 'pdf' || ($mime !== '' && $mime !== 'application/pdf')) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => $originalName . ' ay hindi PDF file.'));
        exit;
    }

    $storedName  = 'so_' . ascb_random_token(16) . '.pdf';
    $destination = $UPLOAD_DIR . $storedName;

    if (!move_uploaded_file($tmpPath, $destination)) {
        http_response_code(500);
        echo json_encode(array('ok' => false, 'error' => 'Hindi na-save ang ' . $originalName . '.'));
        exit;
    }

    return array('original' => $originalName, 'stored' => $storedName, 'size' => (int) $size);
}


/* ========================================== GET — LIST */

if ($method === 'GET') {

    $q = trim(ascb_get($_GET, 'q', ''));

    /* WALANG LIMIT — palaging ibabalik LAHAT ng tugma sa
       database, kahit may ipasang ?limit= sa request (hindi
       na ito pinapansin, dati'y default sa 500 ang frontend
       kaya laging naputol ang search results doon). */

    $sql = "SELECT s.*, u.display_name AS uploaded_by_name
            FROM approved_so s
            LEFT JOIN users u ON u.id = s.uploaded_by_user_id";
    $params = array();

    if ($q !== '') {
        // i-normalize sa PHP side ang search text (dito lang,
        // safe ito kahit anong DB version): alisin ang
        // non-breaking space / tabs / newlines, gawing regular
        // space, tapos i-collapse ang paulit-ulit na space.
        $qNorm = str_replace(array("\xC2\xA0", "\t", "\r", "\n"), ' ', $q);
        $qNorm = preg_replace('/\s+/', ' ', $qNorm);
        $qNorm = trim($qNorm);

        // i-escape ang LIKE wildcards (% at _) para hindi sila
        // mabasa bilang wildcard kung na-type ng user
        $qEscaped = str_replace(array('\\', '%', '_'), array('\\\\', '\%', '\_'), $qNorm);

        // hanapin sa PANGALAN ng entry AT sa ORIGINAL FILENAME
        // ng na-upload na PDF, para lahat ng nasa database
        // ma-search — dati'y sa "name" lang tumitignan.
        // Ginamit ang TRIM() lang sa column side (simple at
        // compatible sa lahat ng MySQL/MariaDB version, hindi
        // gaya ng CHAR(... USING charset) na pwedeng mag-error
        // depende sa DB config).
        $sql .= " WHERE (TRIM(s.name) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(s.original_filename) LIKE ? ESCAPE '\\\\')";
        $params[] = '%' . $qEscaped . '%';
        $params[] = '%' . $qEscaped . '%';
    }

    $sql .= " ORDER BY s.created_at DESC, s.id DESC";

    // walang LIMIT dito — sinasadya, para palaging kumpleto
    // ang listahan kahit ilang libo na ang laman ng database

    /* May try/catch dito para kung magkaroon man ng SQL error
       (hal. dahil sa hindi compatible na function, o problema
       sa column names), makikita natin ang totoong error
       message sa halip na tahimik na mag-fail o magbalik ng
       kulang/walang laman na listahan. */
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'May error sa pagkuha ng listahan mula sa database.'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(array('ok' => true, 'rows' => $rows, 'count' => count($rows)), JSON_UNESCAPED_UNICODE);
    exit;
}


/* ========================================== POST — CREATE / UPDATE / DELETE */

if ($method === 'POST') {

    $action = ascb_get($_POST, 'action', 'create');

    /* ----------------------------------------- CREATE */
    if ($action === 'create') {

        $name = trim(ascb_get($_POST, 'name', ''));
        if ($name === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng pangalan.'));
            exit;
        }

        $uploaded = ascbSoHandleUpload('file', $UPLOAD_DIR, $maxSizeBytes);
        if (!$uploaded) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng PDF file.'));
            exit;
        }

        $stmt = $pdo->prepare(
            "INSERT INTO approved_so
                (name, stored_filename, original_filename, filesize_bytes, uploaded_by_user_id)
             VALUES (?,?,?,?,?)"
        );
        $stmt->execute(array(
            $name,
            $uploaded['stored'],
            $uploaded['original'],
            $uploaded['size'],
            ascb_get($ascbUser, 'id', null),
        ));

        echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
        exit;
    }

    /* ----------------------------------------- UPDATE */
    if ($action === 'update') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM approved_so WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang entry.'));
            exit;
        }

        $name = trim(ascb_get($_POST, 'name', ''));
        if ($name === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng pangalan.'));
            exit;
        }

        /* Ang bagong file ay optional — kung wala, panatilihin
           ang luma. Kung may bago, i-validate/i-save muna bago
           galawin ang luma (para safe kung mag-fail). */
        $uploaded = ascbSoHandleUpload('file', $UPLOAD_DIR, $maxSizeBytes);

        if ($uploaded) {
            $stmt = $pdo->prepare(
                "UPDATE approved_so
                    SET name = ?, stored_filename = ?, original_filename = ?, filesize_bytes = ?
                  WHERE id = ?"
            );
            $stmt->execute(array($name, $uploaded['stored'], $uploaded['original'], $uploaded['size'], $id));

            // matagumpay na na-update ang DB — ngayon safe nang tanggalin ang lumang file
            $oldPath = $UPLOAD_DIR . $existing['stored_filename'];
            if (is_file($oldPath)) {
                @unlink($oldPath);
            }
        } else {
            $stmt = $pdo->prepare("UPDATE approved_so SET name = ? WHERE id = ?");
            $stmt->execute(array($name, $id));
        }

        echo json_encode(array('ok' => true));
        exit;
    }

    /* ----------------------------------------- DELETE */
    if ($action === 'delete') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM approved_so WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang entry.'));
            exit;
        }

        $stmt = $pdo->prepare("DELETE FROM approved_so WHERE id = ?");
        $stmt->execute(array($id));

        $path = $UPLOAD_DIR . $existing['stored_filename'];
        if (is_file($path)) {
            @unlink($path);
        }

        echo json_encode(array('ok' => true));
        exit;
    }

    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
    exit;
}


/* ========================================== OTHER METHODS */

http_response_code(405);
echo json_encode(array('ok' => false, 'error' => 'Method not allowed.'));