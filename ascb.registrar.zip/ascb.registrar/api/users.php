<?php
/* =========================================================
   API: USERS (Admin panel — User Management)
   ---------------------------------------------------------
   POST body (JSON), "action" ang nagsasabi kung ano:

     action: "list"
       -> ibinabalik ang listahan ng lahat ng user accounts
          (walang password_hash). Kailangan: manage_users.

     action: "add"
       fields: displayName, role, username (optional, default
       "admin"), preparedByCode (optional), password
       Kailangan: manage_users.

     action: "update"
       fields: id, displayName, role, username, preparedByCode,
       password (optional — kung binigyan, papalitan; kung
       iniwang blangko, hindi na gagalawin)
       Kailangan: manage_users.

     action: "toggle_active"
       fields: id
       Kailangan: manage_users. Hindi pwedeng i-deactivate ang
       sarili mong account, at hindi pwedeng i-deactivate ang
       huling natitirang aktibong UNIT HEAD (safety net para
       hindi ma-lock-out ang lahat sa Admin panel).

     action: "delete"
       fields: id
       Kailangan: manage_users. Hindi pwedeng i-delete ang
       sarili mong account.

     action: "change_password"  (BUKAS SA LAHAT — sariling
       account lang, hindi kailangan ng manage_users)
       fields: currentPassword, newPassword
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/permissions.php';
require_once __DIR__ . '/../includes/activity_log.php';
require_once __DIR__ . '/../config/db.php';

$decoded = json_decode(file_get_contents('php://input'), true);
$input = is_array($decoded) ? $decoded : array();
$action = ascb_get($input, 'action', '');

$myId   = (int) ascb_get($ascbUser, 'id', 0);
$myRole = ascb_get($ascbUser, 'role', '');

$VALID_ROLES = array('ADMIN STAFF', 'UNIT HEAD', 'SCHOOL REGISTRAR', 'DEAN');


/* ---------- self-service: bukas sa LAHAT, hindi kailangan ng manage_users ---------- */

if ($action === 'change_password') {

    $currentPassword = ascb_get($input, 'currentPassword', '');
    $newPassword     = ascb_get($input, 'newPassword', '');

    if ($currentPassword === '' || $newPassword === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Punan ang kasalukuyan at bagong password.'));
        exit;
    }
    if (strlen($newPassword) < 8) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Kailangang hindi bababa sa 8 karakter ang bagong password.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($myId));
    $me = $stmt->fetch();

    if (!$me || !password_verify($currentPassword, $me['password_hash'])) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Mali ang kasalukuyang password.'));
        exit;
    }

    $stmt = $pdo->prepare("UPDATE users SET password_hash = ? WHERE id = ?");
    $stmt->execute(array(password_hash($newPassword, PASSWORD_DEFAULT), $myId));

    ascb_log_activity($pdo, $ascbUser, 'PASSWORD_CHANGE_SELF', 'user', $me['display_name']);

    echo json_encode(array('ok' => true));
    exit;
}


/* ---------- lahat ng iba pa: kailangan ng manage_users ---------- */

if (!ascb_can($myRole, 'manage_users')) {
    http_response_code(403);
    echo json_encode(array('ok' => false, 'error' => 'Wala kang access sa User Management. UNIT HEAD lang ang pwede dito.'));
    exit;
}

if ($action === 'list') {
    $rows = $pdo->query(
        "SELECT u.id, u.username, u.display_name, u.role, u.prepared_by_code, u.department_id, d.name AS department_name, u.is_active, u.created_at
         FROM users u LEFT JOIN departments d ON d.id=u.department_id ORDER BY display_name"
    )->fetchAll();
    echo json_encode(array('ok' => true, 'users' => $rows), JSON_UNESCAPED_UNICODE);
    exit;
}

if ($action === 'add') {

    $displayName    = trim(ascb_get($input, 'displayName', ''));
    $role           = trim(ascb_get($input, 'role', ''));
    $username       = trim(ascb_get($input, 'username', 'admin'));
    $preparedByCode = trim(ascb_get($input, 'preparedByCode', ''));
    $password       = ascb_get($input, 'password', '');
    $departmentId   = (int) ascb_get($input, 'departmentId', 0);

    if ($username === '') $username = 'admin';

    if ($displayName === '' || $password === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Kailangan ng pangalan at password.'));
        exit;
    }
    if (!in_array($role, $VALID_ROLES, true)) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Hindi valid na role.'));
        exit;
    }
    if ($role === 'DEAN' && $departmentId <= 0) { http_response_code(400); echo json_encode(array('ok'=>false,'error'=>'Pumili ng Department para sa DEAN.')); exit; }
    if (strlen($password) < 8) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Kailangang hindi bababa sa 8 karakter ang password.'));
        exit;
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE display_name = ?");
    $check->execute(array($displayName));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'May existing na account na sa pangalang ito.'));
        exit;
    }

    $stmt = $pdo->prepare(
        "INSERT INTO users (username, password_hash, display_name, role, department_id, prepared_by_code, is_active)
         VALUES (?, ?, ?, ?, ?, ?, 1)"
    );
    $stmt->execute(array(
        $username,
        password_hash($password, PASSWORD_DEFAULT),
        $displayName,
        $role,
        $role === 'DEAN' ? $departmentId : null,
        $preparedByCode !== '' ? $preparedByCode : null,
    ));

    ascb_log_activity($pdo, $ascbUser, 'USER_ADD', 'user', $displayName, 'Role: ' . $role);

    echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
    exit;
}

if ($action === 'update') {

    $id             = (int) ascb_get($input, 'id', 0);
    $displayName    = trim(ascb_get($input, 'displayName', ''));
    $role           = trim(ascb_get($input, 'role', ''));
    $username       = trim(ascb_get($input, 'username', 'admin'));
    $preparedByCode = trim(ascb_get($input, 'preparedByCode', ''));
    $password       = ascb_get($input, 'password', '');
    $departmentId   = (int) ascb_get($input, 'departmentId', 0);

    if ($username === '') $username = 'admin';

    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($id));
    $existing = $stmt->fetch();

    if (!$existing) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang account.'));
        exit;
    }

    if ($displayName === '') {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Kailangan ng pangalan.'));
        exit;
    }
    if (!in_array($role, $VALID_ROLES, true)) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Hindi valid na role.'));
        exit;
    }
    if ($role === 'DEAN' && $departmentId <= 0) { http_response_code(400); echo json_encode(array('ok'=>false,'error'=>'Pumili ng Department para sa DEAN.')); exit; }

    if ($existing['role'] === 'UNIT HEAD' && $role !== 'UNIT HEAD' && !empty($existing['is_active'])) {
        $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'UNIT HEAD' AND is_active = 1 AND id <> ?");
        $countStmt->execute(array($id));
        if ((int) $countStmt->fetch()['c'] < 1) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Hindi pwedeng palitan ang role — ito na ang huling aktibong UNIT HEAD.'));
            exit;
        }
    }

    $check = $pdo->prepare("SELECT id FROM users WHERE display_name = ? AND id <> ?");
    $check->execute(array($displayName, $id));
    if ($check->fetch()) {
        echo json_encode(array('ok' => false, 'error' => 'May ibang account na gumagamit ng pangalang ito.'));
        exit;
    }

    if ($password !== '') {
        if (strlen($password) < 8) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangang hindi bababa sa 8 karakter ang password.'));
            exit;
        }
        $stmt = $pdo->prepare(
            "UPDATE users SET display_name = ?, role = ?, department_id = ?, username = ?, prepared_by_code = ?, password_hash = ? WHERE id = ?"
        );
        $stmt->execute(array(
            $displayName, $role, $role === 'DEAN' ? $departmentId : null, $username,
            $preparedByCode !== '' ? $preparedByCode : null,
            password_hash($password, PASSWORD_DEFAULT),
            $id,
        ));
    } else {
        $stmt = $pdo->prepare(
            "UPDATE users SET display_name = ?, role = ?, department_id = ?, username = ?, prepared_by_code = ? WHERE id = ?"
        );
        $stmt->execute(array(
            $displayName, $role, $role === 'DEAN' ? $departmentId : null, $username,
            $preparedByCode !== '' ? $preparedByCode : null,
            $id,
        ));
    }

    /* Kung nabago natin ang sariling account, i-refresh ang session
       data para tama agad ang makikita sa sidebar (walang kailangang
       mag-re-login). */
    if ($id === $myId) {
        $_SESSION['ascb_user']['displayName'] = $displayName;
        $_SESSION['ascb_user']['role']        = $role;
        $_SESSION['ascb_user']['preparedBy']  = $preparedByCode !== '' ? $preparedByCode : null;
    }

    ascb_log_activity($pdo, $ascbUser, 'USER_UPDATE', 'user', $displayName, 'Role: ' . $role);

    echo json_encode(array('ok' => true));
    exit;
}

if ($action === 'toggle_active') {

    $id = (int) ascb_get($input, 'id', 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
        exit;
    }

    if ($id === $myId) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Hindi mo pwedeng i-deactivate ang sarili mong account.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($id));
    $existing = $stmt->fetch();

    if (!$existing) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang account.'));
        exit;
    }

    $newStatus = $existing['is_active'] ? 0 : 1;

    /* Safety net: kung ito ang huling natitirang AKTIBONG UNIT
       HEAD, huwag payagang i-deactivate — mawawalan ng access
       sa User Management ang lahat. */
    if ($newStatus === 0 && $existing['role'] === 'UNIT HEAD') {
        $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'UNIT HEAD' AND is_active = 1 AND id <> ?");
        $countStmt->execute(array($id));
        $remaining = (int) $countStmt->fetch()['c'];
        if ($remaining < 1) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Hindi pwedeng i-deactivate — ito na ang huling aktibong UNIT HEAD.'));
            exit;
        }
    }

    $stmt = $pdo->prepare("UPDATE users SET is_active = ? WHERE id = ?");
    $stmt->execute(array($newStatus, $id));

    ascb_log_activity(
        $pdo, $ascbUser,
        $newStatus ? 'USER_ACTIVATE' : 'USER_DEACTIVATE',
        'user', $existing['display_name']
    );

    echo json_encode(array('ok' => true, 'isActive' => (bool) $newStatus));
    exit;
}

if ($action === 'delete') {

    $id = (int) ascb_get($input, 'id', 0);
    if ($id <= 0) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
        exit;
    }

    if ($id === $myId) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => 'Hindi mo pwedeng i-delete ang sarili mong account.'));
        exit;
    }

    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute(array($id));
    $existing = $stmt->fetch();

    if (!$existing) {
        http_response_code(404);
        echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang account.'));
        exit;
    }

    if ($existing['role'] === 'UNIT HEAD') {
        $countStmt = $pdo->prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'UNIT HEAD' AND is_active = 1 AND id <> ?");
        $countStmt->execute(array($id));
        $remaining = (int) $countStmt->fetch()['c'];
        if ($remaining < 1) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Hindi pwedeng i-delete — ito na ang huling aktibong UNIT HEAD.'));
            exit;
        }
    }

    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ?");
    $stmt->execute(array($id));

    ascb_log_activity($pdo, $ascbUser, 'USER_DELETE', 'user', $existing['display_name']);

    echo json_encode(array('ok' => true));
    exit;
}

http_response_code(400);
echo json_encode(array('ok' => false, 'error' => 'Unknown action.'));
