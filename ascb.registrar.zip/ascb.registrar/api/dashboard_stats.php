<?php
/* =========================================================
   API: DASHBOARD STATS
   ---------------------------------------------------------
   GET params:
     trimester (opsyonal) — hal. "1st Trimester". Kung
                blangko/wala, lahat ng trimester ang isasama.

   GET -> ibinabalik ang:
            - totalEnrolled : bilang ng mga ESTUDYANTE (hindi
                               records) na "active" — hindi
                               na-archive AT hindi "rejected".
                               Kung may ilang term/record na ang
                               isang estudyante, ISANG BESES lang
                               siya binibilang (batay sa student_id,
                               gamit ang PINAKA-BAGONG record niya).
            - male / female : bilang ng estudyanteng lalaki / babae
                               (batay rin sa parehong "isang
                               estudyante = isang beses lang" na
                               paraan sa itaas).
            - byCourse      : listahan kada Course/Program —
                               {course, male, female, total} —
                               pinagsunod-sunod mula sa pinaka-
                               maraming estudyante. Ang "course"
                               dito ay ang MAIKLING CODE (hal. BSA,
                               BSCS, BSBA-FM) mula sa program_code
                               column — pantay-pantay ang format
                               para sa LAHAT ng kurso, hindi na
                               yung mahabang pangalan. Kung walang
                               program_code (lumang datos), ang
                               `course` (mahabang pangalan) na lang
                               ang gagamitin bilang fallback.

   Ang buong counting logic ay nasa includes/dashboard_stats_helper.php
   (ascb_dashboard_stats) — parehong ginagamit ng Excel export sa
   api/dashboard_stats_export.php para laging magkatugma ang
   nakikita sa Dashboard at ang na-e-export.

   Bukas ito sa kahit sinong naka-login (parehong pattern gaya ng
   ibang GET API dito) — walang binabagong data, basa lang.
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../includes/dashboard_stats_helper.php';
require_once __DIR__ . '/../includes/departments.php';
require_once __DIR__ . '/../config/db.php';

$trimester = trim((string) ascb_get($_GET, 'trimester', ''));
$departmentId = ascb_get($ascbUser,'role','') === 'DEAN' ? ascb_require_dean_department($pdo,$ascbUser) : null;
$stats = ascb_dashboard_stats($pdo, $trimester, $departmentId);

echo json_encode(array(
    'ok'            => true,
    'totalEnrolled' => $stats['totalEnrolled'],
    'male'          => $stats['male'],
    'female'        => $stats['female'],
    'byCourse'      => $stats['byCourse'],
));
