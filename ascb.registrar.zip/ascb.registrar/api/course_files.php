<?php
/* =========================================================
   API: COURSE FILES
   ---------------------------------------------------------
   Bawat entry = pangalan + course + isang Excel file
   (.xlsx / .xls / .csv). CREATE at DELETE lang ang meron —
   SINADYANG WALANG "UPDATE" na papalit sa laman ng file, para
   hindi na mababago ang laman ng na-upload na Excel kailanman.
   Kung mali ang na-upload, i-delete na lang ang entry at
   mag-upload ulit ng panibago.

   GET  -> ibinabalik ang listahan ng mga Course File entries
           (pinaka-bago muna).

           Params: q (search text, optional — hahanapin sa
                   pangalan, course, at sa orihinal na filename)
                   Walang limit — palaging ibabalik lahat ng
                   tugma sa database.

   POST -> multipart/form-data (HINDI JSON, dahil may
           kasamang file upload). Ang "action" field ang
           nagsasabi kung create / delete:

           action=create : fields name, course, file (1 Excel
                            file, required)
           action=delete : field id
   ========================================================= */

require_once __DIR__ . '/../includes/api_guard.php';
require_once __DIR__ . '/../config/db.php';

$UPLOAD_DIR = __DIR__ . '/../uploads/course_files/';
if (!is_dir($UPLOAD_DIR)) {
    @mkdir($UPLOAD_DIR, 0755, true);
}
if (!is_dir($UPLOAD_DIR) || !is_writable($UPLOAD_DIR)) {
    http_response_code(500);
    echo json_encode(array('ok' => false, 'error' => 'Hindi writable ang upload folder sa server. I-check ang deployment folder permissions.'));
    exit;
}

$maxSizeBytes = ASCB_MAX_UPLOAD_MB * 1024 * 1024; // configurable; default 25 MB

$ALLOWED_EXTENSIONS = array('xlsx', 'xls', 'csv');

$method = $_SERVER['REQUEST_METHOD'];


/* =========================================================
   Tulong na function: i-validate + i-save ang isang na-upload
   na Excel file. Ibinabalik ang array(original, stored, size)
   kung tagumpay, o direktang nagpapadala ng JSON error at
   nag-e-exit kung mayroong problema.

   NOTE: extension lang ang mahigpit na ini-check dito (hindi
   MIME type via finfo) — dahil hindi consistent ang MIME na
   naibabalik ng iba't ibang server/PHP build para sa .xlsx
   (madalas "application/zip" dahil ZIP container talaga ang
   .xlsx sa ilalim), kaya mapeperwisyo lang ang user kung
   mahigpit dito.
   ========================================================= */
function ascbCfHandleUpload($fieldName, $UPLOAD_DIR, $maxSizeBytes, $allowedExtensions) {

    if (empty($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
        return null; // walang na-upload na file
    }

    if ($_FILES[$fieldName]['error'] !== UPLOAD_ERR_OK) {
        $uploadErrCode = $_FILES[$fieldName]['error'];
        $uploadErrMsgs = array(
            UPLOAD_ERR_INI_SIZE   => 'Lumagpas sa upload_max_filesize ng server (php.ini). Kailangang taasan ito ng system admin.',
            UPLOAD_ERR_FORM_SIZE  => 'Lumagpas sa max file size na tinakda sa form.',
            UPLOAD_ERR_PARTIAL    => 'Hindi natapos ang pag-upload ng file (na-interrupt sa gitna, baka slow connection o na-timeout).',
            UPLOAD_ERR_NO_TMP_DIR => 'Walang temporary folder sa server para sa upload.',
            UPLOAD_ERR_CANT_WRITE => 'Hindi ma-isulat ang file sa disk ng server (baka permission issue).',
            UPLOAD_ERR_EXTENSION  => 'Hinarang ang upload ng isang PHP extension sa server.',
        );
        $uploadErrText = isset($uploadErrMsgs[$uploadErrCode])
            ? $uploadErrMsgs[$uploadErrCode]
            : 'Hindi kilalang error (code ' . $uploadErrCode . ').';

        http_response_code(400);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'May error sa pag-upload ng file (' . $_FILES[$fieldName]['name'] . '): ' . $uploadErrText,
        ));
        exit;
    }

    $tmpPath      = $_FILES[$fieldName]['tmp_name'];
    $originalName = $_FILES[$fieldName]['name'];
    $size         = $_FILES[$fieldName]['size'];

    if ($size > $maxSizeBytes) {
        http_response_code(400);
        echo json_encode(array('ok' => false, 'error' => $originalName . ' ay masyadong malaki (max ' . ASCB_MAX_UPLOAD_MB . 'MB).'));
        exit;
    }

    $ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));

    if (!in_array($ext, $allowedExtensions, true)) {
        http_response_code(400);
        echo json_encode(array(
            'ok'    => false,
            'error' => $originalName . ' ay hindi Excel file. Tanging .xlsx, .xls, o .csv lang ang tinatanggap.',
        ));
        exit;
    }

    $storedName  = 'cf_' . ascb_random_token(16) . '.' . $ext;
    $destination = $UPLOAD_DIR . $storedName;

    if (!move_uploaded_file($tmpPath, $destination)) {
        http_response_code(500);
        echo json_encode(array('ok' => false, 'error' => 'Hindi na-save ang ' . $originalName . '.'));
        exit;
    }

    return array('original' => $originalName, 'stored' => $storedName, 'size' => (int) $size);
}


/* ========================================== GET — LIST */

if ($method === 'GET') {

    $q = trim(ascb_get($_GET, 'q', ''));

    /* WALANG LIMIT — palaging ibabalik LAHAT ng tugma sa database */

    $sql = "SELECT c.*, u.display_name AS uploaded_by_name
            FROM course_files c
            LEFT JOIN users u ON u.id = c.uploaded_by_user_id";
    $params = array();

    if ($q !== '') {
        $qNorm = str_replace(array("\xC2\xA0", "\t", "\r", "\n"), ' ', $q);
        $qNorm = preg_replace('/\s+/', ' ', $qNorm);
        $qNorm = trim($qNorm);

        $qEscaped = str_replace(array('\\', '%', '_'), array('\\\\', '\%', '\_'), $qNorm);

        $sql .= " WHERE (TRIM(c.student_name) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(c.course) LIKE ? ESCAPE '\\\\'"
              . " OR TRIM(c.original_filename) LIKE ? ESCAPE '\\\\')";
        $params[] = '%' . $qEscaped . '%';
        $params[] = '%' . $qEscaped . '%';
        $params[] = '%' . $qEscaped . '%';
    }

    $sql .= " ORDER BY c.created_at DESC, c.id DESC";

    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
    } catch (Exception $e) {
        http_response_code(500);
        echo json_encode(array(
            'ok'    => false,
            'error' => 'May error sa pagkuha ng listahan mula sa database.'
        ), JSON_UNESCAPED_UNICODE);
        exit;
    }

    echo json_encode(array('ok' => true, 'rows' => $rows, 'count' => count($rows)), JSON_UNESCAPED_UNICODE);
    exit;
}


/* ========================================== POST — CREATE / DELETE */

if ($method === 'POST') {

    $action = ascb_get($_POST, 'action', 'create');

    /* ----------------------------------------- CREATE */
    if ($action === 'create') {

        $name = trim(ascb_get($_POST, 'name', ''));
        if ($name === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng pangalan.'));
            exit;
        }

        $course = trim(ascb_get($_POST, 'course', ''));
        if ($course === '') {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng course.'));
            exit;
        }

        $uploaded = ascbCfHandleUpload('file', $UPLOAD_DIR, $maxSizeBytes, $ALLOWED_EXTENSIONS);
        if (!$uploaded) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Kailangan ng Excel file (.xlsx, .xls, o .csv).'));
            exit;
        }

        $stmt = $pdo->prepare(
            "INSERT INTO course_files
                (student_name, course, stored_filename, original_filename, filesize_bytes, uploaded_by_user_id)
             VALUES (?,?,?,?,?,?)"
        );
        $stmt->execute(array(
            $name,
            $course,
            $uploaded['stored'],
            $uploaded['original'],
            $uploaded['size'],
            ascb_get($ascbUser, 'id', null),
        ));

        echo json_encode(array('ok' => true, 'id' => $pdo->lastInsertId()));
        exit;
    }

    /* ----------------------------------------- DELETE */
    if ($action === 'delete') {

        $id = (int) ascb_get($_POST, 'id', 0);
        if ($id <= 0) {
            http_response_code(400);
            echo json_encode(array('ok' => false, 'error' => 'Invalid id.'));
            exit;
        }

        $stmt = $pdo->prepare("SELECT * FROM course_files WHERE id = ?");
        $stmt->execute(array($id));
        $existing = $stmt->fetch();

        if (!$existing) {
            http_response_code(404);
            echo json_encode(array('ok' => false, 'error' => 'Hindi nahanap ang entry.'));
            exit;
        }

        $stmt = $pdo->prepare("DELETE FROM course_files WHERE id = ?");
        $stmt->execute(array($id));

        $path = $UPLOAD_DIR . $existing['stored_filename'];
        if (is_file($path)) {
            @unlink($path);
        }

        echo json_encode(array('ok' => true));
        exit;
    }

    http_response_code(400);
    echo json_encode(array('ok' => false, 'error' => 'Unknown action. (update/replace ay sinadyang hindi suportado dito — permanente ang laman ng na-upload na file.)'));
    exit;
}


/* ========================================== OTHER METHODS */

http_response_code(405);
echo json_encode(array('ok' => false, 'error' => 'Method not allowed.'));
