<?php
/**
 * ONE-TIME HELPER — Department / Dean / Backup migration (via browser)
 * ----------------------------------------------------------------------
 * Gamitin ito KUNG hindi available/hindi komportable gumamit ng command
 * line (CLI) sa server/XAMPP. Ito ay pansamantalang "bypass" lang ng
 * setup_guard.php na naka-block sa pagpapatakbo ng migration scripts
 * sa web para sa seguridad.
 *
 * PAANO GAMITIN:
 *   1. I-kopya ang file na ito sa ROOT folder ng ascb-registrar
 *      (kasabay ng dashboard.php / index.php — HINDI sa loob ng
 *      /database o /includes folder).
 *   2. Buksan sa browser, hal.:
 *        http://localhost/ascb-registrar/run_departments_backup_migration_once.php
 *   3. Dapat lumabas ang: "Department / Dean / Backup migration complete."
 *   4. Pagkatapos gumana, I-DELETE AGAD ang file na ito sa server.
 *      Huwag itong iwanan sa live/production folder.
 */

putenv('ASCB_ALLOW_WEB_SETUP=1');
$_ENV['ASCB_ALLOW_WEB_SETUP'] = '1';

require __DIR__ . '/database/migrate_departments_dean_backup_module.php';
