<?php
/**
 * ONE-TIME DIAGNOSTIC — Department Excel export (walang datos ng estudyante)
 * ----------------------------------------------------------------------
 * PAANO GAMITIN:
 *   1. I-kopya ang file na ito sa ROOT folder ng ascb-registrar
 *      (kasabay ng dashboard.php).
 *   2. Buksan sa browser:
 *        http://localhost/ascb-registrar/diagnose_department_export.php
 *   3. I-COPY ang buong output at ipadala/i-paste sa chat.
 *   4. I-DELETE ang file na ito pagkatapos gamitin.
 */

define('ASCB_DB_OPTIONAL', true);
require_once __DIR__ . '/config/db.php';

header('Content-Type: text/plain; charset=utf-8');

if (!$pdo) { echo "WALANG KONEKSYON SA DATABASE.\n"; exit; }

function q($pdo, $sql, $params = array()) {
    $s = $pdo->prepare($sql);
    $s->execute($params);
    return $s->fetchAll();
}

echo "===== 1. DEPARTMENTS =====\n";
$deps = q($pdo, "SELECT id, code, name, is_active FROM departments ORDER BY id");
if (!$deps) { echo "WALA PANG DEPARTMENT NA GINAWA.\n"; }
foreach ($deps as $d) { echo "  #{$d['id']}  {$d['code']}  —  {$d['name']}  (active={$d['is_active']})\n"; }

echo "\n===== 2. PROGRAMS (at kung may naka-link na Department) =====\n";
$progs = q($pdo, "SELECT p.id, p.code, p.course_name, p.department_id, d.name AS dept_name FROM programs p LEFT JOIN departments d ON d.id=p.department_id ORDER BY p.code");
$withDept = 0; $withoutDept = 0;
foreach ($progs as $p) {
    if ($p['department_id']) { $withDept++; } else { $withoutDept++; }
    echo "  {$p['code']}  —  {$p['course_name']}  ->  Department: " . ($p['dept_name'] ?: '(WALANG NAKA-ASSIGN)') . "\n";
}
echo "  TOTAL: " . count($progs) . " programs | May Department: {$withDept} | WALANG Department: {$withoutDept}\n";

echo "\n===== 3. ENROLLEES: bilang bawat program_code (data mismatch check) =====\n";
$counts = q($pdo, "SELECT e.program_code, COUNT(*) c, MAX(p.id) matched_program_id, MAX(p.department_id) matched_department_id
                    FROM enrollees e LEFT JOIN programs p ON p.code = e.program_code
                    WHERE e.archived_at IS NULL AND e.status <> 'rejected'
                    GROUP BY e.program_code ORDER BY c DESC");
if (!$counts) { echo "WALANG NAKITANG ENROLLEE (o lahat ay archived/rejected).\n"; }
foreach ($counts as $c) {
    $tag = $c['matched_program_id'] ? ('MATCHED sa program #' . $c['matched_program_id'] . ($c['matched_department_id'] ? ", may Department" : ", WALANG Department")) : '*** WALANG TUMUGMANG PROGRAM ROW (mismatch ang code) ***';
    echo "  program_code='" . $c['program_code'] . "'  ({$c['c']} enrollee/s)  ->  {$tag}\n";
}

echo "\n===== 4. ENROLLMENT SUBJECTS / GRADES: may laman ba =====\n";
$esCount = $pdo->query("SELECT COUNT(*) c FROM enrollment_subjects")->fetch()['c'];
$gCount = $pdo->query("SELECT COUNT(*) c FROM grades")->fetch()['c'];
$sjCount = $pdo->query("SELECT COUNT(*) c FROM enrollees WHERE subjects_json IS NOT NULL AND subjects_json <> ''")->fetch()['c'];
echo "  enrollment_subjects rows: {$esCount}\n";
echo "  grades rows: {$gCount}\n";
echo "  enrollees na may lumang subjects_json (legacy, hindi pa na-migrate): {$sjCount}\n";
if ($esCount == 0 && $sjCount > 0) {
    echo "  *** MUKHANG HINDI PA NA-RUN ang migrate_grade_management_module.php — nasa lumang subjects_json pa ang datos, hindi sa bagong table. ***\n";
}

echo "\n===== 5. SIMULATION: export query para sa bawat Department =====\n";
foreach ($deps as $d) {
    $rows = q($pdo, "SELECT COUNT(DISTINCT e.id) c FROM enrollees e LEFT JOIN programs p ON p.code=e.program_code
                      WHERE e.archived_at IS NULL AND e.status<>'rejected' AND p.department_id=?", array($d['id']));
    echo "  Department '{$d['name']}' (#{$d['id']}): magla-Excel ng " . $rows[0]['c'] . " (distinct) enrollee(s) kung 'All School Year/Term'.\n";
}

echo "\n===== TAPOS NA. I-PASTE ANG BUONG OUTPUT NA ITO SA CHAT. =====\n";
