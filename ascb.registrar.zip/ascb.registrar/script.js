/* =========================================================
   DEPLOYMENT SAFETY: all same-origin write requests carry the
   server-generated CSRF token automatically. Existing fetch()
   calls do not need to be rewritten one by one.
   ========================================================= */
(function () {
    if (typeof window === "undefined" || typeof window.fetch !== "function") return;
    const nativeFetch = window.fetch.bind(window);

    window.fetch = function (resource, options) {
        const opts = options ? Object.assign({}, options) : {};
        let method = (opts.method || "GET").toUpperCase();
        let requestUrl = "";

        try {
            if (typeof resource === "string") {
                requestUrl = new URL(resource, window.location.href).href;
            } else if (resource && resource.url) {
                requestUrl = new URL(resource.url, window.location.href).href;
                if (!opts.method && resource.method) method = String(resource.method).toUpperCase();
            }
        } catch (e) {
            requestUrl = "";
        }

        const sameOrigin = requestUrl && new URL(requestUrl).origin === window.location.origin;
        const mutating = !["GET", "HEAD", "OPTIONS"].includes(method);

        if (sameOrigin && mutating && typeof ASCB_CSRF_TOKEN !== "undefined" && ASCB_CSRF_TOKEN) {
            const headers = new Headers(opts.headers || (resource && resource.headers ? resource.headers : undefined));
            headers.set("X-CSRF-Token", ASCB_CSRF_TOKEN);
            opts.headers = headers;
            opts.credentials = "same-origin";
        }

        return nativeFetch(resource, opts);
    };
})();


const structuredPrograms = {

    /* =====================================================
       BSIT — Effective SY 2022-2023, CMO No. 25 s.2015
    ===================================================== */
    BSIT: [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "CC 101", description: "Introduction to Computing with Keyboarding", units: 3 },
                { code: "CSS 1", description: "Install and Configure Computers/Set-up Computer Networks", units: 3 },
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Reading in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "CC 102", description: "Computer Programming 1", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "CSS 2", description: "Set-up Computer Servers/Maintain Computer Systems and Networks", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness", units: 2 },
                { code: "NSTP 1", description: "Civic Welfare Training Service I", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "CC 103", description: "Computer Programming 2", units: 3 },
                { code: "MS 101", description: "Discrete Mathematics", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology & Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service II", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "PF 101", description: "Object Oriented Programming", units: 3 },
                { code: "CC 104", description: "Data Structures & Algorithms", units: 3 },
                { code: "PT 101", description: "Platform Technologies", units: 3 },
                { code: "CC 105", description: "Information Management", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "IM 101", description: "Fundamentals of Database Systems", units: 3 },
                { code: "Net 101", description: "Networking 1", units: 3 },
                { code: "IPT 101", description: "Integrative Programming and Technologies", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "GE 12", description: "Life & Works of Rizal", units: 3 },
                { code: "SAD", description: "System Analysis, Design and Development", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "IAS 101", description: "Information Assurance & Security", units: 3 },
                { code: "SIA 101", description: "System Integration and Architecture 1", units: 3 },
                { code: "HCI 101", description: "Introduction to Human Computer Interaction 1", units: 3 },
                { code: "MS 102", description: "Quantitative Methods (include Modelling & Simulation)", units: 3 },
                { code: "Stat 1", description: "Statistics", units: 3 },
                { code: "CC 106", description: "Application Development and Emerging Technologies", units: 3 },
                { code: "DM", description: "Data Mining", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "BD 101", description: "Business Intelligence", units: 3 },
                { code: "SP 101", description: "Social and Professional Issues", units: 3 },
                { code: "Net 102", description: "Networking 2", units: 3 },
                { code: "SA 101", description: "System Administration and Maintainance", units: 3 },
                { code: "Cap 101", description: "Capstone Project and Research 1", units: 3 },
                { code: "IT Elec 1", description: "Web Systems and Technologies", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "CAP 102", description: "Capstone Project and Research 2", units: 3 },
                { code: "IT Elec 2", description: "Integrative Programming and Technologies 2", units: 3 },
                { code: "IAS 102", description: "Information Assurance & Security 2", units: 3 },
                { code: "Acctg. 1", description: "Basic Accounting 1", units: 3 },
                { code: "IT Elec 3", description: "Human Computer Interaction 2", units: 3 },
                { code: "PDC", description: "Parallel and Distributed Computing", units: 3 },
                { code: "OS 101", description: "Operating Systems", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "PR 101", description: "Practicum (486 hrs.)", units: 3 },
                { code: "IT Elec 4", description: "System Integration and Architecture 2", units: 3 }
            ]
        }
    ],


    /* =====================================================
       BSIS — Effective SY 2022-2023, CMO No. 25 s.2015
    ===================================================== */
    BSIS: [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "CC 101", description: "Introduction to Computing with Keyboarding", units: 3 },
                { code: "CSS 1", description: "Install and Configure Computers/Set-up Computer Networks", units: 3 },
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "CC 102", description: "Computer Programming 1 (Fundamentals of Programming)", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "CSS 2", description: "Set-up Computer Servers/Maintain Computer Systems & Networks", units: 0 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness", units: 2 },
                { code: "NSTP 1", description: "Civic Welfare Training Service I", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "CC 103", description: "Computer Programming 2 (Intermediate Programming)", units: 3 },
                { code: "IS 101", description: "Fundamentals of Information Systems", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology & Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service II", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "PF 101", description: "Object Oriented Programming", units: 3 },
                { code: "CC 104", description: "Data Structures and Algorithms", units: 3 },
                { code: "IS 103", description: "IT Infrastructure and Network Technologies", units: 3 },
                { code: "IS 102", description: "Professional Issues in Information Systems", units: 3 },
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "IM 101", description: "Fundamentals of Database Systems", units: 3 },
                { code: "CC 105", description: "Information Management", units: 3 },
                { code: "IS 104", description: "System Analysis, Design and Development", units: 3 },
                { code: "DM 101", description: "Organization and Management Concepts", units: 3 },
                { code: "IPT 101", description: "Integrative Programming & Technologies", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "GE 12", description: "Life & Works of Rizal", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "IAS 101", description: "Information Assurance & Security", units: 3 },
                { code: "HCI 101", description: "Human Computer Interaction", units: 3 },
                { code: "QUAMET", description: "Quantitative Methods", units: 3 },
                { code: "Stat 1", description: "Statistics", units: 3 },
                { code: "IS 105", description: "Enterprise Architecture", units: 3 },
                { code: "IS Elec 1", description: "Data Mining", units: 3 },
                { code: "DM 102", description: "Financial Management", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "CAP 101", description: "Capstone Project 1", units: 3 },
                { code: "IS 106", description: "IS Project Management 1", units: 3 },
                { code: "ITAC", description: "IT Audit and Controls", units: 3 },
                { code: "BD 101", description: "Business Intelligence", units: 3 },
                { code: "IS 107", description: "IS Strategy, Management and Acquisition", units: 3 },
                { code: "DM 103", description: "Business Process Design & Management", units: 3 },
                { code: "Research", description: "Methods of Research in Computing", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "CAP 102", description: "Capstone Project 2", units: 3 },
                { code: "CC 106", description: "Applications Devt. & Emerging Technologies", units: 3 },
                { code: "ISI", description: "IS Innovation and New Technologies", units: 3 },
                { code: "Acctg. 1", description: "Basic Accounting 1", units: 3 },
                { code: "IS Elec 2", description: "Enterprise Resource Planning", units: 3 },
                { code: "IS Elec 3", description: "IS Project Management 2", units: 3 },
                { code: "Techno", description: "Technopreneurship", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "DM 104", description: "Evaluation of Business Performance", units: 3 },
                { code: "IS Elec 4", description: "Customer Relationship Management", units: 3 },
                { code: "Prac 101", description: "Practicum for Information System (486 hours)", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BSCS — Effective SY 2022-2023, CMO No. 25 s.2015
    ===================================================== */
    BSCS: [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "CC 101", description: "Introduction to Computing with Keyboarding", units: 3 },
                { code: "CSS 1", description: "Install and Configure Computers/Set-up Computer Networks", units: 3 },
                { code: "GE 1", description: "Understanding Self", units: 3 },
                { code: "GE 2", description: "Reading in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "CC 102", description: "Fundamentals of Programming", units: 3 },
                { code: "GE 4", description: "Mathematics in Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "NSTP 1", description: "Civic Welfare Training Service", units: 3 },
                { code: "CSS 2", description: "Set-up Computer Servers/Maintain Computer Systems and Networks", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness", units: 2 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "CC 103", description: "Intermediate Programming", units: 3 },
                { code: "DS 101", description: "Discrete Structure 1", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology & Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service II", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "SDF 104", description: "Object Oriented Programming", units: 3 },
                { code: "CC 104", description: "Data Structures & Algorithms", units: 3 },
                { code: "CC 105", description: "Information Management", units: 3 },
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 },
                { code: "PT 101", description: "Platform Technologies", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "AL 101", description: "Algorithms & Complexity", units: 3 },
                { code: "Math 2A", description: "Math Elective (Differential Calculus)", units: 3 },
                { code: "AR 101", description: "Architecture & Organization", units: 3 },
                { code: "SAD 101", description: "System Analysis, Design and Development", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "SE 101", description: "Software Engineering 1", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "AL 102", description: "Automata Theory & Formal Languages", units: 3 },
                { code: "CC 106", description: "Application Development and Emerging Technologies", units: 3 },
                { code: "IAS 101", description: "Information Assurance & Security", units: 3 },
                { code: "HCI", description: "Human Computer Interaction", units: 3 },
                { code: "Stat 1", description: "Statistics", units: 3 },
                { code: "SE 102", description: "Software Engineering 2", units: 3 },
                { code: "DS 102", description: "Discrete Structure 2", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "THS 101", description: "CS Thesis Writing 1", units: 3 },
                { code: "BD 101", description: "Business Intelligence", units: 3 },
                { code: "DM", description: "Data Mining", units: 3 },
                { code: "SP 101", description: "Social Issues & Professional Practice", units: 3 },
                { code: "NC 101", description: "Networks and Communication", units: 3 },
                { code: "CS Elec 1", description: "System Fundamentals", units: 3 },
                { code: "CS Elec 2", description: "Graphics and Visual Computing", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "THS 102", description: "CS Thesis Writing 2", units: 3 },
                { code: "CS Elec 3", description: "Computational Science", units: 3 },
                { code: "PDC 101", description: "Parallel and Distributed Computing", units: 3 },
                { code: "IS 101", description: "Intelligent System", units: 3 },
                { code: "OS 101", description: "Operating Systems", units: 3 },
                { code: "Acctg 101", description: "Basic Accounting", units: 3 },
                { code: "PL 101", description: "Programming Languages", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "PRC", description: "Practicum (486 hrs.)", units: 6 },
                { code: "G12", description: "Life & Works of Rizal", units: 3 }
            ]
        }
    ],


    /* =====================================================
       BSCRIM — Effective SY 2022-2023, CMO No. 5 s.2018
    ===================================================== */
    BSCRIM: [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in Modern World", units: 3 },
                { code: "Crim 1", description: "Introduction to Criminology", units: 3 },
                { code: "EC 1", description: "Reading Comprehension", units: 3 },
                { code: "DEFTAC 1", description: "Fundamentals of Martial Arts", units: 2 },
                { code: "NSTP 1", description: "ROTC 1", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology and Society", units: 3 },
                { code: "LEA 1", description: "Law Enforcement Organization and Administration", units: 4 },
                { code: "CLJ 1", description: "Introduction to Philippine Criminal Justice System", units: 3 },
                { code: "DEFTAC 2", description: "Arnis and Disarming Technique", units: 2 },
                { code: "NSTP 2", description: "ROTC 2", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "EC 2", description: "Basic Computer Software", units: 3 },
                { code: "CLJ 2", description: "Human Rights Education", units: 3 },
                { code: "Crim 2", description: "Theories of Crime Causation", units: 3 },
                { code: "CDI 1", description: "Fundamentals of Investigation and Intelligence", units: 4 },
                { code: "LEA 2", description: "Comparative Models in Policing", units: 3 },
                { code: "DEFTAC 3", description: "First Aid and Water Safety", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "PC 1", description: "Life and Works of Rizal", units: 3 },
                { code: "CDI 2", description: "Specialized Crime Investigation 1 w/ Legal Medicine", units: 3 },
                { code: "CLJ 3", description: "Criminal Law (Book 1)", units: 3 },
                { code: "Chem 1", description: "General Chemistry (Organic)", units: 3 },
                { code: "Forensic 1", description: "Forensic Photography", units: 3 },
                { code: "LEA 3", description: "Introduction to Industrial Security Concepts", units: 3 },
                { code: "DEFTAC 4", description: "Marksmanship and Combat Shooting", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "EC 3", description: "Politics & Governance with Philippine Constitution", units: 3 },
                { code: "Crim 3", description: "Human Behavior and Victimology", units: 3 },
                { code: "Crim 4", description: "Professional Conduct and Ethical Standards", units: 3 },
                { code: "CLJ 4", description: "Criminal Law (Book 2)", units: 4 },
                { code: "Forensic 2", description: "Personal Identification Techniques", units: 3 },
                { code: "CDI 3", description: "Specialized Crime Investigation 2 w/ Simulation on Interrogation and Interview", units: 3 },
                { code: "CA 1", description: "Institutional Corrections", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Forensic 3", description: "Forensic Chemistry and Toxicology", units: 5 },
                { code: "CDI 4", description: "Traffic Management and Accident Investigation w/ Driving", units: 3 },
                { code: "CA 2", description: "Non-Institutional Corrections", units: 3 },
                { code: "Crim 5", description: "Juvenile Delinquency and Juvenile Justice System", units: 3 },
                { code: "Crim 6", description: "Dispute Resolution and Crises/Incidents Management", units: 3 },
                { code: "CFLM 1", description: "Character Formation, Nationalism and Patriotism", units: 3 },
                { code: "LEA 4", description: "Law Enforcement Operation and Planning w/ Crime Mapping", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "CLJ 5", description: "Evidence", units: 3 },
                { code: "CFLM 2", description: "Character Formation w/ Leadership, Decision Making, Management and Administration", units: 3 },
                { code: "CDI 5", description: "Technical English 1 (Technical Report Writing & Presentation)", units: 3 },
                { code: "CDI 6", description: "Fire Protection & Arson Investigation", units: 3 },
                { code: "CA 3", description: "Therapeutic Modalities", units: 2 },
                { code: "Forensic 4", description: "Questioned Documents Examination", units: 3 },
                { code: "Crim 7", description: "Criminological Research 1 (Research Methods with Applied Statistics)", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "Forensic 5", description: "Lie Detection Techniques", units: 3 },
                { code: "Crim 8", description: "Criminological Research 2 (Thesis Writing and Presentation)", units: 3 },
                { code: "CDI 7", description: "Vice and Drug Education and Control", units: 3 },
                { code: "CLJ 6", description: "Criminal Procedure & Court Testimony", units: 3 },
                { code: "Forensic 6", description: "Forensic Ballistics", units: 3 },
                { code: "CDI 8", description: "Technical English 2 (Legal Forms)", units: 3 },
                { code: "CDI 9", description: "Introduction to Cybercrime and Environmental Laws and Protection", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Criminology Practicum 1", description: "Internship (On-the Job Training 1)", units: 3 },
                { code: "Sem 1", description: "Seminar 1", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "1st Trimester",
            subjects: [
                { code: "Criminology Practicum 2", description: "Internship (On-the Job Training 2)", units: 3 },
                { code: "Sem 2", description: "Seminar 2", units: 3 }
            ]
        }
    ],


    /* =====================================================
       BSA — Effective SY 2024-2025, CMO No. 27 s.2017
    ===================================================== */
    BSA: [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "A1", description: "Conceptual Framework and Accounting Standards", units: 3 },
                { code: "A1a", description: "Fundamentals of Accounting", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "BA 1", description: "Managerial Economics", units: 3 },
                { code: "A2", description: "Fundamentals of Partnership & Corporation Accounting", units: 3 },
                { code: "NSTP 1", description: "National Service Training Program", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "BAb", description: "Principles of Management (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 7", description: "Science, Technology, and Society", units: 3 },
                { code: "A3", description: "Cost of Accounting and Control", units: 3 },
                { code: "A4", description: "Financial Accounting and Reporting", units: 3 },
                { code: "BA 2", description: "Law on Obligations and Contracts", units: 3 },
                { code: "BA 3", description: "Management Science", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "NSTP 2", description: "National Service Training Program", units: 3 },
                { code: "BAa", description: "Principles of Marketing (Non-ABM graduates)", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "GE 9", description: "Business Logic", units: 3 },
                { code: "BA 4", description: "Economic Development", units: 3 },
                { code: "BA 5", description: "Business Laws and Regulations", units: 3 },
                { code: "A5", description: "Intermediate Accounting 1", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 11", description: "Living In An IT Era", units: 3 },
                { code: "BA 6", description: "Income Taxation", units: 3 },
                { code: "A6", description: "Intermediate Accounting 2", units: 3 },
                { code: "A7", description: "Strategic Cost Management", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 12", description: "Life and Works of Rizal", units: 3 },
                { code: "BA 7", description: "Business Taxation", units: 3 },
                { code: "A8", description: "Regulatory Framework and Legal Issues in Business", units: 3 },
                { code: "A9", description: "Intermediate Accounting 3", units: 3 },
                { code: "BA 8", description: "Financial Management", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "A&B1", description: "Operational Management and TQM with field trip", units: 3 },
                { code: "A10", description: "Governance, Business Ethics, Risk Management, and Internal Control", units: 3 },
                { code: "BA 9", description: "IT Application Tools in Business", units: 3 },
                { code: "BA 10", description: "Financial Markets", units: 3 },
                { code: "PA 1", description: "Auditing and Assurance Principles", units: 3 },
                { code: "BA 11", description: "Statistical Analysis with Software Application", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "A&B2", description: "Strategic Management", units: 3 },
                { code: "A11", description: "Accounting Information System", units: 3 },
                { code: "BA 12", description: "International Business and Trade", units: 3 },
                { code: "PA 2", description: "Auditing and Assurance: Concepts and Applications 1", units: 3 },
                { code: "PA 3", description: "Auditing and Assurance: Specialized Industries", units: 3 },
                { code: "PA 4", description: "Accounting for Business Combinations", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "A12*", description: "Accounting Research Methods", units: 3 },
                { code: "PA 5", description: "Auditing in CIS Environment", units: 3 },
                { code: "PA 6", description: "Accounting for Special Transactions", units: 3 },
                { code: "PA 7", description: "Auditing and Assurance: Concepts and Applications 2", units: 3 },
                { code: "PA 8", description: "Accounting for Government and Non-Profit Organizations", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "1st Trimester",
            subjects: [
                { code: "A13", description: "Accountancy Research", units: 3 },
                { code: "A14", description: "Accounting Internship", units: 6 },
                { code: "PA Elec1", description: "Valuation Concepts & Methods", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "2nd Trimester",
            subjects: [
                { code: "PA Elec2", description: "Updates in Financial Reporting", units: 3 },
                { code: "PA Elec3", description: "Operations Auditing", units: 3 },
                { code: "BA 13", description: "Strategic Business Analysis", units: 3 },
                { code: "Review 1", description: "Review on Management Services", units: 3 },
                { code: "Review 2", description: "Review on Financial Accounting & Reporting", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "3rd Trimester",
            subjects: [
                { code: "PA Elec4", description: "Human Behavior in an Organization", units: 3 },
                { code: "Review 3", description: "Review on Auditing", units: 3 },
                { code: "Review 4", description: "Review on Advance Financial Accounting and Reporting", units: 3 },
                { code: "Review 5", description: "Review on Taxation", units: 3 },
                { code: "Review 6", description: "Review on Business Law", units: 3 }
            ]
        }
    ],


    /* =====================================================
       BSBA-FM — Effective SY 2024-2025, CMO No. 17 s.2017
    ===================================================== */
    "BSBA-FM": [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "A1a", description: "Fundamentals of Accounting", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology & Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "A1*", description: "Fundamentals of Partnership & Corporation Accounting", units: 3 },
                { code: "NSTP 1", description: "National Service Training Program", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "BAa", description: "Principles of Management (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "BA 1", description: "Basic Microeconomics", units: 3 },
                { code: "FM 101", description: "Financial Management", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "NSTP 2", description: "National Service Training Program", units: 3 },
                { code: "BAb", description: "Principles of Marketing (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 12", description: "Life and Works of Rizal", units: 3 },
                { code: "GE Elec1", description: "Mathematics, Science & Technology", units: 3 },
                { code: "GE Elec2", description: "Social Science and Philosophy", units: 3 },
                { code: "BA 2", description: "Obligations and Contract", units: 3 },
                { code: "FM 102", description: "Financial Analysis & Reporting", units: 3 },
                { code: "FM 103", description: "Banking & Financial Institution", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE Elec3", description: "Arts and Humanities", units: 3 },
                { code: "BA 3", description: "Human Behavior in an Organization with Case Analysis", units: 3 },
                { code: "BA 4", description: "Income Taxation", units: 3 },
                { code: "FM 104", description: "Monetary Policy & Central Banking", units: 3 },
                { code: "FM 105", description: "Investment & Portfolio Management", units: 3 },
                { code: "PATH Fit 3", description: "Dance & Sports", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "BA 5", description: "Good Governance and Social Responsibility", units: 3 },
                { code: "BA 6", description: "Human Resource Management", units: 3 },
                { code: "BA 7", description: "International Trade and Agreement", units: 3 },
                { code: "FM 106", description: "Credit & Collection", units: 3 },
                { code: "FM 107", description: "Capital Market", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "BA 8", description: "Business Research", units: 3 },
                { code: "A&B 1", description: "Strategic Management", units: 3 },
                { code: "FM 108", description: "Strategic Financial Management", units: 3 },
                { code: "Elec 2", description: "Cooperative Management", units: 3 },
                { code: "Elec. 1", description: "Entrepreneurial Management", units: 3 },
                { code: "BA 10", description: "Graphic Design in Business", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "A&B 2", description: "Operations Management (TQM)", units: 3 },
                { code: "BA 9", description: "Thesis or Feasibility", units: 3 },
                { code: "FM 109", description: "Special Topics in Financial Management", units: 3 },
                { code: "Elec 4", description: "E-commerce and Internet Marketing", units: 3 },
                { code: "Elec 3", description: "Franchising", units: 3 },
                { code: "BA 11", description: "IT Application Tools in Business", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Practicum", description: "Work Integrated Learning", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BSBA-HRDM — Effective SY 2024-2025, CMO No. 17 s.2017
    ===================================================== */
    "BSBA-HRDM": [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "A1a", description: "Fundamentals of Accounting", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology & Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "A1*", description: "Fundamentals of Partnership & Corporation Accounting", units: 3 },
                { code: "NSTP 1", description: "National Service Training Program", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "BAa", description: "Principles of Management (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "BA 1", description: "Basic Microeconomics", units: 3 },
                { code: "HRDM 101", description: "Administrative and Office Management", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "NSTP 2", description: "National Service Training Program", units: 3 },
                { code: "BAb", description: "Principles of Marketing (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 12", description: "Life & Works of Rizal", units: 3 },
                { code: "GE Elec1", description: "Mathematics, Science & Technology", units: 3 },
                { code: "GE Elec2", description: "Social Science and Philosophy", units: 3 },
                { code: "BA 2", description: "Obligations and Contract", units: 3 },
                { code: "HRDM 102", description: "Labor Law & Legislation", units: 3 },
                { code: "HRDM 103", description: "Recruitment & Selection", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE Elec3", description: "Arts and Humanities", units: 3 },
                { code: "BA 3", description: "Human Behavior in an Organization with Case Analysis", units: 3 },
                { code: "BA 4", description: "Income Taxation", units: 3 },
                { code: "HRDM 104", description: "Training & Development", units: 3 },
                { code: "HRDM 105", description: "Compensation Administration", units: 3 },
                { code: "PATH Fit 3", description: "Dance & Sports", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "BA 5", description: "Good Governance and Social Responsibility", units: 3 },
                { code: "BA 6", description: "Human Resource Management", units: 3 },
                { code: "BA 7", description: "International Trade and Agreement", units: 3 },
                { code: "HRDM 106", description: "Labor Relations & Negotiations", units: 3 },
                { code: "HRDM 107", description: "Organizational Development", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "BA 8", description: "Business Research", units: 3 },
                { code: "A&B 1", description: "Strategic Management", units: 3 },
                { code: "HRDM 108", description: "Strategic Human Resource Management", units: 3 },
                { code: "Elec 2", description: "Personal Finance", units: 3 },
                { code: "Elec. 1", description: "Entrepreneurial Management", units: 3 },
                { code: "BA 10", description: "Graphic Designs in Business", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "A&B 2", description: "Operations Management (TQM) with fieldtrip", units: 3 },
                { code: "BA 9", description: "Thesis or Feasibility", units: 3 },
                { code: "HRDM 109", description: "Special Topics in Human Resource Management", units: 3 },
                { code: "Elec 4", description: "Project Management", units: 3 },
                { code: "Elec 3", description: "Global / International Trade", units: 3 },
                { code: "BA 11", description: "IT Tools in Business", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Practicum", description: "Work Integrated Learning", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BSBA-MM — Effective SY 2024-2025, CMO No. 17 s.2017
    ===================================================== */
    "BSBA-MM": [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "A1a", description: "Fundamentals of Accounting", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology & Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "A1*", description: "Fundamentals of Partnership & Corporation Accounting", units: 3 },
                { code: "NSTP 1", description: "National Service Training Program", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "BAa", description: "Principles of Management (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "BA 1", description: "Basic Microeconomics", units: 3 },
                { code: "MM 101", description: "Professional Salesmanship", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "NSTP 2", description: "National Service Training Program", units: 3 },
                { code: "BAb", description: "Principles of Marketing (Non-ABM & GAS graduates)", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 12", description: "Life and Works of Rizal", units: 3 },
                { code: "GE Elec1", description: "Mathematics, Science & Technology", units: 3 },
                { code: "GE Elec2", description: "Social Science and Philosophy", units: 3 },
                { code: "BA 2", description: "Obligations and Contract", units: 3 },
                { code: "MM 102", description: "Marketing Research", units: 3 },
                { code: "MM 103", description: "Marketing Management", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE Elec3", description: "Arts and Humanities", units: 3 },
                { code: "BA 3", description: "Human Behavior in an Organization with Case Analysis", units: 3 },
                { code: "BA 4", description: "Income Taxation", units: 3 },
                { code: "MM 104", description: "Distribution Management", units: 3 },
                { code: "MM 105", description: "Advertisement", units: 3 },
                { code: "PATH Fit 3", description: "Dance & Sports", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "BA 5", description: "Good Governance and Social Responsibility", units: 3 },
                { code: "BA 6", description: "Human Resource Management", units: 3 },
                { code: "BA 7", description: "International Trade and Agreement", units: 3 },
                { code: "MM 106", description: "Product Management", units: 3 },
                { code: "MM 107", description: "Retail Management", units: 3 },
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "BA 8", description: "Business Research", units: 3 },
                { code: "A&B 1", description: "Strategic Management", units: 3 },
                { code: "MM 108", description: "Pricing Strategy", units: 3 },
                { code: "Elec 2", description: "Cooperative Management", units: 3 },
                { code: "Elec. 1", description: "Entrepreneurial Management", units: 3 },
                { code: "BA 10", description: "Graphic Design in Business", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "A&B 2", description: "Operations Management (TQM) with fieldtrip", units: 3 },
                { code: "BA 9", description: "Thesis or Feasibility Study", units: 3 },
                { code: "MM 109", description: "Special Topics in Marketing Management", units: 3 },
                { code: "Elec 4", description: "E-Commerce and Internet Marketing", units: 3 },
                { code: "Elec 3", description: "Franchising", units: 3 },
                { code: "BA 11", description: "Application Tools in Business", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Practicum", description: "Work Integrated Learning", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BEED — Effective SY 2024-2025, CMO 74 s.2017
    ===================================================== */
    BEED: [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "NSTP 1", description: "Civic Welfare Training Service 1", units: 3 },
                { code: "CoEd 100", description: "The Child and Adolescent Learners and Learning Principles", units: 3 },
                { code: "CoEd 101", description: "Building and Enhancing New Literacies Across the Curriculum", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "GE 5", description: "Purposive Communication", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service 2", units: 3 },
                { code: "CoEd 102", description: "Teaching Math in the Primary Grades", units: 3 },
                { code: "CoEd 103", description: "Facilitating Learner-Centered Teaching", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 7", description: "Science, Technology and Society", units: 3 },
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "CoEd 104", description: "The Teaching Profession", units: 3 },
                { code: "CoEd 105", description: "Good Manners and Right Conduct (Edukasyon sa Pagpapakatao)", units: 3 },
                { code: "CoEd 106", description: "Teaching Social Studies in Elementary Grades (Culture and Geography)", units: 3 },
                { code: "CoEd 107", description: "Teaching Social Studies in Elementary Grades (Philippine History and Government)", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "CoEd 200", description: "Content and Pedagogy for the Mother-Tongue", units: 3 },
                { code: "CoEd 201", description: "Foundations of Special and Inclusive Education", units: 3 },
                { code: "CoEd 202", description: "The Teacher and the School Curriculum", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 },
                { code: "TTL 1", description: "Technology for Teaching & Learning 1", units: 3 },
                { code: "CoEd 203", description: "Teaching Science in Elementary Grades (Biology and Chemistry)", units: 3 },
                { code: "CoEd 204", description: "Pagtuturo ng Filipino sa Elementarya (I) Estruktura at Gamit ng Wikang Filipino", units: 3 },
                { code: "CoEd 205", description: "Teaching English in the Elementary Grades (Language Arts)", units: 3 },
                { code: "CoEd 206", description: "Teaching English in Elementary Grades Through Literature", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 12", description: "The Life and Works of Rizal", units: 3 },
                { code: "TTL 2", description: "Technology for Teaching and Learning in the Elementary Grades", units: 3 },
                { code: "CAL 1", description: "Assessment in Learning 1 (BEED)", units: 3 },
                { code: "CoEd 207", description: "Teaching Science in Elementary Grades (Physics, Earth and Space Science)", units: 3 },
                { code: "CoEd 208", description: "Pagtuturo ng Filipino sa Elementarya (II) Panitikan ng Pilipinas", units: 3 },
                { code: "CoEd 209", description: "Teaching Math in the Intermediate Grades", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "CAL 2", description: "Assessment in Learning 2 (BEED)", units: 3 },
                { code: "SEM 1", description: "Seminar in Teaching MEFSS 1", units: 3 },
                { code: "CoEd 300", description: "Teaching PE and Health in the Elementary Grades", units: 3 },
                { code: "CoEd 301", description: "Edukasyong Pantahanan at Pangkabuhayan", units: 3 },
                { code: "CoEd 302", description: "Teaching Arts in the Elementary Grades", units: 3 },
                { code: "CoEd 303", description: "Teaching Music in the Elementary Grades", units: 3 },
                { code: "CoEd 304", description: "Research in Education", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "Elective 1", description: "Teaching Multi-Grade Classes", units: 3 },
                { code: "Elective 2", description: "English for Specific Purposes", units: 3 },
                { code: "Research 1", description: "Introduction to Thesis Writing", units: 3 },
                { code: "SEM 2", description: "Seminar in Teaching MEFSS 2", units: 3 },
                { code: "CoEd 305", description: "The Teacher and the Community, School Culture and Organizational Leadership", units: 3 },
                { code: "CoEd 306", description: "Edukasyong Pantahanan at Pangkabuhayan with Entrepreneurship", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Research 2", description: "Thesis Writing", units: 3 },
                { code: "FS 1", description: "Observation of Teaching-Learning in Actual School Environment", units: 3 },
                { code: "FS 2", description: "Participation and Teaching Assistantship", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "1st Trimester",
            subjects: [
                { code: "PRACTICUM", description: "Teaching Internship", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BSED-ENGLISH — Effective SY 2024-2025, CMO 75 s.2017
    ===================================================== */
    "BSED-ENGLISH": [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "NSTP 1", description: "Civic Welfare Training Service 1", units: 3 },
                { code: "CoEd 100", description: "The Child and Adolescent Learners and Learning Principles", units: 3 },
                { code: "CSEE 101", description: "Introduction to Linguistics", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 5", description: "Purposive Communication (with speech lab)", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology and Society", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service 2", units: 3 },
                { code: "CSEE 102", description: "Language Culture & Society", units: 3 },
                { code: "CSEE 103", description: "Structure of English", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "CoEd 103", description: "Facilitating Learner-Centered Teaching", units: 3 },
                { code: "CoEd 104", description: "The Teaching Profession", units: 3 },
                { code: "CSEE 104", description: "Principles and Theories of Language Acquisition and Learning", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "Elective 1E", description: "Stylistics & Discourse Analysis", units: 3 },
                { code: "CoEd 202", description: "The Teacher and the School Curriculum", units: 3 },
                { code: "CSEE 201", description: "Teaching and Assessment of the Macro Skills", units: 3 },
                { code: "CSEE 202", description: "Speech and Theater Arts (with Speech Lab)", units: 3 },
                { code: "CSEE 203", description: "Children and Adolescent Literature", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 },
                { code: "Elective 2E", description: "Creative Writing", units: 3 },
                { code: "TTL 1", description: "Technology for Teaching and Learning 1", units: 3 },
                { code: "CoEd 201", description: "Foundation of Special and Inclusive Education", units: 3 },
                { code: "CSEE 204", description: "Contemporary, Popular, and Emergent Literature", units: 3 },
                { code: "CSEE 205", description: "Teaching and Assessment of Grammar", units: 3 },
                { code: "CSEE 305", description: "Survey of Philippine Literature in English", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 12", description: "The Life and Works of Rizal", units: 3 },
                { code: "TTL 2E", description: "Technology for Teaching and Learning 2 (Technology in Language Education) with computer lab", units: 3 },
                { code: "CALE 1", description: "Assessment of Learning 1 (English)", units: 3 },
                { code: "CSEE 206", description: "Language Programs and Policies in Multilingual Societies", units: 3 },
                { code: "CSEE 207", description: "Mythology and Folklore", units: 3 },
                { code: "CSEE 208", description: "Survey of Afro-Asian Literature", units: 3 },
                { code: "CSEE 209", description: "Technical Writing", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "Research 1", description: "Introduction to Thesis Writing", units: 3 },
                { code: "CALE 2", description: "Assessment in Learning 2 (English)", units: 3 },
                { code: "SEM 1", description: "Seminar in Teaching MEFSS 1", units: 3 },
                { code: "CoEd 101", description: "Building and Enhancing New Literacies Across the Curriculum", units: 3 },
                { code: "CoEd 305", description: "The Teacher and the Community, School Culture and Organizational Leadership", units: 3 },
                { code: "CSEE 301", description: "Survey of English and American Literature", units: 3 },
                { code: "CSEE 303", description: "Campus Journalism (with Speech Lab)", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "SEM 2", description: "Seminar in Teaching MEFSS 2", units: 3 },
                { code: "CSEE 302", description: "Literary Criticism", units: 3 },
                { code: "CSEE 304", description: "Teaching and Assessment of Literature Studies", units: 3 },
                { code: "CSEE 306", description: "Language Learning Materials Development", units: 3 },
                { code: "CSEE 307", description: "Language Education Research", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Research 2", description: "Thesis Writing", units: 3 },
                { code: "FS 1", description: "Observation of Teaching-Learning in Actual School Environment", units: 3 },
                { code: "FS 2", description: "Participation and Teaching Assistantship", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "1st Trimester",
            subjects: [
                { code: "PRACTICUM", description: "Teaching Internship", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BSED-MATH — Effective SY 2024-2025, CMO 75 s.2017
    ===================================================== */
    "BSED-MATH": [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "NSTP 1", description: "Civic Welfare Training Service 1", units: 3 },
                { code: "CSEM 101", description: "History of Mathematics", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 5", description: "Purposive Communication (with speech lab)", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology and Society", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service 2", units: 3 },
                { code: "CoEd 100", description: "The Child and Adolescent Learners and Learning Principles", units: 3 },
                { code: "CSEM 102", description: "College and Advanced Algebra", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 },
                { code: "CoEd 101", description: "Building and Enhancing New Literacies Across the Curriculum", units: 3 },
                { code: "CoEd 104", description: "The Teaching Profession", units: 3 },
                { code: "CSEM 103", description: "Logic and Set Theory", units: 3 },
                { code: "CSEM 104", description: "Mathematics of Investment", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "CoEd 103", description: "Facilitating Learner-Centered Teaching", units: 3 },
                { code: "CSEM 201", description: "Plane and Solid Geometry", units: 3 },
                { code: "CSEM 203", description: "Trigonometry", units: 3 },
                { code: "CSEM 205", description: "Elementary Statistics & Probability", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 },
                { code: "CALM 1", description: "Assessment in Learning 1 (Mathematics)", units: 3 },
                { code: "CSEM 204", description: "Modern Geometry", units: 3 },
                { code: "CSEM 210", description: "Advanced Statistics", units: 3 },
                { code: "CSEM 206", description: "Number Theory", units: 3 },
                { code: "CSEM 207", description: "Linear Algebra", units: 3 },
                { code: "CSEM 202", description: "Abstract Algebra", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 12", description: "The Life and Works of Rizal", units: 3 },
                { code: "CALM 2", description: "Assessment in Learning 2 (Mathematics)", units: 3 },
                { code: "CSEM 208", description: "Calculus 1 (with Analytic Geometry)", units: 4 },
                { code: "CSEM 209", description: "Problem Solving, Mathematical Investigations and Modelling", units: 3 },
                { code: "CSEM 303", description: "Assessment and Evaluation in Mathematics", units: 3 },
                { code: "CSEM 301", description: "Principle and Strategies of Teaching Mathematics", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "SEM 1", description: "Seminar in Teaching MEFSS 1", units: 3 },
                { code: "CoEd 201", description: "Foundations of Special and Inclusive Education", units: 3 },
                { code: "TTL 1", description: "Technology for Teaching and Learning 1", units: 3 },
                { code: "CSEM 302", description: "Calculus II", units: 4 },
                { code: "CSEM 304", description: "Research in Mathematics", units: 4 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "Research 1", description: "Introduction to Thesis Writing", units: 3 },
                { code: "SEM 2", description: "Seminar in Teaching MEFSS 2", units: 3 },
                { code: "CoEd 202", description: "The Teacher and the School Curriculum", units: 3 },
                { code: "CoEd 305", description: "The Teacher and the Community, School Culture and Organizational Leadership", units: 3 },
                { code: "CSEM 305", description: "Calculus III", units: 3 },
                { code: "TTL 2M", description: "Technology for Teaching and Learning 2 (Instrumentation and Technology in Mathematics) with computer lab", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Research 2", description: "Thesis Writing", units: 3 },
                { code: "FS 1", description: "Observation of Teaching-Learning in Actual School Environment", units: 3 },
                { code: "FS 2", description: "Participation and Teaching Assistantship", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "1st Trimester",
            subjects: [
                { code: "PRACTICUM", description: "Teaching Internship", units: 6 }
            ]
        }
    ],


    /* =====================================================
       BSED-SOCIAL — Effective SY 2024-2025, CMO 75 s.2017
    ===================================================== */
    "BSED-SOCIAL": [
        {
            year: "1st Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 1", description: "Understanding the Self", units: 3 },
                { code: "GE 2", description: "Readings in Philippine History", units: 3 },
                { code: "GE 3", description: "The Contemporary World", units: 3 },
                { code: "GE 4", description: "Mathematics in the Modern World", units: 3 },
                { code: "NSTP 1", description: "Civic Welfare Training Service 1", units: 3 },
                { code: "CSES 101", description: "Geography 1 (Human Geography)", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "2nd Trimester",
            subjects: [
                { code: "GE 5", description: "Purposive Communication (with speech lab)", units: 3 },
                { code: "GE 6", description: "Art Appreciation", units: 3 },
                { code: "GE 7", description: "Science, Technology and Society", units: 3 },
                { code: "PATH Fit 1", description: "Movement Competency Training", units: 2 },
                { code: "NSTP 2", description: "Civic Welfare Training Service 2", units: 3 },
                { code: "CoEd 100", description: "The Child and Adolescent Learners and Learning Principles", units: 3 },
                { code: "CSES 102", description: "Geography 2 (Physical Geography)", units: 3 }
            ]
        },
        {
            year: "1st Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 8", description: "Ethics", units: 3 },
                { code: "GE 9", description: "Gender and Society", units: 3 },
                { code: "GE 10", description: "Philippine Popular Culture", units: 3 },
                { code: "CoEd 103", description: "Facilitating Learner-Centered Teaching", units: 3 },
                { code: "CoEd 104", description: "The Teaching Profession", units: 3 },
                { code: "CSES 103", description: "Geography 3 (Urban Geography)", units: 3 },
                { code: "PATH Fit 2", description: "Exercise-based Fitness Activity", units: 2 }
            ]
        },
        {
            year: "2nd Year", trimester: "1st Trimester",
            subjects: [
                { code: "GE 11", description: "Living in an IT Era", units: 3 },
                { code: "PATH Fit 3", description: "Dance and Sports", units: 2 },
                { code: "CoEd 202", description: "The Teacher and the School Curriculum", units: 3 },
                { code: "CSES 201", description: "Foundation of Social Studies", units: 3 },
                { code: "CSES 202", description: "Asian Studies", units: 3 },
                { code: "CSES 203", description: "Places and Landscape in a Changing World", units: 3 },
                { code: "CSES 204", description: "Micro Economics", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "PATH Fit 4", description: "Outdoor and Adventure Activities", units: 2 },
                { code: "CALS 1", description: "Assessment of Learning 1 (Social Studies)", units: 3 },
                { code: "CoEd 201", description: "Foundations of Special and Inclusive Education", units: 3 },
                { code: "CSES 205", description: "World History 1 (Ancient & Medieval Era)", units: 3 },
                { code: "CSES 206", description: "Macro Economics", units: 3 },
                { code: "CSES 207", description: "Integrative Methods in Teaching Social Science discipline in Basic Education", units: 3 }
            ]
        },
        {
            year: "2nd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "GE 12", description: "The Life and Works of Rizal", units: 3 },
                { code: "CSES 301", description: "Assessment and Evaluation in the Social Sciences", units: 3 },
                { code: "CALS 2", description: "Assessment of Learning 2 (Social Studies)", units: 3 },
                { code: "CSES 208", description: "World History 2 (Modern & Contemporary Era)", units: 3 },
                { code: "CSES 209", description: "Law-Related Studies", units: 3 },
                { code: "CSES 210", description: "Comparative Government and Politics", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "1st Trimester",
            subjects: [
                { code: "TTL 1", description: "Technology for Teaching and Learning 1", units: 3 },
                { code: "SEM 1", description: "Seminar in Teaching MEFSS", units: 3 },
                { code: "CoEd 101", description: "Building and Enhancing New Literacies Across the Curriculum", units: 3 },
                { code: "Elective 1S", description: "Basic of School Management and Administration", units: 3 },
                { code: "CSES 302", description: "Production of Social Studies Instructional Materials", units: 3 },
                { code: "CSES 303", description: "Research in Social Studies", units: 3 },
                { code: "CSES 304", description: "Socio-Cultural Anthropology", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "2nd Trimester",
            subjects: [
                { code: "Research 1", description: "Introduction to Thesis Writing", units: 3 },
                { code: "Elective 2S", description: "Human Resources Management", units: 3 },
                { code: "TTL 2S", description: "Technology for Teaching and Learning 2 (Social Studies) with computer lab", units: 3 },
                { code: "SEM 2", description: "Seminar in Teaching MEFSS", units: 3 },
                { code: "CoEd 305", description: "The Teacher and the Community, School Culture and Organizational Leadership", units: 3 },
                { code: "CSES 305", description: "Teaching Approach in Secondary Social Studies", units: 3 },
                { code: "CSES 306", description: "Comparative Economic Planning", units: 3 },
                { code: "CSES 307", description: "Trends and Issues in Social Studies", units: 3 }
            ]
        },
        {
            year: "3rd Year", trimester: "3rd Trimester",
            subjects: [
                { code: "Research 2", description: "Thesis Writing", units: 3 },
                { code: "FS 1", description: "Observation of Teaching-Learning in Actual School Environment", units: 3 },
                { code: "FS 2", description: "Participation and Teaching Assistantship", units: 3 }
            ]
        },
        {
            year: "4th Year", trimester: "1st Trimester",
            subjects: [
                { code: "PRACTICUM", description: "Teaching Internship", units: 6 }
            ]
        }
    ]

};


/* =========================================================
   PROGRAM NAMES
========================================================= */

const programNames = {

    "BSCS":
        "Bachelor of Science in Computer Science (BSCS)",

    "BSIS":
        "Bachelor of Science in Information Systems (BSIS)",

    "BSIT":
        "Bachelor of Science in Information Technology (BSIT)",

    "BSCRIM":
        "Bachelor of Science in Criminology (BS Crim)",

    "BSA":
        "Bachelor of Science in Accountancy (BSA)",

    "BSBA-FM":
        "Bachelor of Science in Business Administration Major in Financial Management",

    "BSBA-HRDM":
        "Bachelor of Science in Business Administration Major in Human Resource Development Management",

    "BSBA-MM":
        "Bachelor of Science in Business Administration Major in Marketing Management",

    "BEED":
        "Bachelor of Elementary Education (BEED)",

    "BSED-ENGLISH":
        "Bachelor of Secondary Education Major in English",

    "BSED-MATH":
        "Bachelor of Secondary Education Major in Mathematics",

    "BSED-SOCIAL":
        "Bachelor of Secondary Education Major in Social Studies"
};

/* =========================================================
   CUSTOM PROGRAMS (mula sa Admin -> Programs & Subjects)
   ---------------------------------------------------------
   Ang mga naka-hardcode sa itaas ay ang "factory" na prospectus.
   Ang mga BAGONG idinagdag na Course/Major/Subject/Trimester o
   Semester (via Admin) ay nakadatabase at ipinapadala ni
   dashboard.php bilang ASCB_CUSTOM_PROGRAMS / _NAMES /
   _TERM_TYPES (tingnan sa dulo ng dashboard.php, bago i-load
   ang script.js na ito) — dinadagdag lang sila dito sa parehong
   structures para awtomatiko silang "callable" sa Enrollment
   module (Course dropdown, Load Subjects for Term) nang hindi
   na kailangang galawin ang code sa taas.
   `programTermTypes` naman ang nagsasabi kung Trimester o
   Semester ang gagamitin ng bawat program code — default
   "Trimester" ang lahat ng naka-hardcode sa itaas.
========================================================= */
const programTermTypes = {};
if (typeof ASCB_CUSTOM_PROGRAMS !== "undefined" && ASCB_CUSTOM_PROGRAMS) {
    Object.assign(structuredPrograms, ASCB_CUSTOM_PROGRAMS);
}
if (typeof ASCB_CUSTOM_PROGRAM_NAMES !== "undefined" && ASCB_CUSTOM_PROGRAM_NAMES) {
    Object.assign(programNames, ASCB_CUSTOM_PROGRAM_NAMES);
}
if (typeof ASCB_CUSTOM_PROGRAM_TERM_TYPES !== "undefined" && ASCB_CUSTOM_PROGRAM_TERM_TYPES) {
    Object.assign(programTermTypes, ASCB_CUSTOM_PROGRAM_TERM_TYPES);
}

function ascbGetProgramTermType(programCode) {
    if (programCode && typeof programTermTypes !== "undefined" && programTermTypes[programCode]) {
        return programTermTypes[programCode];
    }
    return "Trimester";
}

function ascbTermOptionsFor(termType) {
    return termType === "Semester"
        ? ["1st Semester", "2nd Semester", "3rd Semester | Summer"]
        : ["1st Trimester", "2nd Trimester", "3rd Trimester"];
}

/* Ire-refresh ang mga <option> ng isang Trimester/Semester
   <select> base sa term system ng currently selected program,
   pati na ang kaukulang <label> text nito ("Trimester" o
   "Semester"). Tinatawag ito ni ascbEnrollProgramChanged(). */
function ascbEnrollUpdateTermSelect(trimesterSelectId, programCode) {

    const select = document.getElementById(trimesterSelectId);
    if (!select) return;

    const termType = ascbGetProgramTermType(programCode);
    const options = ascbTermOptionsFor(termType);
    const oldValue = select.value;

    select.innerHTML = `<option value="">Select ${termType}</option>` +
        options.map(o => `<option>${o}</option>`).join("");

    if (options.includes(oldValue)) {
        select.value = oldValue;
    }

    const label = document.querySelector(`label[for="${trimesterSelectId}"]`);
    if (label) label.textContent = termType;
}

/* Kinukuha ang pinaka-bagong Programs & Subjects mula sa server
   (Admin -> Programs & Subjects) at ini-merge sa structuredPrograms/
   programNames/programTermTypes, tapos ire-refresh ang mga
   Course/Program <select> sa Enrollment (Enroll / Edit / New Term)
   para agad lumabas ang bagong idinagdag, kahit hindi pa
   nirre-reload ang buong page. */
async function ascbRefreshCustomPrograms() {
    const data = await ascbApiPost("api/programs.php", { action: "structured" });
    if (!data || !data.ok) return;

    Object.assign(structuredPrograms, data.structured || {});
    Object.assign(programNames, data.names || {});
    Object.assign(programTermTypes, data.termTypes || {});

    const namesMap = data.names || {};
    ["enroll_program", "enroll_edit_program", "enroll_newterm_program"].forEach(selectId => {
        const select = document.getElementById(selectId);
        if (!select) return;

        const currentValue = select.value;
        select.querySelectorAll('option[data-custom="1"]').forEach(opt => opt.remove());

        Object.keys(namesMap).sort((a, b) => String(namesMap[a]).localeCompare(String(namesMap[b]))).forEach(code => {
            const option = document.createElement("option");
            option.value = code;
            option.textContent = namesMap[code];
            option.dataset.custom = "1";
            select.appendChild(option);
        });

        if ([...select.options].some(o => o.value === currentValue)) {
            select.value = currentValue;
        }
    });
}


/* =========================================================
   INITIALIZE
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadSubjects();

        addSubjectRow();

        setToday();

        setDefaultAcademicYear();

    }
);

/* =========================================================
   DEFAULT ACADEMIC YEAR
   Kinukwenta base sa kasalukuyang petsa sa halip na naka-hardcode
   na text, para hindi na kailangang i-update ito taon-taon.
   Karaniwang nagsisimula ang school year sa Pilipinas sa
   Agosto/Setyembre, kaya:
     - Jan–Jul  -> (lastYear)–(thisYear)
     - Aug–Dec  -> (thisYear)–(nextYear)
========================================================= */

function getDefaultAcademicYear() {
    const today = new Date();
    const year = today.getFullYear();
    const month = today.getMonth() + 1; // 1-12

    const startYear = month >= 8 ? year : year - 1;
    return `${startYear}\u2013${startYear + 1}`;
}

function setDefaultAcademicYear() {
    const input = document.getElementById("academicYear");
    if (input && !input.value.trim()) {
        input.value = getDefaultAcademicYear();
    }
}


/* =========================================================
   SET TODAY
========================================================= */

function setToday() {

    const dateInput =
        document.getElementById("enrollmentDate");

    if (!dateInput.value) {

        const today = new Date();

        const year = today.getFullYear();

        const month =
            String(today.getMonth() + 1).padStart(2, "0");

        const day =
            String(today.getDate()).padStart(2, "0");

        dateInput.value = `${year}-${month}-${day}`;
    }
}


/* =========================================================
   LOAD SUBJECT DROPDOWNS
   Every program is now a structured program (Year/Trimester
   optgroups), sourced directly from each program's official
   ASCB curriculum prospectus.
========================================================= */

/* =========================================================
   LOAD SUBJECT DROPDOWNS
   Fine-filtered by Program + Year Level + Trimester.
========================================================= */

function loadSubjects() {

    const selects =
        document.querySelectorAll(".subject-select");

    const program =
        document.getElementById("program").value;

    const isStructured =
        program && structuredPrograms[program];

    selects.forEach(
        select => {

            const oldValue = select.value;

            select.innerHTML =
                `
                <option value="">Select Subject</option>
                <option value="__CUSTOM__">+ Add Custom Subject</option>
                `;

            if (isStructured) {

                structuredPrograms[program].forEach(
                    group => {

                        const optgroup =
                            document.createElement("optgroup");

                        optgroup.label =
                            `${group.year} — ${group.trimester}`;

                        group.subjects.forEach(
                            subject => {

                                const option =
                                    document.createElement("option");

                                option.value =
                                    JSON.stringify(subject);

                                option.textContent =
                                    `${subject.code} — ${subject.description} (${subject.units} units)`;

                                optgroup.appendChild(option);
                            }
                        );

                        select.appendChild(optgroup);
                    }
                );

            }

            if (
                oldValue &&
                [...select.options].some(o => o.value === oldValue)
            ) {

                select.value = oldValue;
            }

        }
    );
}


/* =========================================================
   ADD SUBJECTS FOR TERM
   Uses the Year Level + Trimester already selected in
   STUDENT INFORMATION (no separate/duplicate selectors) and
   appends that term's prospectus subjects to the table,
   without clearing what's already there. Skips subjects
   already added (matched by course code) to avoid duplicates,
   and clears out the single unused starter row if present.
========================================================= */

function addSubjectsForTerm() {

    const program =
        document.getElementById("program").value;

    const year =
        document.getElementById("yearLevel").value;

    const trimester =
        document.getElementById("trimester").value;

    if (!program) {
        alert("Pumili muna ng Course / Program.");
        return;
    }

    if (!year || !trimester) {
        alert("Pumili muna ng Year Level at Trimester sa Student Information bago mag-load ng subjects.");
        return;
    }

    if (!structuredPrograms[program]) {
        alert("Walang structured prospectus ang program na ito.");
        return;
    }

    const group =
        structuredPrograms[program].find(
            g => g.year === year && g.trimester === trimester
        );

    if (!group) {
        alert("Walang nakatalang subjects para sa Year Level at Trimester na ito.");
        return;
    }

    /* Collect codes already present sa table, para
       hindi na madoble kapag pinindot ulit. */

    const existingCodes = new Set();

    document.querySelectorAll(".subject-row").forEach(
        row => {

            const code =
                row.dataset.customCode || getRowSubjectCode(row);

            if (code) {
                existingCodes.add(code);
            }
        }
    );

    /* If the table only has the untouched starter row (blank,
       nothing selected, nothing typed), drop it first so the
       loaded term doesn't leave a stray empty row behind. */

    removeUnusedStarterRow();

    let addedCount = 0;

    group.subjects.forEach(
        subject => {

            if (existingCodes.has(subject.code)) {
                return;
            }

            addSubjectRow(subject);

            addedCount++;
        }
    );

    calculateTotalUnits();

    if (addedCount === 0) {

        alert("Naidagdag na lahat ng subjects para sa term na ito.");
    }
}


/* =========================================================
   REMOVE UNUSED STARTER ROW
   Helper — if the subject table has exactly one row and it's
   completely empty (no subject picked, no custom code, no
   description typed), remove it. Keeps the table tidy when
   loading a term into a freshly-opened form.
========================================================= */

function removeUnusedStarterRow() {

    const rows =
        document.querySelectorAll(".subject-row");

    if (rows.length !== 1) {
        return;
    }

    const row = rows[0];

    const select = row.querySelector(".subject-select");
    const description = row.querySelector(".subject-description");

    const isEmpty =
        !row.dataset.customCode &&
        (!select || !select.value) &&
        (!description || !description.value.trim());

    if (isEmpty) {
        row.remove();
    }
}


/* =========================================================
   GET ROW SUBJECT CODE
   Helper — reads the course code currently selected in a
   subject row's dropdown (used for duplicate checking).
========================================================= */

function getRowSubjectCode(row) {

    const select = row.querySelector(".subject-select");

    if (!select || !select.value || select.value === "__CUSTOM__") {
        return null;
    }

    try {

        return JSON.parse(select.value).code;

    } catch (error) {

        return null;
    }
}


/* =========================================================
   ADD SUBJECT ROW
========================================================= */

function addSubjectRow(subjectData = null) {

    const tbody =
        document.getElementById("subjectRows");

    const row = document.createElement("tr");

    row.className = "subject-row";

    row.innerHTML =
        `
        <td>
            <select class="subject-select" onchange="selectSubject(this)">
                <option value="">Select Subject</option>
            </select>
        </td>

        <td>
            <input type="text" class="subject-description" placeholder="Course Description">
        </td>

        <td>
            <input type="text" class="subject-grade" placeholder="e.g. 1.5" oninput="calculateGWA()">
        </td>

        <td>
            <input type="number" class="subject-units" min="0" step="1" value="0" oninput="calculateTotalUnits()">
        </td>

        <td style="text-align:center">
            <button type="button" class="btn btn-danger action-icon-btn" title="Remove" aria-label="Remove" onclick="removeSubjectRow(this)">${ascbIcon('reject')}</button>
        </td>
        `;

    tbody.appendChild(row);

    loadSubjects();

    if (subjectData) {

        const select = row.querySelector(".subject-select");
        const description = row.querySelector(".subject-description");
        const units = row.querySelector(".subject-units");

        select.value = JSON.stringify(subjectData);
        description.value = subjectData.description;
        units.value = subjectData.units;
    }

    calculateTotalUnits();
}


/* =========================================================
   SELECT SUBJECT
========================================================= */

function selectSubject(select) {

    const row = select.closest(".subject-row");

    if (select.value === "__CUSTOM__") {

        const code = prompt("Enter Course Code:");

        if (!code) {
            select.value = "";
            return;
        }

        const description = prompt("Enter Course Description:");

        if (!description) {
            select.value = "";
            return;
        }

        const units = prompt("Enter Units:", "3");

        row.querySelector(".subject-description").value = description;
        row.querySelector(".subject-units").value = units || 0;

        /* Store custom code on row itself. */
        row.dataset.customCode = code;

        calculateTotalUnits();

        return;
    }

    if (!select.value) {

        row.querySelector(".subject-description").value = "";
        row.querySelector(".subject-units").value = 0;

        delete row.dataset.customCode;

        calculateTotalUnits();

        return;
    }

    try {

        const subject = JSON.parse(select.value);

        row.querySelector(".subject-description").value = subject.description;
        row.querySelector(".subject-units").value = subject.units;

        delete row.dataset.customCode;

        calculateTotalUnits();

    } catch (error) {

        console.error(error);
    }
}


/* =========================================================
   REMOVE SUBJECT
========================================================= */

function removeSubjectRow(button) {

    const rows =
        document.querySelectorAll(".subject-row");

    if (rows.length <= 1) {

        alert("At least one subject row is required.");

        return;
    }

    button.closest(".subject-row").remove();

    calculateTotalUnits();
}


/* =========================================================
   TOTAL UNITS
========================================================= */

function calculateTotalUnits() {

    const unitsInputs =
        document.querySelectorAll(".subject-units");

    let total = 0;

    unitsInputs.forEach(
        input => {

            const value = parseFloat(input.value) || 0;

            total += value;
        }
    );

    document.getElementById("totalUnitsInput").textContent = total;

    calculateGWA();
}


/* =========================================================
   GWA (GENERAL WEIGHTED AVERAGE)
   GWA = sum(grade x units) / sum(units), counting only rows
   that have both a valid numeric grade and units. Rows with
   a blank or non-numeric grade (e.g. INC, DRP) are excluded
   from the computation entirely.
========================================================= */

function calculateGWA() {

    const rows =
        document.querySelectorAll(".subject-row");

    let gradedUnits = 0;
    let weightedSum = 0;

    rows.forEach(
        row => {

            const gradeInput = row.querySelector(".subject-grade");
            const unitsInput = row.querySelector(".subject-units");

            if (!gradeInput || !unitsInput) {
                return;
            }

            const grade = parseFloat(gradeInput.value);
            const units = parseFloat(unitsInput.value) || 0;

            if (isNaN(grade) || units <= 0) {
                return;
            }

            weightedSum += grade * units;
            gradedUnits += units;
        }
    );

    const gwa =
        gradedUnits > 0
            ? (weightedSum / gradedUnits)
            : 0;

    const gwaCell =
        document.getElementById("gwaValueInput");

    if (gwaCell) {

        gwaCell.textContent =
            gradedUnits > 0
                ? gwa.toFixed(2)
                : "0.00";
    }

    return gwa;
}


/* =========================================================
   FORMAT DATE
========================================================= */

function formatDate(dateString) {

    if (!dateString) {

        return "________________";
    }

    const date = new Date(dateString + "T00:00:00");

    return date.toLocaleDateString(
        "en-US",
        { month: "long", day: "numeric", year: "numeric" }
    );
}


/* =========================================================
   ORDINAL DAY SUFFIX (1st, 2nd, 3rd, 4th... 25th...)
========================================================= */

function getOrdinalSuffix(day) {

    const remainder10 = day % 10;
    const remainder100 = day % 100;

    if (remainder10 === 1 && remainder100 !== 11) return "st";
    if (remainder10 === 2 && remainder100 !== 12) return "nd";
    if (remainder10 === 3 && remainder100 !== 13) return "rd";

    return "th";
}

function formatDateOrdinal(dateString) {

    if (!dateString) {

        return "________________";
    }

    const date = new Date(dateString + "T00:00:00");

    const month = date.toLocaleDateString("en-US", { month: "long" });
    const day = date.getDate();
    const year = date.getFullYear();

    return `${month} ${day}${getOrdinalSuffix(day)}, ${year}`;
}


/* =========================================================
   GENERATE CERTIFICATE
========================================================= */

/* =========================================================
   CERTIFICATE TYPE
========================================================= */

function changeCertificateType() {

    const certificateType =
        document.getElementById("certificateType").value;

    const title =
        document.getElementById("previewCertificateTitle");

    const intro =
        document.getElementById("certificateIntro");

    const summaryTitleText =
        document.getElementById("summaryTitleText");

    const certificationTextContent =
        document.getElementById("certificationTextContent");

    const headRow =
        document.getElementById("certTableHeadRow");

    const totalLabelCell =
        document.getElementById("certTotalLabelCell");

    const certificationTextBlock =
        document.getElementById("certificationTextBlock");

    const issuedDateBlock =
        document.getElementById("issuedDateBlock");

    const detailRowEnrollmentDate =
        document.getElementById("detailRowEnrollmentDate");

    const detailRowStatus =
        document.getElementById("detailRowStatus");

    const isGradeEvaluation =
        certificateType === "GRADE_EVALUATION";


    /* ===================================== GRADE EVALUATION — HIDE/SHOW BLOCKS
       Grade Evaluation drops the intro sentence, the certification
       text, the "Issued this..." line, and the Date of Enrollment /
       Status rows — everything else stays the same as Enrollment
       and Registration. */

    intro.style.display = isGradeEvaluation ? "none" : "";
    certificationTextBlock.style.display = isGradeEvaluation ? "none" : "";
    issuedDateBlock.style.display = isGradeEvaluation ? "none" : "";
    detailRowEnrollmentDate.style.display = isGradeEvaluation ? "none" : "";
    detailRowStatus.style.display = isGradeEvaluation ? "none" : "";

    document
        .querySelector(".signature-area")
        .classList.toggle("signature-area--grade-eval", isGradeEvaluation);


    /* ===================================== SUBJECT TABLE HEAD */

    if (isGradeEvaluation) {

        headRow.innerHTML = `
            <th class="code-column">Course Code</th>
            <th>Course Description</th>
            <th class="grades-column">Grades</th>
            <th class="units-column">Units</th>
        `;

    } else {

        headRow.innerHTML = `
            <th class="code-column">Course Code</th>
            <th>Course Description</th>
            <th class="units-column">Units</th>
        `;
    }

    totalLabelCell.colSpan = isGradeEvaluation ? 3 : 2;

    const certGwaRow =
        document.getElementById("certGwaRow");

    const certGwaLabelCell =
        document.getElementById("certGwaLabelCell");

    if (certGwaRow) {
        certGwaRow.style.display = isGradeEvaluation ? "" : "none";
    }

    if (certGwaLabelCell) {
        certGwaLabelCell.colSpan = isGradeEvaluation ? 3 : 2;
    }


    /* ===================================== SUMMARY & CERTIFICATION TEXT */

    summaryTitleText.textContent =
        isGradeEvaluation
            ? "Below is the Summary of the Student's Grades:"
            : "Below is the Summary of the Student's Enrollment:";

    certificationTextContent.textContent =
        isGradeEvaluation
            ? "This Grade Evaluation is issued upon the request of the student for whatever lawful purpose it may serve."
            : "This certification is issued upon the request of the student for whatever lawful purpose it may serve.";


    /* ===================================== TITLE & INTRO */

    if (isGradeEvaluation) {

        title.textContent = "GRADE EVALUATION";

        intro.innerHTML = `
            This is to certify that

            <strong id="previewStudentName">
                ______________________________
            </strong>

            is officially enrolled at

            <strong>
                Andres Soriano Colleges of Bislig, Inc.
            </strong>

            in the

            <strong id="previewProgram">
                ______________________________
            </strong>

            program, and has earned the following grades for the

            <strong id="previewTrimester">
                ______________________________
            </strong>,

            <strong>Academic Year</strong>

            <strong id="previewAcademicYear">
                ____________
            </strong>.
        `;

    } else if (certificateType === "REGISTRATION") {

        title.textContent = "CERTIFICATE OF REGISTRATION";

        intro.innerHTML = `
            This is to certify that

            <strong id="previewStudentName">
                ______________________________
            </strong>

            is officially enrolled at

            <strong>
                Andres Soriano Colleges of Bislig, Inc.
            </strong>

            in the

            <strong id="previewProgram">
                ______________________________
            </strong>

            program for the

            <strong id="previewTrimester">
                ______________________________
            </strong>,

            <strong>Academic Year</strong>

            <strong id="previewAcademicYear">
                ____________
            </strong>.
        `;

    } else {

        title.textContent = "CERTIFICATE OF ENROLLMENT";

        intro.innerHTML = `
            This is to certify that

            <strong id="previewStudentName">
                ______________________________
            </strong>

            is officially enrolled at

            <strong>
                Andres Soriano Colleges of Bislig, Inc.
            </strong>

            in the

            <strong id="previewProgram">
                ______________________________
            </strong>

            program for the

            <strong id="previewTrimester">
                ______________________________
            </strong>,

            <strong>Academic Year</strong>

            <strong id="previewAcademicYear">
                ____________
            </strong>.
        `;
    }
}

function generateCertificate() {

    const certificateType =
        document.getElementById("certificateType").value;

    changeCertificateType();

    const studentName =
        document.getElementById("studentName").value.trim();

    const studentId =
        document.getElementById("studentId").value.trim();

    const program =
        document.getElementById("program").value;

    const yearLevel =
        document.getElementById("yearLevel").value;

    const trimester =
        document.getElementById("trimester").value;

    const academicYear =
        document.getElementById("academicYear").value.trim();

    const enrollmentDate =
        document.getElementById("enrollmentDate").value;

    const status =
        document.getElementById("status").value;

    const orNumber =
        document.getElementById("orNumber").value.trim();

    const preparedBy =
        document.getElementById("preparedBy").value.trim();


    /* ========================================== VALIDATION */

    if (!studentName) {
        alert("Please enter the student's name.");
        return;
    }

    if (!studentId) {
        alert("Please enter the Student ID.");
        return;
    }

    if (!program) {
        alert("Please select a Course / Program.");
        return;
    }

    if (!yearLevel) {
        alert("Please select the Year Level.");
        return;
    }

    if (!trimester) {
        alert("Please select the Trimester.");
        return;
    }

    if (certificateType === "GRADE_EVALUATION") {

        const hasGrade =
            [...document.querySelectorAll(".subject-grade")].some(
                input => input.value.trim() !== ""
            );

        if (!hasGrade) {
            alert("Please type in at least one subject's grade before generating the Grade Evaluation.");
            return;
        }
    }


    /* ========================================== BASIC INFO */

    document.getElementById("previewStudentName").textContent = studentName;
    document.getElementById("previewName2").textContent = studentName;
    document.getElementById("previewStudentId").textContent = studentId;
    document.getElementById("previewProgram").textContent = programNames[program];
    document.getElementById("previewCourse").textContent = getShortProgram(program);
    document.getElementById("previewYearLevel").textContent = yearLevel;
    document.getElementById("previewTrimester").textContent = trimester;
    document.getElementById("previewTerm").textContent =
        `${trimester}, AY ${academicYear}`;
    document.getElementById("previewAcademicYear").textContent = academicYear;
    document.getElementById("previewEnrollmentDate").textContent =
        formatDate(enrollmentDate);
    document.getElementById("previewStatus").textContent = status;
    document.getElementById("previewOrNumber").textContent = orNumber || "—";
    document.getElementById("previewPreparedBy").textContent = preparedBy || "—";


    /* ========================================== SUBJECTS */

    const rows =
        document.querySelectorAll(".subject-row");

    const previewBody =
        document.getElementById("previewSubjects");

    previewBody.innerHTML = "";

    const isGradeEvaluation =
        certificateType === "GRADE_EVALUATION";

    let totalUnits = 0;
    let gwaWeightedSum = 0;
    let gwaGradedUnits = 0;
    const subjectsForLog = [];

    rows.forEach(
        row => {

            const select = row.querySelector(".subject-select");
            const description = row.querySelector(".subject-description");
            const grade = row.querySelector(".subject-grade");
            const units = row.querySelector(".subject-units");

            if (
                !description.value.trim() &&
                (!select.value || select.value === "__CUSTOM__")
            ) {
                return;
            }

            let code = "";

            if (row.dataset.customCode) {

                code = row.dataset.customCode;

            } else if (select.value && select.value !== "__CUSTOM__") {

                try {

                    const subject = JSON.parse(select.value);

                    code = subject.code;

                } catch (error) {

                    code = "";
                }
            }

            const unitValue = parseFloat(units.value) || 0;

            totalUnits += unitValue;

            const gradeValue = parseFloat(grade ? grade.value : "");

            if (!isNaN(gradeValue) && unitValue > 0) {

                gwaWeightedSum += gradeValue * unitValue;
                gwaGradedUnits += unitValue;
            }

            const tr = document.createElement("tr");

            tr.innerHTML =
                isGradeEvaluation
                    ? `
                        <td>${escapeHTML(code)}</td>
                        <td>${escapeHTML(description.value)}</td>
                        <td>${escapeHTML(grade ? grade.value.trim() : "")}</td>
                        <td>${unitValue}</td>
                        `
                    : `
                        <td>${escapeHTML(code)}</td>
                        <td>${escapeHTML(description.value)}</td>
                        <td>${unitValue}</td>
                        `;

            previewBody.appendChild(tr);

            subjectsForLog.push({
                code,
                description: description.value.trim(),
                grade: grade ? grade.value.trim() : "",
                units: unitValue
            });
        }
    );

    document.getElementById("previewTotalUnits").textContent = totalUnits;

    const previewGWACell =
        document.getElementById("previewGWA");

    if (previewGWACell) {

        previewGWACell.textContent =
            gwaGradedUnits > 0
                ? (gwaWeightedSum / gwaGradedUnits).toFixed(2)
                : "0.00";
    }


    /* ========================================== ISSUED DATE */

    document.getElementById("previewIssuedDate").textContent =
        formatDateOrdinal(new Date().toISOString().split("T")[0]);


    /* ========================================== LOG TO DATABASE */
    /* Hindi ito hinihintay (fire-and-forget) para hindi ma-delay
       ang pagpakita ng preview — nasa console lang kung may error. */

    ascbApiPost("api/certificates.php", {
        certificateType,
        studentName,
        studentId,
        program,
        yearLevel,
        trimester,
        academicYear,
        enrollmentDate,
        status,
        orNumber,
        totalUnits,
        gwa: gwaGradedUnits > 0 ? (gwaWeightedSum / gwaGradedUnits).toFixed(2) : null,
        preparedBy,
        subjects: subjectsForLog
    }).then(result => {
        if (!result.ok) console.error("Certificate log failed:", result.error);
    });


    /* ========================================== OPEN MODAL */

    document.getElementById("certificateModal").classList.add("active");
}


/* =========================================================
   SHORT PROGRAM
========================================================= */

function getShortProgram(program) {

    const shortNames = {

        "BSCS": "BSCS",
        "BSIS": "BSIS",
        "BSIT": "BSIT",
        "BSCRIM": "BS Crim",
        "BSA": "BSA",
        "BSBA-FM": "BSBA-FM",
        "BSBA-HRDM": "BSBA-HRDM",
        "BSBA-MM": "BSBA-MM",
        "BEED": "BEED",
        "BSED-ENGLISH": "BSED-English",
        "BSED-MATH": "BSED-Mathematics",
        "BSED-SOCIAL": "BSED-Social Studies"
    };

    return shortNames[program] || program;
}


/* =========================================================
   ESCAPE HTML
========================================================= */

function escapeHTML(value) {

    return String(value)
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;");
}


/* =========================================================
   ACTION ICONS
   ---------------------------------------------------------
   Simple SVG line-icons na ginagamit sa mga action button
   (View, Update, Delete, atbp.) sa halip na text label.
   Gumagamit ng currentColor kaya sumusunod ito sa kulay ng
   button (btn-outline, btn-danger-solid, atbp). May title
   (tooltip) at aria-label pa rin ang bawat button kaya
   malinaw pa rin kung ano ang gagawin nito kahit icon lang.
   ========================================================= */

const ASCB_ICON_PATHS = {
    view: '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z"/><circle cx="12" cy="12" r="3"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z"/>',
    delete: '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M10 11v6"/><path d="M14 11v6"/>',
    deleteForever: '<path d="M3 6h18"/><path d="M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/><path d="M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/><path d="M9.5 11l5 5"/><path d="M14.5 11l-5 5"/>',
    approve: '<path d="M20 6L9 17l-5-5"/>',
    reject: '<path d="M18 6L6 18"/><path d="M6 6l12 12"/>',
    newTerm: '<rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4"/><path d="M8 2v4"/><path d="M3 10h18"/><path d="M12 14v6"/><path d="M9 17h6"/>',
    restore: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    viewGrades: '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-4"/>',
    activate: '<path d="M12 2v6"/><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/>',
    deactivate: '<path d="M12 2v6"/><path d="M18.36 6.64a9 9 0 1 1-12.73 0"/>',
};

function ascbIcon(name, label) {
    const path = ASCB_ICON_PATHS[name] || "";
    const safeLabel = escapeHTML(label || "");
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" ` +
        `stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">${path}</svg>` +
        (safeLabel ? `<span class="sr-only">${safeLabel}</span>` : "");
}


/* =========================================================
   CLOSE CERTIFICATE
========================================================= */

function closeCertificate() {

    document.getElementById("certificateModal").classList.remove("active");
}


/* =========================================================
   PRINT CERTIFICATE — ONE COPY ONLY
========================================================= */

function printCertificate() {

    const printArea = document.getElementById("printArea");

    if (!printArea) {
        alert("Certificate print area not found.");
        return;
    }

    const printWindow = window.open(
        "",
        "_blank",
        "width=900,height=1000"
    );

    if (!printWindow) {
        alert("Please allow pop-ups for this website to print the certificate.");
        return;
    }

    const styles = [...document.querySelectorAll("link[rel='stylesheet'], style")]
        .map(style => {
            if (style.tagName === "STYLE") {
                return `<style>${style.innerHTML}</style>`;
            }

            return `<link rel="stylesheet" href="${style.href}">`;
        })
        .join("");

    printWindow.document.open();

    printWindow.document.write(`
        <!DOCTYPE html>
        <html lang="en">
        <head>

            <meta charset="UTF-8">

            <title>${document.getElementById("previewCertificateTitle").textContent}</title>

            ${styles}

            <style>

                @page {
                    size: Letter portrait;
                    margin: 0;
                }

                html,
                body {
                    width: 8.5in;
                    height: 11in;
                    margin: 0;
                    padding: 0;
                    background: #ffffff;
                    overflow: hidden;
                }

                body {
                    font-family: "Poppins", Arial, sans-serif;
                }

                .print-area {
                    width: 8.5in !important;
                    height: 11in !important;
                    min-height: 11in !important;
                    max-height: 11in !important;

                    margin: 0 !important;
                    padding: 0 !important;

                    overflow: hidden !important;

                    box-shadow: none !important;
                    background: #ffffff !important;
                }

                /* WATERMARK */

                .watermark-container {
                    position: absolute !important;

                    left: 0 !important;
                    right: 0 !important;

                    top: 2.20in !important;
                    bottom: 0 !important;

                    display: flex !important;
                    align-items: center !important;
                    justify-content: center !important;

                    overflow: hidden !important;

                    z-index: 1 !important;
                    pointer-events: none !important;
                }

                .document-watermark {
                    position: relative !important;

                    width: 4.35in !important;
                    height: 4.35in !important;

                    max-width: 4.35in !important;
                    max-height: 4.35in !important;

                    transform: none !important;

                    display: block !important;
                    visibility: visible !important;

                    object-fit: contain !important;

                    opacity: 0.055 !important;

                    z-index: 1 !important;
                    pointer-events: none !important;
                }

                .document-content {
                    position: relative !important;
                    z-index: 3 !important;
                }

                .document-header {
                    position: relative !important;
                    z-index: 5 !important;
                }

                .student-details,
                .certificate-title,
                .certificate-intro,
                .summary-title,
                .certificate-table,
                .certification-text,
                .signature-area {
                    position: relative !important;
                    z-index: 3 !important;
                }

                /* HIDE UI CONTROLS */

                button,
                .btn,
                .modal-toolbar,
                .modal-overlay {
                    display: none !important;
                }

                /* PRINT COLORS */

                * {
                    -webkit-print-color-adjust: exact !important;
                    print-color-adjust: exact !important;
                }

            </style>

        </head>

        <body>

            ${printArea.outerHTML}

        </body>
        </html>
    `);

    printWindow.document.close();

    printWindow.focus();

    /*
       Wait for logo/fonts/images to finish loading
       before opening print dialog.
    */

    setTimeout(() => {

        printWindow.print();

        /*
           Close the temporary print window
           after printing.
        */

        setTimeout(() => {
            printWindow.close();
        }, 500);

    }, 700);
}

/* =========================================================
   CLEAR FORM
========================================================= */

function clearForm() {

    const confirmation =
        confirm("Clear all enrollment information and subjects?");

    if (!confirmation) {
        return;
    }

    document.getElementById("studentName").value = "";
    document.getElementById("studentId").value = "";
    document.getElementById("program").value = "";
    document.getElementById("yearLevel").value = "";
    document.getElementById("trimester").value = "";
    document.getElementById("academicYear").value = getDefaultAcademicYear();
    document.getElementById("status").value = "OFFICIALLY ENROLLED";
    document.getElementById("orNumber").value = "";

    /* "Prepared By" is auto-credited to the logged-in user,
       so re-apply it instead of clearing it. */
    ascbInitPreparedBy();

    setToday();

    document.getElementById("subjectRows").innerHTML = "";

    addSubjectRow();

    calculateTotalUnits();
}

function closeModal() {

    const modal = document.getElementById("certificateModal");

    if (modal) {

        modal.classList.remove("active");
    }
}

document.addEventListener("keydown", function (event) {

    if (event.key === "Escape") {

        closeModal();
    }
});


/* =========================================================
   FORM 137 REQUEST MODULE
   Added to the ASCB Certificate System
========================================================= */

const F137_SCHOOLS_KEY = "ascb_form137_schools";
const F137_COURSES_KEY = "ascb_form137_courses";
const F137_FORM_KEY = "ascb_form137_current_form";
const F137_MAX_STUDENTS = 8;

const F137_DEFAULT_SCHOOLS = [
    { name: "ANDRES SORIANO COLLEGES OF BISLIG, INC.", address: "Mangagoy, Bislig City" },
    { name: "TABON M. ESTRELLA NATIONAL HIGH SCHOOL", address: "Tabon, Bislig City" },
    { name: "STAND ALONE SENIOR HIGH SCHOOL", address: "Comawas, Bislig City" },
    { name: "SOUTHERN TECHNOLOGICAL INSTITUTE OF THE PHILIPPINES, INC.", address: "Andres Soriano Avenue, Mangagoy, Bislig City" },
    { name: "AGUSAN NATIONAL HIGH SCHOOL", address: "Butuan City, Surigao del Sur" },
    { name: "BERNARDO D. CARPIO NATIONAL HIGH SCHOOL", address: "Pioneer Village, Buhangin, Davao City" },
    { name: "BISLIG CITY NATIONAL HIGH SCHOOL", address: "Purok 10 Villa Josefa Poblacion, Bislig City" },
    { name: "HINATUAN NATIONAL COMPREHENSIVE HIGH SCHOOL", address: "Sto. Niño, Hinatuan, Surigao del Sur" },
    { name: "LAWIGAN NATIONAL HIGH SCHOOL", address: "Lawigan, Bislig City" },
    { name: "LINGIG NATIONAL HIGH SCHOOL", address: "Lingig 1 District" },
    { name: "MAHARLIKA NATIONAL HIGH SCHOOL", address: "Maharlika, Bislig City" }
];

const F137_DEFAULT_COURSES = [
    "BSIT", "BSCS", "BSIS", "BEED", "BSBA-MM", "BSBA-FM", "BSBA-HRDM", "BSED-ENGLISH"
];

let f137Students = [];

function f137El(id) {
    return document.getElementById(id);
}

function f137Escape(value) {
    const div = document.createElement("div");
    div.textContent = value == null ? "" : String(value);
    return div.innerHTML;
}

function f137Today() {
    const d = new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function f137FormatDate(value) {
    if (!value) return "";
    const d = new Date(value + "T00:00:00");
    if (Number.isNaN(d.getTime())) return "";
    return d.toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
}

/* =========================================================
   SCHOOLS / COURSES — now backed by the MySQL database
   (`schools` / `courses` tables) instead of localStorage.
   dashboard.php injects the current lists as ASCB_SCHOOLS /
   ASCB_COURSES on page load; we keep an in-memory cache here
   so the dropdowns can be updated instantly after an Add/
   Delete without a full page reload, then sync to the DB via
   fetch() to api/schools.php and api/courses.php.
   ========================================================= */

let ascbSchoolsCache = (typeof ASCB_SCHOOLS !== "undefined" && Array.isArray(ASCB_SCHOOLS))
    ? ASCB_SCHOOLS.map(s => ({ name: s.name, address: s.address || "" }))
    : [...F137_DEFAULT_SCHOOLS];

let ascbCoursesCache = (typeof ASCB_COURSES !== "undefined" && Array.isArray(ASCB_COURSES))
    ? [...ASCB_COURSES]
    : [...F137_DEFAULT_COURSES];

function f137GetSchools() {
    return ascbSchoolsCache;
}

function f137GetCourses() {
    return ascbCoursesCache;
}

/* Kept as a harmless no-op so any old callers don't break —
   ang starter data ay nasa database na (database/ascb_registrar.sql),
   hindi na sa localStorage. */
function f137InitStorage() {}

async function ascbApiPost(url, payload) {
    try {
        const response = await fetch(url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });
        return await response.json();
    } catch (error) {
        console.error("API request failed:", url, error);
        return { ok: false, error: "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page." };
    }
}

function f137LoadSchools(selected = "") {
    const select = f137El("f137_schoolSelect");
    if (!select) return;
    select.innerHTML = `<option value="">Select School</option>`;
    f137GetSchools().forEach(school => {
        const option = document.createElement("option");
        option.value = school.name;
        option.textContent = school.name;
        option.dataset.address = school.address || "";
        select.appendChild(option);
    });
    if (selected) {
        select.value = selected;
        f137UpdateSchoolAddress();
    }
}

function f137LoadCourses(selected = "") {
    const select = f137El("f137_courseSelect");
    if (!select) return;
    select.innerHTML = `<option value="">Select Course</option>`;
    f137GetCourses().forEach(course => {
        const option = document.createElement("option");
        option.value = course;
        option.textContent = course;
        select.appendChild(option);
    });
    if (selected) select.value = selected;
}

function f137UpdateSchoolAddress() {
    const select = f137El("f137_schoolSelect");
    const address = f137El("f137_schoolAddress");
    const option = select.options[select.selectedIndex];
    if (option && select.value) address.value = option.dataset.address || "";
}

/* Kept as a thin alias to the view switch: some buttons still
   call openForm137() by habit, and it now behaves exactly like
   navigating to Certificates does — no separate init needed,
   since f137Setup() below already prepares the view on load. */
function openForm137() {
    if (typeof ascbNavigate === "function") ascbNavigate("form137");
}

function ascbToggleF137ActionsPanel() {
    const panel = f137El("f137ActionsPanel");
    if (panel) panel.classList.toggle("collapsed");
}

function closeForm137Preview() {
    const modal = f137El("form137PreviewModal");
    if (modal) modal.classList.remove("active");
}

function f137Setup() {
    f137InitStorage();
    f137LoadSchools();
    f137LoadCourses();
    f137El("f137_requestDate").value = f137Today();

    f137El("f137_schoolSelect").addEventListener("change", () => {
        f137UpdateSchoolAddress();
        f137UpdatePreview();
        f137Save();
    });

    f137El("f137_schoolAddress").addEventListener("input", () => {
        f137UpdatePreview();
        f137Save();
    });

    ["f137_requestDate","f137_firstRequest","f137_secondRequest","f137_urgentRequest","f137_bearerRequest","f137_copyForASCB"]
        .forEach(id => {
            const el = f137El(id);
            el.addEventListener("input", () => { f137UpdatePreview(); f137Save(); });
            el.addEventListener("change", () => { f137UpdatePreview(); f137Save(); });
        });

    ["f137_studentName","f137_schoolYear","f137_yearSection"].forEach(id => {
        const el = f137El(id);
        el.addEventListener("input", f137Save);
    });

    f137El("f137_schoolSelect").addEventListener("dblclick", f137DeleteSelectedSchool);
    f137El("f137_courseSelect").addEventListener("dblclick", f137DeleteSelectedCourse);

    f137El("f137_firstRequest").addEventListener("change", () => {
        if (f137El("f137_firstRequest").checked) f137El("f137_secondRequest").checked = false;
        f137UpdatePreview(); f137Save();
    });

    f137El("f137_secondRequest").addEventListener("change", () => {
        if (f137El("f137_secondRequest").checked) f137El("f137_firstRequest").checked = false;
        f137UpdatePreview(); f137Save();
    });

    f137LoadSaved();
    f137UpdatePreview();
}

function addF137Student() {
    const name = f137El("f137_studentName").value.trim();
    const course = f137El("f137_courseSelect").value;
    const year = f137El("f137_schoolYear").value.trim();
    const section = f137El("f137_yearSection").value.trim();

    if (!name || !course || !year || !section) {
        alert("Kumpletuhin muna ang Student Name, Course, School Year, at Year & Section.");
        return;
    }

    if (f137Students.length >= F137_MAX_STUDENTS) {
        alert(`Maximum ${F137_MAX_STUDENTS} students per request.`);
        return;
    }

    f137Students.push({ name, course, schoolYear: year, yearSection: section });

    f137El("f137_studentName").value = "";
    f137El("f137_courseSelect").value = "";
    f137El("f137_schoolYear").value = "";
    f137El("f137_yearSection").value = "";

    f137RenderStudentList();
    f137UpdatePreview();
    f137Save();
    f137El("f137_studentName").focus();
}

function f137RemoveStudent(index) {
    f137Students.splice(index, 1);
    f137RenderStudentList();
    f137UpdatePreview();
    f137Save();
}

function f137RenderStudentList() {
    const container = f137El("f137_studentsList");
    container.innerHTML = "";
    f137Students.forEach((student, index) => {
        const item = document.createElement("div");
        item.className = "f137-student-chip";
        item.innerHTML = `
            <span>
                <span class="f137-student-chip-name">${index + 1}. ${f137Escape(student.name)}</span>
                <span class="f137-student-chip-meta">${f137Escape(student.course)} • ${f137Escape(student.schoolYear)} • ${f137Escape(student.yearSection)}</span>
            </span>
            <button type="button" class="f137-remove-student" onclick="f137RemoveStudent(${index})">×</button>
        `;
        container.appendChild(item);
    });
}

function f137BuildRows() {
    if (f137Students.length) return f137Students;
    return [{
        name: f137El("f137_studentName").value.trim() || "STUDENT NAME",
        course: f137El("f137_courseSelect").value || "COURSE",
        schoolYear: f137El("f137_schoolYear").value.trim() || "SCHOOL YEAR",
        yearSection: f137El("f137_yearSection").value.trim() || "YEAR & SECTION"
    }];
}

function f137UpdatePreview() {
    const rows = f137BuildRows();
    const school = f137El("f137_schoolSelect").value || "ANDRES SORIANO COLLEGES OF BISLIG, INC.";
    const address = f137El("f137_schoolAddress").value.trim() || "Mangagoy, Bislig City";
    const plural = rows.length > 1;

    f137El("f137_previewDate").textContent = f137FormatDate(f137El("f137_requestDate").value);
    f137El("f137_previewSchool").textContent = school;
    f137El("f137_previewSchoolAddress").textContent = address;
    f137El("f137_pluralTag").textContent = plural ? "s" : "";
    f137El("f137_pluralTag2").textContent = plural ? "s" : "";
    f137El("f137_isAreTag").textContent = plural ? "are" : "is";

    const body = f137El("f137_studentTableBody");
    body.innerHTML = "";
    rows.forEach(student => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
            <td>${f137Escape(student.name)}</td>
            <td>${f137Escape(student.course)}</td>
            <td>${f137Escape(student.schoolYear)}</td>
            <td>${f137Escape(student.yearSection)}</td>
        `;
        body.appendChild(tr);
    });

    const checks = [
        ["f137_checkFirst","f137_firstRequest"],
        ["f137_checkSecond","f137_secondRequest"],
        ["f137_checkUrgent","f137_urgentRequest"],
        ["f137_checkBearer","f137_bearerRequest"],
        ["f137_checkCopy","f137_copyForASCB"]
    ];
    checks.forEach(([target, source]) => {
        f137El(target).classList.toggle("active", !!f137El(source).checked);
    });
}

function generateForm137() {
    const hasPending =
        f137El("f137_studentName").value.trim() ||
        f137El("f137_courseSelect").value ||
        f137El("f137_schoolYear").value.trim() ||
        f137El("f137_yearSection").value.trim();

    if (hasPending) {
        const name = f137El("f137_studentName").value.trim();
        const course = f137El("f137_courseSelect").value;
        const year = f137El("f137_schoolYear").value.trim();
        const section = f137El("f137_yearSection").value.trim();

        if (name && course && year && section && f137Students.length < F137_MAX_STUDENTS) {
            f137Students.push({ name, course, schoolYear: year, yearSection: section });
            f137El("f137_studentName").value = "";
            f137El("f137_courseSelect").value = "";
            f137El("f137_schoolYear").value = "";
            f137El("f137_yearSection").value = "";
            f137RenderStudentList();
        }
    }

    f137UpdatePreview();

    if (!f137Students.length) {
        alert("Mag-add muna ng kahit isang student.");
        return;
    }

    if (!f137El("f137_schoolSelect").value) {
        alert("Pumili muna ng receiving school.");
        return;
    }

    f137Save();

    /* Log sa database — fire-and-forget, hindi hinihintay bago
       ipakita ang preview. */
    ascbApiPost("api/form137.php", {
        requestDate: f137El("f137_requestDate")?.value || "",
        school: f137El("f137_schoolSelect")?.value || "",
        schoolAddress: f137El("f137_schoolAddress")?.value || "",
        firstRequest: !!f137El("f137_firstRequest")?.checked,
        secondRequest: !!f137El("f137_secondRequest")?.checked,
        urgentRequest: !!f137El("f137_urgentRequest")?.checked,
        bearerRequest: !!f137El("f137_bearerRequest")?.checked,
        copyForASCB: !!f137El("f137_copyForASCB")?.checked,
        students: f137Students
    }).then(result => {
        if (!result.ok) console.error("Form 137 request log failed:", result.error);
    });

    const modal = f137El("form137PreviewModal");
    if (modal) modal.classList.add("active");
}

function f137OpenMini(id) {
    f137El(id).classList.add("active");
}

function f137CloseMiniDialogs() {
    ["f137SchoolDialog","f137CourseDialog"].forEach(id => {
        const el = f137El(id);
        if (el) el.classList.remove("active");
    });
}

function openF137SchoolDialog() {
    f137El("f137_newSchoolName").value = "";
    f137El("f137_newSchoolAddress").value = "";
    f137OpenMini("f137SchoolDialog");
    setTimeout(() => f137El("f137_newSchoolName").focus(), 50);
}

function closeF137SchoolDialog() {
    f137El("f137SchoolDialog").classList.remove("active");
}

async function saveF137School() {
    const name = f137El("f137_newSchoolName").value.trim();
    const address = f137El("f137_newSchoolAddress").value.trim();
    if (!name) { alert("Enter the school name."); return; }

    if (ascbSchoolsCache.some(s => s.name.toLowerCase() === name.toLowerCase())) {
        alert("This school is already saved.");
        return;
    }

    const result = await ascbApiPost("api/schools.php", { action: "add", name, address });
    if (!result.ok) {
        alert(result.error || "Hindi na-save ang school.");
        return;
    }

    ascbSchoolsCache.push({ name, address });
    f137LoadSchools(name);
    f137El("f137_schoolAddress").value = address;
    closeF137SchoolDialog();
    f137UpdatePreview();
    f137Save();
}

function openF137CourseDialog() {
    f137El("f137_newCourseName").value = "";
    f137OpenMini("f137CourseDialog");
    setTimeout(() => f137El("f137_newCourseName").focus(), 50);
}

function closeF137CourseDialog() {
    f137El("f137CourseDialog").classList.remove("active");
}

async function saveF137Course() {
    const course = f137El("f137_newCourseName").value.trim();
    if (!course) { alert("Enter the course name."); return; }

    if (ascbCoursesCache.some(c => c.toLowerCase() === course.toLowerCase())) {
        alert("This course is already saved.");
        return;
    }

    const result = await ascbApiPost("api/courses.php", { action: "add", name: course });
    if (!result.ok) {
        alert(result.error || "Hindi na-save ang course.");
        return;
    }

    ascbCoursesCache.push(course);
    f137LoadCourses(course);
    closeF137CourseDialog();
    f137Save();
}

async function f137DeleteSelectedSchool() {
    const select = f137El("f137_schoolSelect");
    if (!select.value) return;
    if (!confirm("Remove this school from the saved dropdown?")) return;

    const name = select.value;
    const result = await ascbApiPost("api/schools.php", { action: "delete", name });
    if (!result.ok) {
        alert(result.error || "Hindi na-delete ang school.");
        return;
    }

    ascbSchoolsCache = ascbSchoolsCache.filter(s => s.name !== name);
    f137LoadSchools();
    f137El("f137_schoolAddress").value = "";
    f137UpdatePreview();
    f137Save();
}

async function f137DeleteSelectedCourse() {
    const select = f137El("f137_courseSelect");
    if (!select.value) return;
    if (!confirm("Remove this course from the saved dropdown?")) return;

    const name = select.value;
    const result = await ascbApiPost("api/courses.php", { action: "delete", name });
    if (!result.ok) {
        alert(result.error || "Hindi na-delete ang course.");
        return;
    }

    ascbCoursesCache = ascbCoursesCache.filter(c => c !== name);
    f137LoadCourses();
    f137Save();
}

function f137Save() {
    const data = {
        students: f137Students,
        school: f137El("f137_schoolSelect")?.value || "",
        schoolAddress: f137El("f137_schoolAddress")?.value || "",
        studentName: f137El("f137_studentName")?.value || "",
        course: f137El("f137_courseSelect")?.value || "",
        schoolYear: f137El("f137_schoolYear")?.value || "",
        yearSection: f137El("f137_yearSection")?.value || "",
        requestDate: f137El("f137_requestDate")?.value || "",
        firstRequest: !!f137El("f137_firstRequest")?.checked,
        secondRequest: !!f137El("f137_secondRequest")?.checked,
        urgentRequest: !!f137El("f137_urgentRequest")?.checked,
        bearerRequest: !!f137El("f137_bearerRequest")?.checked,
        copyForASCB: !!f137El("f137_copyForASCB")?.checked
    };
    sessionStorage.setItem(F137_FORM_KEY, JSON.stringify(data));
}

function f137LoadSaved() {
    try {
        const saved = sessionStorage.getItem(F137_FORM_KEY);
        if (!saved) {
            f137RenderStudentList();
            return;
        }
        const data = JSON.parse(saved);
        f137Students = Array.isArray(data.students) ? data.students : [];
        f137LoadSchools(data.school || "");
        f137El("f137_schoolAddress").value = data.schoolAddress || f137El("f137_schoolAddress").value;
        f137LoadCourses(data.course || "");
        f137El("f137_studentName").value = data.studentName || "";
        f137El("f137_schoolYear").value = data.schoolYear || "";
        f137El("f137_yearSection").value = data.yearSection || "";
        f137El("f137_requestDate").value = data.requestDate || f137Today();
        f137El("f137_firstRequest").checked = !!data.firstRequest;
        f137El("f137_secondRequest").checked = !!data.secondRequest;
        f137El("f137_urgentRequest").checked = !!data.urgentRequest;
        f137El("f137_bearerRequest").checked = !!data.bearerRequest;
        f137El("f137_copyForASCB").checked = !!data.copyForASCB;
        f137RenderStudentList();
    } catch (error) {
        console.error("Form 137 load error:", error);
    }
}

function clearForm137() {
    if (!confirm("Clear all Form 137 request information?")) return;
    f137Students = [];
    ["f137_studentName","f137_schoolYear","f137_yearSection","f137_schoolAddress"].forEach(id => {
        f137El(id).value = "";
    });
    f137El("f137_courseSelect").value = "";
    f137El("f137_schoolSelect").value = "";
    f137El("f137_requestDate").value = f137Today();
    ["f137_firstRequest","f137_secondRequest","f137_urgentRequest","f137_bearerRequest","f137_copyForASCB"].forEach(id => {
        f137El(id).checked = false;
    });
    f137RenderStudentList();
    f137UpdatePreview();
    f137Save();
}

function printForm137() {
    // Update preview bago mag-print
    f137UpdatePreview();

    const area = document.getElementById("f137PrintArea");
    const modal = document.getElementById("form137PreviewModal");

    if (!area || !modal) {
        alert("Form 137 print area is not available.");
        return;
    }

    if (!f137Students || f137Students.length === 0) {
        alert("Mag-add muna ng kahit isang student bago mag-print.");
        return;
    }

    const schoolSelect = document.getElementById("f137_schoolSelect");

    if (!schoolSelect || !schoolSelect.value) {
        alert("Pumili muna ng receiving school bago mag-print.");
        return;
    }

    // Ipakita ang preview
    modal.classList.add("active");

    // Activate print mode
    document.body.classList.add("f137-printing");

    // Cleanup pagkatapos lamang ng print
    const cleanup = () => {
        document.body.classList.remove("f137-printing");
        window.removeEventListener("afterprint", cleanup);
    };

    window.addEventListener("afterprint", cleanup);

    // Hintayin munang ma-render ang lahat
    const startPrint = () => {

        // Force browser layout refresh
        area.offsetHeight;

        requestAnimationFrame(() => {
            requestAnimationFrame(() => {

                window.print();

            });
        });
    };

    // Hintayin ang fonts
    if (document.fonts && document.fonts.ready) {

        document.fonts.ready.then(startPrint);

    } else {

        startPrint();

    }
}

/* =========================================================
   DASHBOARD STATS — Enrollment Overview
   TOTAL ENROLLED (isang beses lang bawat estudyante kahit
   ilang term na siya), MALE/FEMALE, at breakdown kada
   Course/Program — mula sa api/dashboard_stats.php.
   ========================================================= */

async function ascbLoadDashboardStats() {
    const status = document.getElementById("dashboardStatsStatus");
    const cards = document.getElementById("dashboardStatsCards");
    const courseStats = document.getElementById("dashboardCourseStats");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading…";
    }
    if (cards) cards.style.display = "none";
    if (courseStats) courseStats.style.display = "none";

    try {
        const trimester = document.getElementById("dashboardTrimesterFilter")
            ? document.getElementById("dashboardTrimesterFilter").value
            : "";
        const response = await fetch("api/dashboard_stats.php?trimester=" + encodeURIComponent(trimester));
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang dashboard stats. Subukan muli.";
            return;
        }

        const totalEl = document.getElementById("dashboardStatTotal");
        const maleEl = document.getElementById("dashboardStatMale");
        const femaleEl = document.getElementById("dashboardStatFemale");
        if (totalEl) totalEl.textContent = Number(data.totalEnrolled || 0).toLocaleString();
        if (maleEl) maleEl.textContent = Number(data.male || 0).toLocaleString();
        if (femaleEl) femaleEl.textContent = Number(data.female || 0).toLocaleString();

        const byCourse = Array.isArray(data.byCourse) ? data.byCourse : [];
        if (courseStats) {
            courseStats.innerHTML = byCourse.length
                ? byCourse.map(row => `
                    <div class="dashboard-course-item">
                        <span class="dashboard-course-name">${escapeHTML(row.course || "Unspecified")}</span>
                        <div class="dashboard-course-breakdown">
                            <span class="dashboard-course-count is-male">♂ Male: <strong>${Number(row.male || 0).toLocaleString()}</strong></span>
                            <span class="dashboard-course-count is-female">♀ Female: <strong>${Number(row.female || 0).toLocaleString()}</strong></span>
                            <span class="dashboard-course-count is-total">Total: <strong>${Number(row.total || 0).toLocaleString()}</strong></span>
                        </div>
                    </div>
                `).join("")
                : `<div class="dashboard-course-item-empty">Wala pang enrolled na estudyante.</div>`;
        }

        if (status) status.style.display = "none";
        if (cards) cards.style.display = "grid";
        if (courseStats) courseStats.style.display = "grid";

    } catch (error) {
        console.error("Dashboard stats load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

/* "📊 Report" button — ini-export bilang Excel file ang kasalukuyang
   Enrollment Overview (parehong datos na nakikita sa cards/breakdown
   sa itaas), naka-filter ayon sa napiling Trimester. Simpleng GET
   navigation lang ito papunta sa api/dashboard_stats_export.php,
   kaya awtomatikong mag-do-download ang browser ng file. */
function ascbExportDashboardReport() {
    const trimester = document.getElementById("dashboardTrimesterFilter")
        ? document.getElementById("dashboardTrimesterFilter").value
        : "";
    window.location.href = "api/dashboard_stats_export.php?trimester=" + encodeURIComponent(trimester);
}


/* =========================================================
   DARK MODE / THEME
   Theme is stored in localStorage ("ascbTheme": "light" |
   "dark") and applied via a `data-theme` attribute on
   <html>. The attribute itself is already set as early as
   possible by an inline script in dashboard.php's <head> so
   there is no light-mode flash on load — this section just
   keeps every on-screen switch (sidebar quick toggle +
   Settings > Appearance) in sync with that state.
   ========================================================= */

function ascbGetTheme() {
    return localStorage.getItem("ascbTheme") === "dark" ? "dark" : "light";
}

function ascbApplyTheme(theme) {
    const isDark = theme === "dark";
    document.documentElement.setAttribute("data-theme", isDark ? "dark" : "light");
    localStorage.setItem("ascbTheme", isDark ? "dark" : "light");
    ascbSyncThemeControls(isDark);
}

function ascbToggleTheme() {
    ascbApplyTheme(ascbGetTheme() === "dark" ? "light" : "dark");
}

function ascbSyncThemeControls(isDark) {
    document.querySelectorAll("[data-theme-switch]").forEach((el) => {
        el.setAttribute("aria-checked", isDark ? "true" : "false");
        el.classList.toggle("is-dark", isDark);
    });
    document.querySelectorAll("[data-theme-quick-toggle]").forEach((el) => {
        el.innerHTML = isDark
            ? '<span class="theme-quick-toggle-icon">☀</span> Light Mode'
            : '<span class="theme-quick-toggle-icon">🌙</span> Dark Mode';
    });
    document.querySelectorAll("[data-theme-status]").forEach((el) => {
        el.textContent = isDark ? "Dark mode is on." : "Light mode is on.";
    });
}

document.addEventListener("DOMContentLoaded", () => {
    ascbSyncThemeControls(ascbGetTheme() === "dark");
    const gradeMgmtNav = document.getElementById("navGradeManagement");
    if (gradeMgmtNav && typeof ASCB_PERMISSIONS !== "undefined" && !ASCB_PERMISSIONS.manageGrades) gradeMgmtNav.style.display = "none";
    f137Setup();
    ascbDocsSetup();
    ascbLoadDashboardStats();
    // initBlueFireworks(); // temporarily disabled
});


/* =========================================================
   PAGINATION HELPER (reusable sa Records, Docs, at Approved SO
   tables). Client-side lang ang pagination — ang buong filtered
   na listahan ang hinahati sa "pages" base sa ASCB_PAGE_SIZE.
   ========================================================= */

const ASCB_PAGE_SIZE = 12;

/* Ibinabalik: { pageRows, page, totalPages, total, start }
   - pageRows  = mga row na ipapakita sa kasalukuyang page
   - page      = na-clamp na page number (1-based)
   - totalPages, total = para sa "Showing X–Y of Z" at buttons */
function ascbPaginate(rows, page, pageSize) {
    const total = rows.length;
    const totalPages = Math.max(1, Math.ceil(total / pageSize));
    const clampedPage = Math.min(Math.max(1, page || 1), totalPages);
    const start = (clampedPage - 1) * pageSize;
    const pageRows = rows.slice(start, start + pageSize);
    return { pageRows, page: clampedPage, totalPages, total, start };
}

/* Nagre-render ng "Showing X–Y of Z" + Prev/Next/page-number
   buttons sa loob ng elemento na may id = containerId.
   onPageChangeFn = pangalan (string) ng global function na
   tatawagin kapag pinindot ang isang page button, e.g.
   "ascbRecordsGoToPage". */
function ascbRenderPagination(containerId, page, totalPages, total, pageSize, onPageChangeFn) {
    const el = document.getElementById(containerId);
    if (!el) return;

    if (!total) {
        el.innerHTML = "";
        return;
    }

    const start = (page - 1) * pageSize + 1;
    const end = Math.min(page * pageSize, total);

    const maxButtons = 5;
    let startPage = Math.max(1, page - Math.floor(maxButtons / 2));
    let endPage = Math.min(totalPages, startPage + maxButtons - 1);
    startPage = Math.max(1, endPage - maxButtons + 1);

    let numberButtons = "";
    for (let p = startPage; p <= endPage; p++) {
        numberButtons += `<button type="button" class="pagination-btn${p === page ? " active" : ""}" ${p === page ? 'aria-current="page"' : ""} onclick="${onPageChangeFn}(${p})">${p}</button>`;
    }

    el.innerHTML = `
        <div class="pagination-info">Showing ${start}–${end} of ${total}</div>
        <div class="pagination-controls">
            <button type="button" class="pagination-btn pagination-nav" ${page <= 1 ? "disabled" : ""} onclick="${onPageChangeFn}(${page - 1})">‹ Prev</button>
            ${numberButtons}
            <button type="button" class="pagination-btn pagination-nav" ${page >= totalPages ? "disabled" : ""} onclick="${onPageChangeFn}(${page + 1})">Next ›</button>
        </div>`;
}


/* =========================================================
   RECORDS VIEW MODULE
   Nagpapakita ng mga naka-log na Certificates at Form 137-A
   requests mula sa database, sa pamamagitan ng api/records.php.
   Ino-fetch lang ito kapag pumunta ang user sa Records view
   (tingnan ang onclick ng "Records" button sa dashboard.php).
   ========================================================= */

let ascbRecordsType = "certificates";
let ascbRecordsRows = [];
let ascbRecordsFilteredCache = [];
let ascbRecordsPage = 1;

function ascbRecordsEl(id) {
    return document.getElementById(id);
}

async function ascbLoadRecords(forceType) {
    const type = forceType || ascbRecordsType;
    ascbRecordsType = type;

    const status = ascbRecordsEl("recordsStatus");
    const wrapper = ascbRecordsEl("recordsTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    try {
        const response = await fetch(`api/records.php?type=${encodeURIComponent(type)}&limit=500`);
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang records. Subukan muli.";
            return;
        }

        ascbRecordsRows = Array.isArray(data.rows) ? data.rows : [];
        ascbRecordsPage = 1;
        ascbRecordsRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Records load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

function ascbRecordsSwitchTab(type) {
    ascbRecordsType = type;

    const certTab = ascbRecordsEl("recordsTabCertificates");
    const f137Tab = ascbRecordsEl("recordsTabForm137");
    if (certTab) certTab.classList.toggle("active", type === "certificates");
    if (f137Tab) f137Tab.classList.toggle("active", type === "form137");

    const search = ascbRecordsEl("recordsSearchInput");
    if (search) search.value = "";

    ascbLoadRecords(type);
}

function ascbRecordsFilter() {
    ascbRecordsPage = 1;
    ascbRecordsRenderTable();
}

function ascbRecordsGoToPage(page) {
    ascbRecordsPage = page;
    ascbRecordsRenderTable();
}

function ascbRecordsCertLabel(type) {
    if (type === "ENROLLMENT") return "Enrollment";
    if (type === "REGISTRATION") return "Registration";
    if (type === "GRADE_EVALUATION") return "Grade Evaluation";
    return type || "—";
}

function ascbRecordsFormatDate(value, withTime) {
    if (!value) return "—";
    const d = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return value;
    const datePart = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    if (!withTime) return datePart;
    const timePart = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    return `${datePart}, ${timePart}`;
}

function ascbRecordsRenderTable() {
    const head = ascbRecordsEl("recordsTableHead");
    const body = ascbRecordsEl("recordsTableBody");
    if (!head || !body) return;

    const term = (ascbRecordsEl("recordsSearchInput")?.value || "").trim().toLowerCase();

    if (ascbRecordsType === "form137") {

        head.innerHTML = `
            <tr>
                <th>Date</th>
                <th>Receiving School</th>
                <th>Students</th>
                <th>Flags</th>
                <th>Requested By</th>
                <th></th>
            </tr>`;

        const filtered = ascbRecordsRows.filter(row => {
            if (!term) return true;
            const studentNames = (row.students || []).map(s => s.name || "").join(" ").toLowerCase();
            return (row.school_name || "").toLowerCase().includes(term) || studentNames.includes(term);
        });

        ascbRecordsFilteredCache = filtered;

        if (!filtered.length) {
            body.innerHTML = `<tr><td colspan="6" class="records-empty">Walang nahanap na record.</td></tr>`;
            ascbRenderPagination("recordsPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");
            return;
        }

        const { pageRows, page, totalPages, total, start } = ascbPaginate(filtered, ascbRecordsPage, ASCB_PAGE_SIZE);
        ascbRecordsPage = page;

        body.innerHTML = pageRows.map((row, i) => {
            const idx = start + i;
            const flags = [];
            if (Number(row.first_request) === 1) flags.push("1st");
            if (Number(row.second_request) === 1) flags.push("2nd");
            if (Number(row.urgent_request) === 1) flags.push("Urgent");
            if (Number(row.bearer_request) === 1) flags.push("Bearer");
            if (Number(row.copy_for_ascb) === 1) flags.push("Copy-ASCB");

            const studentCount = (row.students || []).length;

            return `
                <tr>
                    <td data-label="Date">${escapeHTML(ascbRecordsFormatDate(row.request_date))}</td>
                    <td data-label="Receiving School">${escapeHTML(row.school_name || "")}</td>
                    <td data-label="Students">${studentCount} student${studentCount === 1 ? "" : "s"}</td>
                    <td data-label="Flags">${escapeHTML(flags.join(", ") || "—")}</td>
                    <td data-label="Requested By">${escapeHTML(row.requested_by_name || "—")}</td>
                    <td data-label="Action"><button type="button" class="btn btn-outline records-view-btn action-icon-btn" title="View" aria-label="View" onclick="ascbRecordsShowDetail('form137', ${idx})">${ascbIcon('view')}</button></td>
                </tr>`;
        }).join("");

        ascbRenderPagination("recordsPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");

    } else {

        head.innerHTML = `
            <tr>
                <th>Date</th>
                <th>Type</th>
                <th>Student</th>
                <th>Student ID</th>
                <th>Program</th>
                <th>OR No.</th>
                <th>Prepared By</th>
                <th></th>
            </tr>`;

        const filtered = ascbRecordsRows.filter(row => {
            if (!term) return true;
            return (
                (row.student_name || "").toLowerCase().includes(term) ||
                (row.student_id || "").toLowerCase().includes(term) ||
                (row.or_number || "").toLowerCase().includes(term)
            );
        });

        ascbRecordsFilteredCache = filtered;

        if (!filtered.length) {
            body.innerHTML = `<tr><td colspan="8" class="records-empty">Walang nahanap na record.</td></tr>`;
            ascbRenderPagination("recordsPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");
            return;
        }

        const { pageRows, page, totalPages, total, start } = ascbPaginate(filtered, ascbRecordsPage, ASCB_PAGE_SIZE);
        ascbRecordsPage = page;

        body.innerHTML = pageRows.map((row, i) => {
            const idx = start + i;
            const programLabel = (typeof getShortProgram === "function" ? getShortProgram(row.program) : null) || row.program || "";
            return `
                <tr>
                    <td data-label="Date">${escapeHTML(ascbRecordsFormatDate(row.created_at, true))}</td>
                    <td data-label="Type">${escapeHTML(ascbRecordsCertLabel(row.certificate_type))}</td>
                    <td data-label="Student">${escapeHTML(row.student_name || "")}</td>
                    <td data-label="Student ID">${escapeHTML(row.student_id || "")}</td>
                    <td data-label="Program">${escapeHTML(programLabel)}</td>
                    <td data-label="OR No.">${escapeHTML(row.or_number || "—")}</td>
                    <td data-label="Prepared By">${escapeHTML(row.prepared_by || row.issued_by_name || "—")}</td>
                    <td data-label="Action"><button type="button" class="btn btn-outline records-view-btn action-icon-btn" title="View" aria-label="View" onclick="ascbRecordsShowDetail('certificates', ${idx})">${ascbIcon('view')}</button></td>
                </tr>`;
        }).join("");

        ascbRenderPagination("recordsPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbRecordsGoToPage");
    }
}

function ascbRecordsShowDetail(type, idx) {
    const row = ascbRecordsFilteredCache[idx];
    if (!row) return;

    const modal = ascbRecordsEl("recordsDetailModal");
    const title = ascbRecordsEl("recordsDetailTitle");
    const body = ascbRecordsEl("recordsDetailBody");
    if (!modal || !title || !body) return;

    if (type === "form137") {

        title.textContent = `Form 137-A Request — ${row.school_name || ""}`;

        const studentRows = (row.students || []).map(s => `
            <tr>
                <td>${escapeHTML(s.name || "")}</td>
                <td>${escapeHTML(s.course || "")}</td>
                <td>${escapeHTML(s.schoolYear || "")}</td>
                <td>${escapeHTML(s.yearSection || "")}</td>
            </tr>`).join("");

        body.innerHTML = `
            <p><strong>Request Date:</strong> ${escapeHTML(ascbRecordsFormatDate(row.request_date))}</p>
            <p><strong>Receiving School:</strong> ${escapeHTML(row.school_name || "")}</p>
            <p><strong>Address:</strong> ${escapeHTML(row.school_address || "—")}</p>
            <p><strong>Requested By:</strong> ${escapeHTML(row.requested_by_name || "—")}</p>
            <table class="f137-student-table">
                <thead><tr><th>Name</th><th>Admitted To</th><th>School Year</th><th>Year &amp; Section</th></tr></thead>
                <tbody>${studentRows || `<tr><td colspan="4">—</td></tr>`}</tbody>
            </table>`;

    } else {

        title.textContent = `${ascbRecordsCertLabel(row.certificate_type)} — ${row.student_name || ""}`;

        const subjectRows = (row.subjects || []).map(s => `
            <tr>
                <td>${escapeHTML(s.code || "")}</td>
                <td>${escapeHTML(s.description || "")}</td>
                <td>${escapeHTML(s.grade || "—")}</td>
                <td>${escapeHTML(s.units ?? "")}</td>
            </tr>`).join("");

        body.innerHTML = `
            <p><strong>Student:</strong> ${escapeHTML(row.student_name || "")} (${escapeHTML(row.student_id || "")})</p>
            <p><strong>Program:</strong> ${escapeHTML(row.program || "")} — ${escapeHTML(row.year_level || "")}, ${escapeHTML(row.trimester || "")}</p>
            <p><strong>Academic Year:</strong> ${escapeHTML(row.academic_year || "—")}</p>
            <p><strong>OR No.:</strong> ${escapeHTML(row.or_number || "—")} &nbsp; <strong>Total Units:</strong> ${escapeHTML(String(row.total_units ?? "—"))} &nbsp; <strong>GWA:</strong> ${escapeHTML(String(row.gwa ?? "—"))}</p>
            <p><strong>Prepared By:</strong> ${escapeHTML(row.prepared_by || row.issued_by_name || "—")}</p>
            <table class="f137-student-table">
                <thead><tr><th>Code</th><th>Description</th><th>Grade</th><th>Units</th></tr></thead>
                <tbody>${subjectRows || `<tr><td colspan="4">—</td></tr>`}</tbody>
            </table>`;
    }

    modal.classList.add("active");
}

function ascbCloseRecordsDetail() {
    const modal = ascbRecordsEl("recordsDetailModal");
    if (modal) modal.classList.remove("active");
}

document.addEventListener("keydown", function (event) {
    if (event.key !== "Escape") return;
    const modal = ascbRecordsEl("recordsDetailModal");
    if (modal && modal.classList.contains("active")) {
        ascbCloseRecordsDetail();
    }
    const enrollModal = document.getElementById("enrollDetailModal");
    if (enrollModal && enrollModal.classList.contains("active")) {
        ascbEnrollCloseDetail();
    }
});


/* =========================================================
   RELEASING & RECEIVING MODULE
   Nag-lo-log ng mga papasok/palabas na dokumento (may PDF
   attachment/s bawat entry) gamit ang api/documents.php.
   Ino-fetch lang ang listahan kapag pumunta ang user sa
   Releasing & Receiving view (tingnan ang onclick sa
   dashboard.php).
   ========================================================= */

let ascbDocsRows = [];
let ascbDocsDirectionFilter = "";
let ascbDocsPage = 1;

function ascbDocsEl(id) {
    return document.getElementById(id);
}

function ascbDocsSetup() {
    const directionSelect = ascbDocsEl("docs_direction");
    if (directionSelect) {
        directionSelect.addEventListener("change", ascbDocsUpdatePartyLabel);
        ascbDocsUpdatePartyLabel();
    }
}

function ascbDocsUpdatePartyLabel() {
    const direction = ascbDocsEl("docs_direction") ? ascbDocsEl("docs_direction").value : "RELEASED";
    const label = ascbDocsEl("docs_partyNameLabel");
    if (label) label.textContent = direction === "RECEIVED" ? "Received From" : "Released To";
}

function ascbDocsFormatDate(value, withTime) {
    if (!value) return "—";
    const d = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return value;
    const datePart = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    if (!withTime) return datePart;
    const timePart = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    return `${datePart}, ${timePart}`;
}

async function ascbLoadDocuments() {
    const status = ascbDocsEl("docsStatus");
    const wrapper = ascbDocsEl("docsTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    try {
        const params = new URLSearchParams();
        if (ascbDocsDirectionFilter) params.set("direction", ascbDocsDirectionFilter);
        params.set("limit", "500");

        const response = await fetch(`api/documents.php?${params.toString()}`);
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang records. Subukan muli.";
            return;
        }

        ascbDocsRows = Array.isArray(data.rows) ? data.rows : [];
        ascbDocsPage = 1;
        ascbDocsRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Documents load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

function ascbDocsSwitchTab(direction) {
    ascbDocsDirectionFilter = direction;

    const all = ascbDocsEl("docsTabAll");
    const released = ascbDocsEl("docsTabReleased");
    const received = ascbDocsEl("docsTabReceived");
    if (all) all.classList.toggle("active", direction === "");
    if (released) released.classList.toggle("active", direction === "RELEASED");
    if (received) received.classList.toggle("active", direction === "RECEIVED");

    const search = ascbDocsEl("docsSearchInput");
    if (search) search.value = "";

    ascbLoadDocuments();
}

function ascbDocsFilter() {
    ascbDocsPage = 1;
    ascbDocsRenderTable();
}

function ascbDocsGoToPage(page) {
    ascbDocsPage = page;
    ascbDocsRenderTable();
}

function ascbDocsRenderTable() {
    const body = ascbDocsEl("docsTableBody");
    if (!body) return;

    const term = (ascbDocsEl("docsSearchInput") ? ascbDocsEl("docsSearchInput").value : "").trim().toLowerCase();

    const filtered = ascbDocsRows.filter(row => {
        if (!term) return true;
        return (
            (row.document_name || "").toLowerCase().includes(term) ||
            (row.party_name || "").toLowerCase().includes(term)
        );
    });

    if (!filtered.length) {
        body.innerHTML = `<tr><td colspan="8" class="records-empty">Walang nahanap na record.</td></tr>`;
        ascbRenderPagination("docsPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbDocsGoToPage");
        return;
    }

    const { pageRows, page, totalPages, total } = ascbPaginate(filtered, ascbDocsPage, ASCB_PAGE_SIZE);
    ascbDocsPage = page;

    body.innerHTML = pageRows.map(row => {
        const badge = row.direction === "RECEIVED"
            ? `<span class="docs-badge docs-badge-received">Received</span>`
            : `<span class="docs-badge docs-badge-released">Released</span>`;

        const files = (row.files || []).map(f =>
            `<a href="api/document_file.php?id=${encodeURIComponent(f.id)}" target="_blank" rel="noopener" class="docs-file-chip">📄 ${escapeHTML(f.name)}</a>`
        ).join("");

        return `
            <tr>
                <td data-label="Date">${escapeHTML(ascbDocsFormatDate(row.transaction_date))}</td>
                <td data-label="Type">${badge}</td>
                <td data-label="Document">${escapeHTML(row.document_name || "")}</td>
                <td data-label="Released To / Received From">${escapeHTML(row.party_name || "")}</td>
                <td data-label="Files">${files || "—"}</td>
                <td data-label="Handled By">${escapeHTML(row.handled_by_name || "—")}</td>
                <td data-label="Remarks">${escapeHTML(row.remarks || "—")}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="Update" aria-label="Update" onclick="ascbDocsOpenEdit(${row.id})">${ascbIcon('edit')}</button>
                    
                </td>
            </tr>`;
    }).join("");

    ascbRenderPagination("docsPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbDocsGoToPage");
}

async function ascbDocsSubmit() {
    const direction = ascbDocsEl("docs_direction") ? ascbDocsEl("docs_direction").value : "RELEASED";
    const documentName = ascbDocsEl("docs_documentName") ? ascbDocsEl("docs_documentName").value.trim() : "";
    const partyName = ascbDocsEl("docs_partyName") ? ascbDocsEl("docs_partyName").value.trim() : "";
    const date = ascbDocsEl("docs_date") ? ascbDocsEl("docs_date").value : "";
    const remarks = ascbDocsEl("docs_remarks") ? ascbDocsEl("docs_remarks").value.trim() : "";
    const filesInput = ascbDocsEl("docs_files");

    const partyLabel = direction === "RECEIVED" ? "Received From" : "Released To";

    if (!documentName || !partyName) {
        alert(`Kailangan ng Document Name at ${partyLabel}.`);
        return;
    }

    const files = filesInput && filesInput.files ? Array.from(filesInput.files) : [];
    for (const file of files) {
        const looksLikePdf = (file.type && file.type === "application/pdf") || file.name.toLowerCase().endsWith(".pdf");
        if (!looksLikePdf) {
            alert(`${file.name} ay hindi PDF file.`);
            return;
        }
    }

    const formData = new FormData();
    formData.append("direction", direction);
    formData.append("documentName", documentName);
    formData.append("partyName", partyName);
    formData.append("transactionDate", date);
    formData.append("remarks", remarks);
    files.forEach(file => formData.append("documents[]", file));

    const status = ascbDocsEl("docsFormStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Sino-save…";
    }

    try {
        const response = await fetch("api/documents.php", {
            method: "POST",
            body: formData
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        if (status) {
            status.textContent = "Na-save!";
            setTimeout(() => { status.style.display = "none"; }, 1500);
        }

        ascbDocsEl("docs_documentName").value = "";
        ascbDocsEl("docs_partyName").value = "";
        ascbDocsEl("docs_date").value = "";
        ascbDocsEl("docs_remarks").value = "";
        if (filesInput) filesInput.value = "";

        ascbLoadDocuments();

    } catch (error) {
        console.error("Document save failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon.";
    }
}

function ascbDocsOpenEdit(id) {
    const row = ascbDocsRows.find(r => Number(r.id) === Number(id));
    if (!row) return;

    ascbDocsEl("docs_edit_id").value = row.id;
    ascbDocsEl("docs_edit_direction").value = row.direction === "RECEIVED" ? "RECEIVED" : "RELEASED";
    ascbDocsEl("docs_edit_documentName").value = row.document_name || "";
    ascbDocsEl("docs_edit_partyName").value = row.party_name || "";
    ascbDocsEl("docs_edit_date").value = row.transaction_date ? String(row.transaction_date).slice(0, 10) : "";
    ascbDocsEl("docs_edit_remarks").value = row.remarks || "";
    if (ascbDocsEl("docs_edit_files")) ascbDocsEl("docs_edit_files").value = "";

    ascbDocsRenderEditFilesList(row.files || []);

    const status = ascbDocsEl("docsEditStatus");
    if (status) status.style.display = "none";

    ascbDocsEl("docsEditModal").classList.add("active");
}

function ascbDocsRenderEditFilesList(files) {
    const container = ascbDocsEl("docs_edit_filesList");
    if (!container) return;

    if (!files.length) {
        container.innerHTML = `<span style="font-size:12px; color: var(--muted);">Walang naka-attach na file.</span>`;
        return;
    }

    container.innerHTML = files.map(f => `
        <span class="docs-file-chip">
            📄 ${escapeHTML(f.name)}
            <a href="javascript:void(0)" onclick="ascbDocsDeleteFileFromEdit(${f.id})" style="margin-left:6px; color: var(--danger, #a92720); font-weight:700; text-decoration:none;" title="Remove this file">✕</a>
        </span>
    `).join("");
}

async function ascbDocsDeleteFileFromEdit(fileId) {
    if (!confirm("Tanggalin ang file na ito mula sa entry?")) return;

    try {
        const formData = new FormData();
        formData.append("action", "delete_file");
        formData.append("file_id", fileId);

        const response = await fetch("api/documents.php", { method: "POST", body: formData });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi natanggal ang file.");
            return;
        }

        // I-refresh ang listahan sa likod at ang mini-list sa loob ng modal
        await ascbLoadDocuments();
        const id = ascbDocsEl("docs_edit_id") ? ascbDocsEl("docs_edit_id").value : null;
        const row = ascbDocsRows.find(r => Number(r.id) === Number(id));
        ascbDocsRenderEditFilesList(row ? (row.files || []) : []);

    } catch (error) {
        console.error("Delete file failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}

function ascbDocsCloseEdit() {
    ascbDocsEl("docsEditModal").classList.remove("active");
}

async function ascbDocsSubmitEdit() {
    const id = ascbDocsEl("docs_edit_id") ? ascbDocsEl("docs_edit_id").value : "";
    const direction = ascbDocsEl("docs_edit_direction") ? ascbDocsEl("docs_edit_direction").value : "RELEASED";
    const documentName = ascbDocsEl("docs_edit_documentName") ? ascbDocsEl("docs_edit_documentName").value.trim() : "";
    const partyName = ascbDocsEl("docs_edit_partyName") ? ascbDocsEl("docs_edit_partyName").value.trim() : "";
    const date = ascbDocsEl("docs_edit_date") ? ascbDocsEl("docs_edit_date").value : "";
    const remarks = ascbDocsEl("docs_edit_remarks") ? ascbDocsEl("docs_edit_remarks").value.trim() : "";
    const filesInput = ascbDocsEl("docs_edit_files");

    if (!documentName || !partyName) {
        alert("Kailangan ng Document Name at Released To/Received From.");
        return;
    }

    const files = filesInput && filesInput.files ? Array.from(filesInput.files) : [];
    for (const file of files) {
        const looksLikePdf = (file.type && file.type === "application/pdf") || file.name.toLowerCase().endsWith(".pdf");
        if (!looksLikePdf) {
            alert(`${file.name} ay hindi PDF file.`);
            return;
        }
    }

    const formData = new FormData();
    formData.append("action", "update");
    formData.append("id", id);
    formData.append("direction", direction);
    formData.append("documentName", documentName);
    formData.append("partyName", partyName);
    formData.append("transactionDate", date);
    formData.append("remarks", remarks);
    files.forEach(file => formData.append("documents[]", file));

    const status = ascbDocsEl("docsEditStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Sino-save…";
    }

    try {
        const response = await fetch("api/documents.php", { method: "POST", body: formData });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        ascbDocsCloseEdit();
        ascbLoadDocuments();

    } catch (error) {
        console.error("Document update failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon.";
    }
}

async function ascbDocsDelete(id) {
    if (!confirm("Sigurado ka bang gusto mong i-delete ang buong entry na ito, kasama lahat ng naka-attach na files?")) return;

    try {
        const formData = new FormData();
        formData.append("action", "delete");
        formData.append("id", id);

        const response = await fetch("api/documents.php", { method: "POST", body: formData });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi na-delete. Subukan muli.");
            return;
        }

        ascbLoadDocuments();

    } catch (error) {
        console.error("Document delete failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}


/* =========================================================
   ENROLLMENT
   Basic info ng estudyante bawat entry (Surname, Given Name,
   Middle Name, Birth Date, Address, Previous School — Junior
   HS at Senior HS). May Add, Edit, at Delete.
   ========================================================= */

let ascbEnrollRows = [];

/* Normalized grouping key para sa isang estudyante — pareho ang
   logic dito sa ascbGradeEvalStudentKey (student_id kung meron,
   kundi Surname + Given Name + Middle Name). Ginagamit para
   malaman kung aling mga row sa `enrollees` ay iisang estudyante
   lang (maraming term). */
function ascbEnrollStudentKey(row) {
    return (row.student_id || "").trim() || [row.surname, row.first_name, row.middle_name]
        .map(v => (v || "").trim().toLowerCase())
        .join("|");
}

/* Kapag maraming term (row) ang iisang estudyante lang (dahil sa
   "New Term"), sa TABLE view lang dapat lumabas ang PINAKABAGONG
   term niya — hindi dapat magparami/magduplicate ng row per
   estudyante. HINDI ito nagde-delete ng kahit ano sa database —
   nananatili pa rin ang lahat ng lumang record doon (makikita pa
   rin sila sa "Grade Evaluation", na siyang tumitingin sa buong
   history ng bawat estudyante); dito lang sa listahan/table
   pinipili lang ang pinakabago dahil pareho na itong ORDER BY
   created_at DESC mula sa API — kaya ang unang row na makikita
   ng bawat key ang siya nang pinakabago. */
function ascbEnrollLatestPerStudent(rows) {
    const seen = new Set();
    const latest = [];
    rows.forEach(row => {
        const key = ascbEnrollStudentKey(row);
        if (!key || seen.has(key)) return;
        seen.add(key);
        latest.push(row);
    });
    return latest;
}

let ascbEnrollPage = 1;

// "View All" toggle — kapag true, ipinapakita LAHAT ng (naka-filter na)
// records sa isang tingin, walang pagination. Naka-store sa
// sessionStorage para hindi mawala ang preference pagpalit ng view.
let ascbEnrollShowAll = sessionStorage.getItem("ascb_enroll_show_all") === "1";

function ascbEnrollToggleViewAll() {
    ascbEnrollShowAll = !ascbEnrollShowAll;
    sessionStorage.setItem("ascb_enroll_show_all", ascbEnrollShowAll ? "1" : "0");
    ascbEnrollPage = 1;
    ascbEnrollRenderTable();
}

function ascbEnrollEl(id) {
    return document.getElementById(id);
}

function ascbEnrollFormatDate(value) {
    if (!value) return "—";
    const d = new Date(String(value).replace(" ", "T"));
    if (Number.isNaN(d.getTime())) return value;
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
}

function ascbEnrollFullName(row) {
    const parts = [row.surname || "", row.first_name || "", row.middle_name || ""].filter(Boolean);
    return parts.length ? `${row.surname || ""}, ${row.first_name || ""} ${row.middle_name || ""}`.trim() : "—";
}

/* ---------------------------------------------------------
   APPROVAL STATUS — kapag ADMIN STAFF ang nag-input (create o
   update) ng enrollee, "pending" muna ito hanggang aprubahan
   ng UNIT HEAD (tingnan ang api/enrollment.php).
   --------------------------------------------------------- */
function ascbEnrollStatusBadge(row) {
    const status = (row.status || "approved").toLowerCase();
    const map = {
        pending:  { label: "Pending",  cls: "status-badge-pending" },
        approved: { label: "Enrolled", cls: "status-badge-approved" },
        rejected: { label: "Rejected", cls: "status-badge-rejected" },
    };
    const info = map[status] || map.approved;

    let title = "";
    if (status === "approved" && row.approved_by_name) {
        title = `Inaprubahan ni ${row.approved_by_name}`;
    } else if (status === "rejected") {
        title = row.approval_remarks ? `Na-reject: ${row.approval_remarks}` : (row.approved_by_name ? `Na-reject ni ${row.approved_by_name}` : "Na-reject");
    } else if (status === "pending") {
        title = "Naghihintay ng approval ng Unit Head";
    }

    return `<span class="status-badge ${info.cls}" title="${escapeHTML(title)}">${info.label}</span>`;
}

async function ascbLoadEnrollment() {
    const status = ascbEnrollEl("enrollStatus");
    const wrapper = ascbEnrollEl("enrollTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    try {
        // scope=active — hindi kasama ang "rejected" (may sariling
        // "Rejected Students" menu na ito) at hindi kasama ang
        // naka-archive na (may sariling "Archive" menu na ito).
        const response = await fetch("api/enrollment.php?scope=active");
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang records. Subukan muli.";
            return;
        }

        // Ang API mismo ay ORDER BY created_at DESC (pinakabago muna),
        // kaya sapat nang kunin ang UNANG makita per estudyante para
        // makuha ang pinakabagong term niya lang — hindi ito
        // nagbubura ng lumang record sa database, dito lang sa
        // pagpapakita sa table ito nangyayari.
        ascbEnrollRows = ascbEnrollLatestPerStudent(Array.isArray(data.rows) ? data.rows : []);
        ascbEnrollPage = 1;
        ascbEnrollRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Enrollment load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

function ascbEnrollFilter() {
    ascbEnrollPage = 1;
    ascbEnrollRenderTable();
}

function ascbEnrollGoToPage(page) {
    ascbEnrollPage = page;
    ascbEnrollRenderTable();
}

function ascbEnrollRenderTable() {
    const body = ascbEnrollEl("enrollTableBody");
    if (!body) return;

    const perms = (typeof ASCB_PERMISSIONS !== "undefined") ? ASCB_PERMISSIONS : {};
    const term = (ascbEnrollEl("enrollSearchInput") ? ascbEnrollEl("enrollSearchInput").value : "").trim().toLowerCase();
    const statusFilter = ascbEnrollEl("enrollStatusFilterInput") ? ascbEnrollEl("enrollStatusFilterInput").value : "";

    const viewAllBtn = ascbEnrollEl("enrollViewAllBtn");
    if (viewAllBtn) {
        viewAllBtn.textContent = ascbEnrollShowAll ? "Paginate" : "View All";
        viewAllBtn.classList.toggle("btn-secondary", !ascbEnrollShowAll);
        viewAllBtn.classList.toggle("btn-outline", ascbEnrollShowAll);
    }

    const filtered = ascbEnrollRows.filter(row => {
        if (statusFilter && (row.status || "approved") !== statusFilter) return false;
        if (!term) return true;
        const haystack = [
            row.student_id, row.surname, row.first_name, row.middle_name,
            row.address, row.mobile_number, row.prev_school_junior_hs, row.prev_school_senior_hs,
            row.course, row.major, row.school_year,
        ].map(v => (v || "").toLowerCase()).join(" ");
        return haystack.includes(term);
    });

    if (!filtered.length) {
        body.innerHTML = `<tr><td colspan="7" class="records-empty">Walang nahanap na record.</td></tr>`;
        const paginationEl = ascbEnrollEl("enrollPagination");
        if (paginationEl) paginationEl.innerHTML = "";
        return;
    }

    const pageSize = ascbEnrollShowAll ? filtered.length : ASCB_PAGE_SIZE;
    const { pageRows, page, totalPages, total } = ascbPaginate(filtered, ascbEnrollPage, pageSize);
    ascbEnrollPage = page;

    body.innerHTML = pageRows.map(row => {
        const deleteBtn = perms.deleteLookups
            ? `<button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbEnrollDelete(${row.id})">${ascbIcon('delete')}</button>`
            : "";

        const isPending = (row.status || "approved") === "pending";
        const approvalBtns = (perms.approveEnrollment && isPending)
            ? `<button type="button" class="btn btn-success-solid approved-so-action-btn action-icon-btn" title="Approve" aria-label="Approve" onclick="ascbEnrollApprove(${row.id})">${ascbIcon('approve')}</button>
               <button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Reject" aria-label="Reject" onclick="ascbEnrollReject(${row.id})">${ascbIcon('reject')}</button>`
            : "";

        const updateBtn = perms.updateEnrollment
            ? `<button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="Update" aria-label="Update" onclick="ascbEnrollOpenEdit(${row.id})">${ascbIcon('edit')}</button>`
            : "";

        const yearTrimester = [row.year_level, row.trimester].filter(Boolean).join(" — ");

        return `
            <tr>
                <td data-label="Student ID">${escapeHTML(row.student_id || "—")}</td>
                <td data-label="Name">${escapeHTML(ascbEnrollFullName(row))}</td>
                <td data-label="Course">${escapeHTML(row.course || "—")}</td>
                <td data-label="Major">${escapeHTML(row.major || "—")}</td>
                <td data-label="Year & Trimester">${escapeHTML(yearTrimester || "—")}</td>
                <td data-label="Approval Status">${ascbEnrollStatusBadge(row)}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View" aria-label="View" onclick="ascbEnrollShowDetail(${row.id})">${ascbIcon('view')}</button>
                    ${updateBtn}
                    <button type="button" class="btn btn-success-solid approved-so-action-btn action-icon-btn" title="New Term" aria-label="New Term" onclick="ascbEnrollOpenNewTerm(${row.id})">${ascbIcon('newTerm')}</button>
                    ${approvalBtns}
                    ${deleteBtn}
                </td>
            </tr>`;
    }).join("");

    if (ascbEnrollShowAll) {
        const paginationEl = ascbEnrollEl("enrollPagination");
        if (paginationEl) paginationEl.innerHTML = `<div class="pagination-info">Showing lahat — ${total} record${total === 1 ? "" : "s"}</div>`;
    } else {
        ascbRenderPagination("enrollPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbEnrollGoToPage");
    }
}

/* ---------------------------------------------------------
   VIEW DETAILS — modal na nagpapakita ng buong info ng isang
   enrollee (kasama na ang mga field na tinanggal na sa table
   mismo para gumaan ito: Mobile Number, Birth Date, Address,
   Previous School Junior/Senior HS).
   --------------------------------------------------------- */
function ascbEnrollShowDetail(id) {
    const row = ascbEnrollRows.find(r => r.id === id)
        || (typeof ascbRejectedRows !== "undefined" && ascbRejectedRows.find(r => r.id === id))
        || (typeof ascbArchiveRows !== "undefined" && ascbArchiveRows.find(r => r.id === id));
    if (!row) return;

    const modal = ascbEnrollEl("enrollDetailModal");
    const title = ascbEnrollEl("enrollDetailTitle");
    const body = ascbEnrollEl("enrollDetailBody");
    if (!modal || !title || !body) return;

    const yearTrimester = [row.year_level, row.trimester].filter(Boolean).join(" — ");

    title.textContent = `${ascbEnrollFullName(row)} (${row.student_id || "—"})`;

    body.innerHTML = `
        <p><strong>Date Enrolled:</strong> ${escapeHTML(ascbEnrollFormatDate(row.created_at))}</p>
        <p><strong>Sex:</strong> ${escapeHTML(row.sex || "—")}</p>
        <p><strong>Student Type:</strong> ${escapeHTML(row.student_type || "—")}</p>
        <p><strong>Course / Major:</strong> ${escapeHTML(row.course || "—")}${row.major ? " — " + escapeHTML(row.major) : ""}</p>
        <p><strong>Year &amp; Trimester:</strong> ${escapeHTML(yearTrimester || "—")}</p>
        <p><strong>School Year:</strong> ${escapeHTML(row.school_year || "—")}</p>
        <p><strong>Mobile Number:</strong> ${escapeHTML(row.mobile_number || "—")}</p>
        <p><strong>Birth Date:</strong> ${escapeHTML(ascbEnrollFormatDate(row.birth_date))}</p>
        <p><strong>Address:</strong> ${escapeHTML(row.address || "—")}</p>
        <p><strong>Previous School (Junior HS):</strong> ${escapeHTML(row.prev_school_junior_hs || "—")}</p>
        <p><strong>Previous School (Senior HS):</strong> ${escapeHTML(row.prev_school_senior_hs || "—")}</p>
        <p><strong>Approval Status:</strong> ${ascbEnrollStatusBadge(row)}</p>`;

    modal.classList.add("active");
}

function ascbEnrollCloseDetail() {
    const modal = ascbEnrollEl("enrollDetailModal");
    if (modal) modal.classList.remove("active");
}

/* ---------------------------------------------------------
   APPROVE / REJECT — Unit Head lang (ASCB_PERMISSIONS.approveEnrollment).
   Ang backend din ang tunay na nagpapatupad ng check na ito.
   --------------------------------------------------------- */
async function ascbEnrollApprove(id) {
    if (!confirm("Aprubahan ang enrollment record na ito?")) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "approve", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi na-approve. Subukan muli.");
            return;
        }

        ascbLoadEnrollment();

    } catch (error) {
        console.error("Enrollment approve failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}

async function ascbEnrollReject(id) {
    const remarks = prompt("Opsyonal: dahilan ng pag-reject (pwedeng iwanang blangko)", "");
    if (remarks === null) return; // cancelled

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "reject", id, remarks: remarks.trim() }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi na-reject. Subukan muli.");
            return;
        }

        ascbLoadEnrollment();

    } catch (error) {
        console.error("Enrollment reject failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}

async function ascbEnrollSubmit() {
    const surname = ascbEnrollEl("enroll_surname") ? ascbEnrollEl("enroll_surname").value.trim() : "";
    const firstName = ascbEnrollEl("enroll_firstName") ? ascbEnrollEl("enroll_firstName").value.trim() : "";
    const middleName = ascbEnrollEl("enroll_middleName") ? ascbEnrollEl("enroll_middleName").value.trim() : "";
    const sex = ascbEnrollEl("enroll_sex") ? ascbEnrollEl("enroll_sex").value : "";
    const studentType = ascbEnrollEl("enroll_studentType") ? ascbEnrollEl("enroll_studentType").value : "";
    const birthDate = ascbEnrollEl("enroll_birthDate") ? ascbEnrollEl("enroll_birthDate").value : "";
    const address = ascbEnrollEl("enroll_address") ? ascbEnrollEl("enroll_address").value.trim() : "";
    const mobileNumber = ascbEnrollEl("enroll_mobileNumber") ? ascbEnrollEl("enroll_mobileNumber").value.trim() : "";
    const prevSchoolJuniorHs = ascbEnrollEl("enroll_prevSchoolJuniorHs") ? ascbEnrollEl("enroll_prevSchoolJuniorHs").value.trim() : "";
    const prevSchoolSeniorHs = ascbEnrollEl("enroll_prevSchoolSeniorHs") ? ascbEnrollEl("enroll_prevSchoolSeniorHs").value.trim() : "";
    const programCode = ascbEnrollEl("enroll_program") ? ascbEnrollEl("enroll_program").value : "";
    const courseMajor = ascbGetCourseMajor(programCode);
    const yearLevel = ascbEnrollEl("enroll_yearLevel") ? ascbEnrollEl("enroll_yearLevel").value : "";
    const trimester = ascbEnrollEl("enroll_trimester") ? ascbEnrollEl("enroll_trimester").value : "";
    const schoolYear = ascbEnrollEl("enroll_schoolYear") ? ascbEnrollEl("enroll_schoolYear").value.trim() : "";
    const subjects = ascbEnrollCollectSubjects("enroll_subjectRows");

    if (!surname || !firstName) {
        alert("Kailangan ng Surname at Given Name.");
        return;
    }

    const status = ascbEnrollEl("enrollFormStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Sino-save…";
    }

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "create",
                surname, firstName, middleName, sex, studentType, birthDate, address, mobileNumber,
                prevSchoolJuniorHs, prevSchoolSeniorHs,
                programCode, course: courseMajor.course, major: courseMajor.major,
                yearLevel, trimester, schoolYear, subjects,
            }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        if (status) {
            const statusNote = data.status === "pending" ? " (Pending — naghihintay ng approval ng Unit Head)" : "";
            status.textContent = (data.studentId ? `Na-save! Student ID: ${data.studentId}` : "Na-save!") + statusNote;
            setTimeout(() => { status.style.display = "none"; }, 4000);
        }

        ["enroll_surname", "enroll_firstName", "enroll_middleName", "enroll_birthDate",
         "enroll_address", "enroll_mobileNumber", "enroll_prevSchoolJuniorHs", "enroll_prevSchoolSeniorHs", "enroll_major",
         "enroll_schoolYear"].forEach(id => {
            if (ascbEnrollEl(id)) ascbEnrollEl(id).value = "";
        });
        if (ascbEnrollEl("enroll_program")) ascbEnrollEl("enroll_program").value = "";
        if (ascbEnrollEl("enroll_sex")) ascbEnrollEl("enroll_sex").value = "";
        if (ascbEnrollEl("enroll_studentType")) ascbEnrollEl("enroll_studentType").value = "";
        if (ascbEnrollEl("enroll_yearLevel")) ascbEnrollEl("enroll_yearLevel").value = "";
        if (ascbEnrollEl("enroll_trimester")) ascbEnrollEl("enroll_trimester").value = "";
        if (ascbEnrollEl("enroll_subjectRows")) ascbEnrollEl("enroll_subjectRows").innerHTML = "";
        ascbEnrollCalculateTotalUnits("enroll_subjectRows");

        ascbLoadEnrollment();

    } catch (error) {
        console.error("Enrollment save failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon.";
    }
}

function ascbEnrollOpenEdit(id) {
    const row = ascbEnrollRows.find(r => Number(r.id) === Number(id));
    if (!row) return;

    ascbEnrollEl("enroll_edit_id").value = row.id;
    if (ascbEnrollEl("enroll_edit_studentIdDisplay")) ascbEnrollEl("enroll_edit_studentIdDisplay").textContent = row.student_id || "—";
    ascbEnrollEl("enroll_edit_surname").value = row.surname || "";
    ascbEnrollEl("enroll_edit_firstName").value = row.first_name || "";
    ascbEnrollEl("enroll_edit_middleName").value = row.middle_name || "";
    if (ascbEnrollEl("enroll_edit_sex")) ascbEnrollEl("enroll_edit_sex").value = row.sex || "";
    if (ascbEnrollEl("enroll_edit_studentType")) ascbEnrollEl("enroll_edit_studentType").value = row.student_type || "";
    ascbEnrollEl("enroll_edit_birthDate").value = row.birth_date ? String(row.birth_date).slice(0, 10) : "";
    ascbEnrollEl("enroll_edit_address").value = row.address || "";
    if (ascbEnrollEl("enroll_edit_mobileNumber")) ascbEnrollEl("enroll_edit_mobileNumber").value = row.mobile_number || "";
    ascbEnrollEl("enroll_edit_prevSchoolJuniorHs").value = row.prev_school_junior_hs || "";
    ascbEnrollEl("enroll_edit_prevSchoolSeniorHs").value = row.prev_school_senior_hs || "";

    if (ascbEnrollEl("enroll_edit_program")) ascbEnrollEl("enroll_edit_program").value = row.program_code || "";
    if (ascbEnrollEl("enroll_edit_major")) ascbEnrollEl("enroll_edit_major").value = row.major || "";
    if (ascbEnrollEl("enroll_edit_yearLevel")) ascbEnrollEl("enroll_edit_yearLevel").value = row.year_level || "";
    // I-refresh muna ang Trimester/Semester <select> (label + options)
    // base sa term_type ng napiling program bago i-set ang value —
    // kung hindi, mananatiling "Trimester" ang label kahit Semester
    // na ang course, dahil hindi na-trigger ang onchange ng dropdown
    // (programmatic set lang ito, hindi user click).
    ascbEnrollUpdateTermSelect("enroll_edit_trimester", row.program_code || "");
    if (ascbEnrollEl("enroll_edit_trimester")) ascbEnrollEl("enroll_edit_trimester").value = row.trimester || "";
    if (ascbEnrollEl("enroll_edit_schoolYear")) ascbEnrollEl("enroll_edit_schoolYear").value = row.school_year || "";

    ascbEnrollPopulateSubjects("enroll_edit_subjectRows", row.subjects || []);

    const status = ascbEnrollEl("enrollEditStatus");
    if (status) status.style.display = "none";

    ascbEnrollEl("enrollEditModal").classList.add("active");
}

function ascbEnrollCloseEdit() {
    ascbEnrollEl("enrollEditModal").classList.remove("active");
}

async function ascbEnrollSubmitEdit() {
    const id = ascbEnrollEl("enroll_edit_id") ? ascbEnrollEl("enroll_edit_id").value : "";
    const surname = ascbEnrollEl("enroll_edit_surname") ? ascbEnrollEl("enroll_edit_surname").value.trim() : "";
    const firstName = ascbEnrollEl("enroll_edit_firstName") ? ascbEnrollEl("enroll_edit_firstName").value.trim() : "";
    const middleName = ascbEnrollEl("enroll_edit_middleName") ? ascbEnrollEl("enroll_edit_middleName").value.trim() : "";
    const sex = ascbEnrollEl("enroll_edit_sex") ? ascbEnrollEl("enroll_edit_sex").value : "";
    const studentType = ascbEnrollEl("enroll_edit_studentType") ? ascbEnrollEl("enroll_edit_studentType").value : "";
    const birthDate = ascbEnrollEl("enroll_edit_birthDate") ? ascbEnrollEl("enroll_edit_birthDate").value : "";
    const address = ascbEnrollEl("enroll_edit_address") ? ascbEnrollEl("enroll_edit_address").value.trim() : "";
    const mobileNumber = ascbEnrollEl("enroll_edit_mobileNumber") ? ascbEnrollEl("enroll_edit_mobileNumber").value.trim() : "";
    const prevSchoolJuniorHs = ascbEnrollEl("enroll_edit_prevSchoolJuniorHs") ? ascbEnrollEl("enroll_edit_prevSchoolJuniorHs").value.trim() : "";
    const prevSchoolSeniorHs = ascbEnrollEl("enroll_edit_prevSchoolSeniorHs") ? ascbEnrollEl("enroll_edit_prevSchoolSeniorHs").value.trim() : "";
    const programCode = ascbEnrollEl("enroll_edit_program") ? ascbEnrollEl("enroll_edit_program").value : "";
    const courseMajor = ascbGetCourseMajor(programCode);
    const yearLevel = ascbEnrollEl("enroll_edit_yearLevel") ? ascbEnrollEl("enroll_edit_yearLevel").value : "";
    const trimester = ascbEnrollEl("enroll_edit_trimester") ? ascbEnrollEl("enroll_edit_trimester").value : "";
    const schoolYear = ascbEnrollEl("enroll_edit_schoolYear") ? ascbEnrollEl("enroll_edit_schoolYear").value.trim() : "";
    const subjects = ascbEnrollCollectSubjects("enroll_edit_subjectRows");

    if (!surname || !firstName) {
        alert("Kailangan ng Surname at Given Name.");
        return;
    }

    const status = ascbEnrollEl("enrollEditStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Sino-save…";
    }

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "update", id, surname, firstName, middleName, sex, studentType, birthDate, address, mobileNumber,
                prevSchoolJuniorHs, prevSchoolSeniorHs,
                programCode, course: courseMajor.course, major: courseMajor.major,
                yearLevel, trimester, schoolYear, subjects,
            }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        ascbEnrollCloseEdit();
        ascbLoadEnrollment();

        if (data.status === "pending") {
            alert("Na-save ang update, pero babalik itong \"Pending\" — kailangan pang aprubahan ng Unit Head.");
        }

    } catch (error) {
        console.error("Enrollment update failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon.";
    }
}

/* ---------------------------------------------------------
   NEW TERM
   ---------------------------------------------------------
   Ginagamit kapag ie-enroll ulit ang isang estudyante para sa
   susunod na term (hal. 2nd Trimester). Kinokopya ang personal
   info AT ang Course/Major/Year Level/Trimester/School Year
   mula sa lumang record papunta sa BAGONG record (action=create,
   may sariling bagong id) — para hindi mas malito mag-encode;
   nananatili pa ring pwedeng i-edit/palitan ng user ang mga ito
   (hal. lipat ng trimester o school year) bago i-save. Blangko
   pa rin ang Subjects — kailangan pa ring piliin ng user para sa
   bagong term. Hindi ito humihipo sa lumang record, kaya buo pa
   rin ang history nito sa Grade Evaluation.
   --------------------------------------------------------- */

function ascbEnrollOpenNewTerm(id) {
    const row = ascbEnrollRows.find(r => Number(r.id) === Number(id));
    if (!row) return;

    ascbEnrollEl("enroll_newterm_sourceId").value = row.id;
    ascbEnrollEl("enroll_newterm_studentId").value = row.student_id || "";
    if (ascbEnrollEl("enroll_newterm_studentIdDisplay")) ascbEnrollEl("enroll_newterm_studentIdDisplay").textContent = row.student_id || "—";
    if (ascbEnrollEl("enroll_newterm_nameDisplay")) ascbEnrollEl("enroll_newterm_nameDisplay").textContent = ascbEnrollFullName(row);
    ascbEnrollEl("enroll_newterm_surname").value = row.surname || "";
    ascbEnrollEl("enroll_newterm_firstName").value = row.first_name || "";
    ascbEnrollEl("enroll_newterm_middleName").value = row.middle_name || "";
    ascbEnrollEl("enroll_newterm_birthDate").value = row.birth_date ? String(row.birth_date).slice(0, 10) : "";
    ascbEnrollEl("enroll_newterm_address").value = row.address || "";
    if (ascbEnrollEl("enroll_newterm_mobileNumber")) ascbEnrollEl("enroll_newterm_mobileNumber").value = row.mobile_number || "";
    ascbEnrollEl("enroll_newterm_prevSchoolJuniorHs").value = row.prev_school_junior_hs || "";
    ascbEnrollEl("enroll_newterm_prevSchoolSeniorHs").value = row.prev_school_senior_hs || "";

    // I-carry over ang Course/Major/Year Level/Trimester/School Year
    // ng dati niyang term — pwede pa ring baguhin ng user (hal.
    // lumipat ng trimester o bagong school year) bago i-save.
    if (ascbEnrollEl("enroll_newterm_sex")) ascbEnrollEl("enroll_newterm_sex").value = row.sex || "";
    if (ascbEnrollEl("enroll_newterm_studentType")) ascbEnrollEl("enroll_newterm_studentType").value = row.student_type || "";
    if (ascbEnrollEl("enroll_newterm_program")) ascbEnrollEl("enroll_newterm_program").value = row.program_code || "";
    if (ascbEnrollEl("enroll_newterm_major")) ascbEnrollEl("enroll_newterm_major").value = row.major || "";
    if (ascbEnrollEl("enroll_newterm_yearLevel")) ascbEnrollEl("enroll_newterm_yearLevel").value = row.year_level || "";
    // I-refresh muna ang Trimester/Semester <select> (label + options)
    // base sa term_type ng napiling program bago i-set ang value —
    // kung hindi, mananatiling "Trimester" ang label kahit Semester
    // na ang course, dahil hindi na-trigger ang onchange ng dropdown
    // (programmatic set lang ito, hindi user click).
    ascbEnrollUpdateTermSelect("enroll_newterm_trimester", row.program_code || "");
    if (ascbEnrollEl("enroll_newterm_trimester")) ascbEnrollEl("enroll_newterm_trimester").value = row.trimester || "";
    if (ascbEnrollEl("enroll_newterm_schoolYear")) ascbEnrollEl("enroll_newterm_schoolYear").value = row.school_year || "";
    // Sadyang blangko pa rin ang Subjects — bagong term, bagong
    // listahan ng subjects ang piplan ng user.
    if (ascbEnrollEl("enroll_newterm_subjectRows")) ascbEnrollEl("enroll_newterm_subjectRows").innerHTML = "";
    ascbEnrollLoadSubjectSelects("enroll_newterm_subjectRows", "enroll_newterm_program");

    const note = ascbEnrollEl("enrollNewTermNote");
    if (note) {
        note.innerHTML = `Gagawa ito ng <strong>bagong record</strong> para sa susunod na term ni <strong>${escapeHTML(ascbEnrollFullName(row))}</strong>. Mananatiling buo at hindi mababago ang record ng dati niyang term — makikita pa rin ito sa Grade Evaluation.`;
    }

    const status = ascbEnrollEl("enrollNewTermStatus");
    if (status) status.style.display = "none";

    ascbEnrollEl("enrollNewTermModal").classList.add("active");
}

function ascbEnrollCloseNewTerm() {
    ascbEnrollEl("enrollNewTermModal").classList.remove("active");
}

async function ascbEnrollSubmitNewTerm() {
    const studentId = ascbEnrollEl("enroll_newterm_studentId") ? ascbEnrollEl("enroll_newterm_studentId").value.trim() : "";
    const surname = ascbEnrollEl("enroll_newterm_surname") ? ascbEnrollEl("enroll_newterm_surname").value.trim() : "";
    const firstName = ascbEnrollEl("enroll_newterm_firstName") ? ascbEnrollEl("enroll_newterm_firstName").value.trim() : "";
    const middleName = ascbEnrollEl("enroll_newterm_middleName") ? ascbEnrollEl("enroll_newterm_middleName").value.trim() : "";
    const sex = ascbEnrollEl("enroll_newterm_sex") ? ascbEnrollEl("enroll_newterm_sex").value : "";
    const studentType = ascbEnrollEl("enroll_newterm_studentType") ? ascbEnrollEl("enroll_newterm_studentType").value : "";
    const birthDate = ascbEnrollEl("enroll_newterm_birthDate") ? ascbEnrollEl("enroll_newterm_birthDate").value : "";
    const address = ascbEnrollEl("enroll_newterm_address") ? ascbEnrollEl("enroll_newterm_address").value.trim() : "";
    const mobileNumber = ascbEnrollEl("enroll_newterm_mobileNumber") ? ascbEnrollEl("enroll_newterm_mobileNumber").value.trim() : "";
    const prevSchoolJuniorHs = ascbEnrollEl("enroll_newterm_prevSchoolJuniorHs") ? ascbEnrollEl("enroll_newterm_prevSchoolJuniorHs").value.trim() : "";
    const prevSchoolSeniorHs = ascbEnrollEl("enroll_newterm_prevSchoolSeniorHs") ? ascbEnrollEl("enroll_newterm_prevSchoolSeniorHs").value.trim() : "";
    const programCode = ascbEnrollEl("enroll_newterm_program") ? ascbEnrollEl("enroll_newterm_program").value : "";
    const courseMajor = ascbGetCourseMajor(programCode);
    const yearLevel = ascbEnrollEl("enroll_newterm_yearLevel") ? ascbEnrollEl("enroll_newterm_yearLevel").value : "";
    const trimester = ascbEnrollEl("enroll_newterm_trimester") ? ascbEnrollEl("enroll_newterm_trimester").value : "";
    const schoolYear = ascbEnrollEl("enroll_newterm_schoolYear") ? ascbEnrollEl("enroll_newterm_schoolYear").value.trim() : "";
    const subjects = ascbEnrollCollectSubjects("enroll_newterm_subjectRows");

    if (!surname || !firstName) {
        alert("Kailangan ng Surname at Given Name.");
        return;
    }

    const status = ascbEnrollEl("enrollNewTermStatus");
    if (status) {
        status.style.display = "block";
        status.textContent = "Sino-save…";
    }

    try {
        // action=create palagi — kahit galing sa dati nang estudyante,
        // BAGONG row ito sa `enrollees` (hindi kailanman action=update),
        // kaya hindi kailanman mao-overwrite ang lumang term.
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                action: "create",
                studentId,
                surname, firstName, middleName, sex, studentType, birthDate, address, mobileNumber,
                prevSchoolJuniorHs, prevSchoolSeniorHs,
                programCode, course: courseMajor.course, major: courseMajor.major,
                yearLevel, trimester, schoolYear, subjects,
            }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = (data && data.error) ? data.error : "Hindi na-save. Subukan muli.";
            return;
        }

        ascbEnrollCloseNewTerm();
        ascbLoadEnrollment();

        if (data.status === "pending") {
            alert("Na-save ang bagong term, pero \"Pending\" muna ito — kailangan pang aprubahan ng Unit Head.");
        }

    } catch (error) {
        console.error("New term enrollment save failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon.";
    }
}

async function ascbEnrollDelete(id) {
    // "Delete" dito ay nag-a-ARCHIVE lang ng record (hindi tuluyang
    // binubura sa database) — makikita pa rin ito sa "Archive" menu,
    // "Restore" na lang ang gagamitin para ibalik.
    if (!confirm("Ililipat ang enrollee na ito sa Archive (hindi ito tuluyang mabubura sa database). Magpatuloy?")) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "delete", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi na-archive. Subukan muli.");
            return;
        }

        // Alinman sa Enrollment/New Term list o sa Rejected Students
        // list ang pinanggalingan nito, i-refresh ang parehong listahan
        // na kasalukuyang nakabukas (ligtas tawagin ang dalawa — ang
        // hindi kasalukuyang view lang ang tahimik na mag-uupdate).
        ascbLoadEnrollment();
        if (typeof ascbLoadRejectedStudents === "function") ascbLoadRejectedStudents();

    } catch (error) {
        console.error("Enrollment delete/archive failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}


/* =========================================================
   REJECTED STUDENTS
   ---------------------------------------------------------
   Hiwalay na listahan para sa mga enrollee na "rejected" ang
   status (hindi pa naka-archive) — scope=rejected sa
   api/enrollment.php. Habang nandito ang isang estudyante,
   HINDI siya lumalabas sa Enrollment / New Term list o sa
   Grade Evaluation. "Delete" dito ay gumagamit pa rin ng
   ascbEnrollDelete() sa itaas — nag-a-archive lang, hindi
   tuluyang binubura sa database.
   ========================================================= */

let ascbRejectedRows = [];
let ascbRejectedPage = 1;

async function ascbLoadRejectedStudents() {
    const status = ascbEnrollEl("rejectedStatus");
    const wrapper = ascbEnrollEl("rejectedTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    try {
        const response = await fetch("api/enrollment.php?scope=rejected");
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang records. Subukan muli.";
            return;
        }

        ascbRejectedRows = Array.isArray(data.rows) ? data.rows : [];
        ascbRejectedPage = 1;
        ascbRejectedRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Rejected students load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

function ascbRejectedFilter() {
    ascbRejectedPage = 1;
    ascbRejectedRenderTable();
}

function ascbRejectedGoToPage(page) {
    ascbRejectedPage = page;
    ascbRejectedRenderTable();
}

function ascbRejectedRenderTable() {
    const body = ascbEnrollEl("rejectedTableBody");
    if (!body) return;

    const perms = (typeof ASCB_PERMISSIONS !== "undefined") ? ASCB_PERMISSIONS : {};
    const term = (ascbEnrollEl("rejectedSearchInput") ? ascbEnrollEl("rejectedSearchInput").value : "").trim().toLowerCase();

    const filtered = ascbRejectedRows.filter(row => {
        if (!term) return true;
        const haystack = [
            row.student_id, row.surname, row.first_name, row.middle_name,
            row.course, row.major, row.school_year,
        ].map(v => (v || "").toLowerCase()).join(" ");
        return haystack.includes(term);
    });

    if (!filtered.length) {
        body.innerHTML = `<tr><td colspan="7" class="records-empty">Walang rejected na estudyante.</td></tr>`;
        const paginationEl = ascbEnrollEl("rejectedPagination");
        if (paginationEl) paginationEl.innerHTML = "";
        return;
    }

    const { pageRows, page, totalPages, total } = ascbPaginate(filtered, ascbRejectedPage, ASCB_PAGE_SIZE);
    ascbRejectedPage = page;

    body.innerHTML = pageRows.map(row => {
        const deleteBtn = perms.deleteLookups
            ? `<button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbEnrollDelete(${row.id})">${ascbIcon('delete')}</button>`
            : "";

        const reasonLabel = row.approval_remarks
            ? escapeHTML(row.approval_remarks)
            : (row.approved_by_name ? `Na-reject ni ${escapeHTML(row.approved_by_name)}` : "—");

        return `
            <tr>
                <td data-label="Student ID">${escapeHTML(row.student_id || "—")}</td>
                <td data-label="Name">${escapeHTML(ascbEnrollFullName(row))}</td>
                <td data-label="Course">${escapeHTML(row.course || "—")}</td>
                <td data-label="Major">${escapeHTML(row.major || "—")}</td>
                <td data-label="School Year">${escapeHTML(row.school_year || "—")}</td>
                <td data-label="Reason / Rejected By">${reasonLabel}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View" aria-label="View" onclick="ascbEnrollShowDetail(${row.id})">${ascbIcon('view')}</button>
                    ${deleteBtn}
                </td>
            </tr>`;
    }).join("");

    ascbRenderPagination("rejectedPagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbRejectedGoToPage");
}


/* =========================================================
   ARCHIVE
   ---------------------------------------------------------
   Mga enrollee na na-archive na (dating "Delete" mula sa
   Enrollment, New Term, o Rejected Students) — scope=archived
   sa api/enrollment.php. Hindi sila tuluyang nabubura sa
   database dito — "Restore" ang ibinabalik sa normal na
   listahan, at "Delete Permanently" na lang ang tunay na
   tumatanggal sa database (kailangan munang naka-archive).
   ========================================================= */

let ascbArchiveRows = [];
let ascbArchivePage = 1;

async function ascbLoadArchive() {
    const status = ascbEnrollEl("archiveStatus");
    const wrapper = ascbEnrollEl("archiveTableWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading records…";
    }
    if (wrapper) wrapper.style.display = "none";

    try {
        const response = await fetch("api/enrollment.php?scope=archived");
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang records. Subukan muli.";
            return;
        }

        ascbArchiveRows = Array.isArray(data.rows) ? data.rows : [];
        ascbArchivePage = 1;
        ascbArchiveRenderTable();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Archive load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

function ascbArchiveFilter() {
    ascbArchivePage = 1;
    ascbArchiveRenderTable();
}

function ascbArchiveGoToPage(page) {
    ascbArchivePage = page;
    ascbArchiveRenderTable();
}

function ascbArchiveRenderTable() {
    const body = ascbEnrollEl("archiveTableBody");
    if (!body) return;

    const perms = (typeof ASCB_PERMISSIONS !== "undefined") ? ASCB_PERMISSIONS : {};
    const term = (ascbEnrollEl("archiveSearchInput") ? ascbEnrollEl("archiveSearchInput").value : "").trim().toLowerCase();

    const filtered = ascbArchiveRows.filter(row => {
        if (!term) return true;
        const haystack = [
            row.student_id, row.surname, row.first_name, row.middle_name,
            row.course, row.major, row.school_year,
        ].map(v => (v || "").toLowerCase()).join(" ");
        return haystack.includes(term);
    });

    if (!filtered.length) {
        body.innerHTML = `<tr><td colspan="7" class="records-empty">Walang naka-archive na record.</td></tr>`;
        const paginationEl = ascbEnrollEl("archivePagination");
        if (paginationEl) paginationEl.innerHTML = "";
        return;
    }

    const { pageRows, page, totalPages, total } = ascbPaginate(filtered, ascbArchivePage, ASCB_PAGE_SIZE);
    ascbArchivePage = page;

    body.innerHTML = pageRows.map(row => {
        const restoreBtn = perms.deleteLookups
            ? `<button type="button" class="btn btn-success-solid approved-so-action-btn action-icon-btn" title="Restore" aria-label="Restore" onclick="ascbEnrollRestore(${row.id})">${ascbIcon('restore')}</button>`
            : "";
        const permDeleteBtn = perms.deleteLookups
            ? `<button type="button" class="btn btn-danger-solid approved-so-action-btn action-icon-btn" title="Delete Permanently" aria-label="Delete Permanently" onclick="ascbEnrollPermanentDelete(${row.id})">${ascbIcon('deleteForever')}</button>`
            : "";

        const archivedByLabel = [
            row.archived_by_name ? `Ni ${escapeHTML(row.archived_by_name)}` : "",
            row.archive_reason ? escapeHTML(row.archive_reason) : "",
        ].filter(Boolean).join(" — ") || "—";

        return `
            <tr>
                <td data-label="Student ID">${escapeHTML(row.student_id || "—")}</td>
                <td data-label="Name">${escapeHTML(ascbEnrollFullName(row))}</td>
                <td data-label="Course">${escapeHTML(row.course || "—")}</td>
                <td data-label="Major">${escapeHTML(row.major || "—")}</td>
                <td data-label="Archived On">${escapeHTML(ascbEnrollFormatDate(row.archived_at))}</td>
                <td data-label="Archived By / Reason">${archivedByLabel}</td>
                <td data-label="Actions">
                    <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View" aria-label="View" onclick="ascbEnrollShowDetail(${row.id})">${ascbIcon('view')}</button>
                    ${restoreBtn}
                    ${permDeleteBtn}
                </td>
            </tr>`;
    }).join("");

    ascbRenderPagination("archivePagination", page, totalPages, total, ASCB_PAGE_SIZE, "ascbArchiveGoToPage");
}

async function ascbEnrollRestore(id) {
    if (!confirm("Ibalik ang enrollee na ito sa normal na listahan?")) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "restore", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi na-restore. Subukan muli.");
            return;
        }

        ascbLoadArchive();
        ascbLoadEnrollment();
        if (typeof ascbLoadRejectedStudents === "function") ascbLoadRejectedStudents();

    } catch (error) {
        console.error("Enrollment restore failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}

async function ascbEnrollPermanentDelete(id) {
    if (!confirm("PERMANENTE itong tatanggalin sa database at HINDI na maibabalik pa. Sigurado ka ba?")) return;

    try {
        const response = await fetch("api/enrollment.php", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ action: "delete", id }),
        });
        const data = await response.json();

        if (!data || !data.ok) {
            alert((data && data.error) ? data.error : "Hindi na-delete. Subukan muli.");
            return;
        }

        ascbLoadArchive();

    } catch (error) {
        console.error("Enrollment permanent delete failed:", error);
        alert("Hindi ma-reach ang server. Suriin ang koneksyon.");
    }
}


/* =========================================================
   ENROLLMENT — COURSE / MAJOR / SUBJECTS (mula sa prospectus)
   ---------------------------------------------------------
   Generic helpers na ginagamit ng parehong "Enroll a Student"
   form (enroll_subjectRows) at ng Edit Enrollee modal
   (enroll_edit_subjectRows). Gumagamit ng `structuredPrograms`
   at `programNames` na naka-define na sa script.js
   (prospectus data) — parehong pinagmumulan ng Certificate /
   Grade Evaluation module, kaya laging magkatugma ang subjects.
   ========================================================= */

/* Hinahati ang programNames[code] sa { course, major } — kung
   walang "Major in" sa label, blangko ang major. */
function ascbGetCourseMajor(programCode) {

    const label = (typeof programNames !== "undefined" && programNames[programCode]) || "";

    const marker = " Major in ";
    const idx = label.indexOf(marker);

    if (idx === -1) {
        return { course: label, major: "" };
    }

    return {
        course: label.substring(0, idx).trim(),
        major: label.substring(idx + marker.length).trim(),
    };
}

/* Tinatawag kapag pinalitan ang Course/Program select — nire-refresh
   ang major field at ang mga subject dropdown sa loob ng
   kaukulang container. */
function ascbEnrollProgramChanged(programSelectId, majorInputId, rowsContainerId, trimesterSelectId) {

    programSelectId = programSelectId || "enroll_program";
    majorInputId = majorInputId || "enroll_major";
    rowsContainerId = rowsContainerId || "enroll_subjectRows";
    trimesterSelectId = trimesterSelectId || "enroll_trimester";

    const programSelect = document.getElementById(programSelectId);
    const majorInput = document.getElementById(majorInputId);

    const programCode = programSelect ? programSelect.value : "";
    const parts = ascbGetCourseMajor(programCode);

    if (majorInput) {
        majorInput.value = parts.major || "";
    }

    ascbEnrollUpdateTermSelect(trimesterSelectId, programCode);
    ascbEnrollLoadSubjectSelects(rowsContainerId, programSelectId);
}

/* Ire-refresh lang ang <option> ng mga .enroll-subject-select sa
   loob ng isang container, base sa currently selected program. */
function ascbEnrollLoadSubjectSelects(rowsContainerId, programSelectId) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    const programSelect = document.getElementById(programSelectId);
    const program = programSelect ? programSelect.value : "";

    const isStructured = program && typeof structuredPrograms !== "undefined" && structuredPrograms[program];

    container.querySelectorAll(".enroll-subject-select").forEach(select => {

        const oldValue = select.value;

        select.innerHTML = `
            <option value="">Select Subject</option>
            <option value="__CUSTOM__">+ Add Custom Subject</option>
        `;

        if (isStructured) {
            structuredPrograms[program].forEach(group => {

                const optgroup = document.createElement("optgroup");
                optgroup.label = `${group.year} — ${group.trimester}`;

                group.subjects.forEach(subject => {
                    const option = document.createElement("option");
                    option.value = JSON.stringify(subject);
                    option.textContent = `${subject.code} — ${subject.description} (${subject.units} units)`;
                    optgroup.appendChild(option);
                });

                select.appendChild(optgroup);
            });
        }

        if (oldValue && [...select.options].some(o => o.value === oldValue)) {
            select.value = oldValue;
        }
    });
}

/* Load-Subjects-for-Term — kagaya ng addSubjectsForTerm() ng
   Certificate module, pero naka-scope sa isang container at
   generic ang element ids (para magamit ulit sa Edit modal). */
function ascbEnrollAddSubjectsForTerm(rowsContainerId, programSelectId, yearSelectId, trimesterSelectId) {

    const programSelect = document.getElementById(programSelectId);
    const yearSelect = document.getElementById(yearSelectId);
    const trimesterSelect = document.getElementById(trimesterSelectId);

    const program = programSelect ? programSelect.value : "";
    const year = yearSelect ? yearSelect.value : "";
    const trimester = trimesterSelect ? trimesterSelect.value : "";

    if (!program) {
        alert("Pumili muna ng Course / Program.");
        return;
    }

    if (!year || !trimester) {
        alert("Pumili muna ng Year Level at Trimester bago mag-load ng subjects.");
        return;
    }

    if (typeof structuredPrograms === "undefined" || !structuredPrograms[program]) {
        alert("Walang structured prospectus ang program na ito. Gamitin na lang ang \"Add Subject\".");
        return;
    }

    const group = structuredPrograms[program].find(g => g.year === year && g.trimester === trimester);

    if (!group) {
        alert("Walang nakatalang subjects para sa Year Level at Trimester na ito.");
        return;
    }

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    const existingCodes = new Set();
    container.querySelectorAll(".enroll-subject-row").forEach(row => {
        const code = row.dataset.customCode || ascbEnrollGetRowSubjectCode(row);
        if (code) existingCodes.add(code);
    });

    let addedCount = 0;

    group.subjects.forEach(subject => {
        if (existingCodes.has(subject.code)) return;
        ascbEnrollAddSubjectRow(rowsContainerId, subject);
        addedCount++;
    });

    ascbEnrollCalculateTotalUnits(rowsContainerId);

    if (addedCount === 0) {
        alert("Naidagdag na lahat ng subjects para sa term na ito.");
    }
}

function ascbEnrollGetRowSubjectCode(row) {
    const select = row.querySelector(".enroll-subject-select");
    if (!select || !select.value || select.value === "__CUSTOM__") return null;
    try {
        return JSON.parse(select.value).code;
    } catch (error) {
        return null;
    }
}

/* Nalalaman ng function kung saang program-select/total-units-cell
   siya dapat sumangguni base sa containerId. BUG FIX: dati,
   kahit anong container id ang hindi "enroll_edit_subjectRows"
   ay bumabalik sa Total Units / GWA cells ng MAIN Enroll form —
   kaya kapag nagdagdag ng bagong container (hal. New Term),
   sisirain nito ang display ng ibang form. Ngayon, whitelist na
   ang bawat kilalang container, at ligtas (null/null) ang
   default kung hindi kilala. */
function ascbEnrollContainerConfig(rowsContainerId) {
    if (rowsContainerId === "enroll_subjectRows") {
        return { programSelectId: "enroll_program", totalUnitsId: "enroll_totalUnitsInput", gwaId: "enroll_gwaValueInput" };
    }
    if (rowsContainerId === "enroll_edit_subjectRows") {
        return { programSelectId: "enroll_edit_program", totalUnitsId: null, gwaId: null };
    }
    if (rowsContainerId === "enroll_newterm_subjectRows") {
        return { programSelectId: "enroll_newterm_program", totalUnitsId: null, gwaId: null };
    }
    return { programSelectId: "enroll_program", totalUnitsId: null, gwaId: null };
}

function ascbEnrollAddSubjectRow(rowsContainerId, subjectData) {

    const tbody = document.getElementById(rowsContainerId);
    if (!tbody) return;

    const row = document.createElement("tr");
    row.className = "enroll-subject-row";

    row.innerHTML = `
        <td>
            <select class="enroll-subject-select" onchange="ascbEnrollSelectSubject(this, '${rowsContainerId}')">
                <option value="">Select Subject</option>
            </select>
        </td>
        <td>
            <input type="text" class="enroll-subject-description" placeholder="Course Description">
        </td>
        <td>
            <input type="number" class="enroll-subject-units" min="0" step="1" value="0" oninput="ascbEnrollCalculateTotalUnits('${rowsContainerId}')">
        </td>
        <td style="text-align:center">
            <button type="button" class="btn btn-danger action-icon-btn" title="Remove" aria-label="Remove" onclick="ascbEnrollRemoveSubjectRow(this, '${rowsContainerId}')">${ascbIcon('reject')}</button>
        </td>
    `;

    tbody.appendChild(row);

    const config = ascbEnrollContainerConfig(rowsContainerId);
    ascbEnrollLoadSubjectSelects(rowsContainerId, config.programSelectId);

    if (subjectData) {
        const select = row.querySelector(".enroll-subject-select");
        const description = row.querySelector(".enroll-subject-description");
        const units = row.querySelector(".enroll-subject-units");
        if (subjectData.code) {
            select.value = JSON.stringify({ code: subjectData.code, description: subjectData.description, units: subjectData.units });
            if (select.value === "" || ![...select.options].some(o => o.value === select.value)) {
                row.dataset.customCode = subjectData.code;
            }
        }

        description.value = subjectData.description || "";
        units.value = subjectData.units || 0;
    }

    ascbEnrollCalculateTotalUnits(rowsContainerId);
}

function ascbEnrollSelectSubject(select, rowsContainerId) {

    const row = select.closest(".enroll-subject-row");

    if (select.value === "__CUSTOM__") {

        const code = prompt("Enter Course Code:");
        if (!code) { select.value = ""; return; }

        const description = prompt("Enter Course Description:");
        if (!description) { select.value = ""; return; }

        const units = prompt("Enter Units:", "3");

        row.querySelector(".enroll-subject-description").value = description;
        row.querySelector(".enroll-subject-units").value = units || 0;
        row.dataset.customCode = code;

        ascbEnrollCalculateTotalUnits(rowsContainerId);
        return;
    }

    if (!select.value) {
        row.querySelector(".enroll-subject-description").value = "";
        row.querySelector(".enroll-subject-units").value = 0;
        delete row.dataset.customCode;
        ascbEnrollCalculateTotalUnits(rowsContainerId);
        return;
    }

    try {
        const subject = JSON.parse(select.value);
        row.querySelector(".enroll-subject-description").value = subject.description;
        row.querySelector(".enroll-subject-units").value = subject.units;
        delete row.dataset.customCode;
        ascbEnrollCalculateTotalUnits(rowsContainerId);
    } catch (error) {
        console.error(error);
    }
}

function ascbEnrollRemoveSubjectRow(button, rowsContainerId) {
    button.closest(".enroll-subject-row").remove();
    ascbEnrollCalculateTotalUnits(rowsContainerId);
}

function ascbEnrollCalculateTotalUnits(rowsContainerId) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    let total = 0;
    container.querySelectorAll(".enroll-subject-units").forEach(input => {
        total += parseFloat(input.value) || 0;
    });

    const config = ascbEnrollContainerConfig(rowsContainerId);
    if (config.totalUnitsId && document.getElementById(config.totalUnitsId)) {
        document.getElementById(config.totalUnitsId).textContent = total;
    }

    ascbEnrollCalculateGWA(rowsContainerId);
}

/* Grades are intentionally not calculated in Enrollment.
   Enrollment records subjects and units only; Grade Management
   owns grade entry and GWA is calculated from the grade records. */
function ascbEnrollCalculateGWA(rowsContainerId) {
    // Grades are maintained separately in Grade Management.
    return 0;
}

/* Kinokolekta ang mga subject row (code/description/units) para
   isama sa POST body papunta sa api/enrollment.php. */
function ascbEnrollCollectSubjects(rowsContainerId) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return [];

    const subjects = [];

    container.querySelectorAll(".enroll-subject-row").forEach(row => {

        const select = row.querySelector(".enroll-subject-select");
        const description = row.querySelector(".enroll-subject-description");
        const units = row.querySelector(".enroll-subject-units");
        let code = row.dataset.customCode || "";

        if (!code && select && select.value && select.value !== "__CUSTOM__") {
            try {
                code = JSON.parse(select.value).code || "";
            } catch (error) {
                code = "";
            }
        }

        const descriptionValue = description ? description.value.trim() : "";

        if (!code && !descriptionValue) return;

        subjects.push({
            code,
            description: descriptionValue,
            units: units ? (parseFloat(units.value) || 0) : 0,
        });
    });

    return subjects;
}

/* Pinupuno ang isang subject table (Edit modal) base sa
   `subjects` array na galing sa row.subjects (api response). */
function ascbEnrollPopulateSubjects(rowsContainerId, subjects) {

    const container = document.getElementById(rowsContainerId);
    if (!container) return;

    container.innerHTML = "";

    (Array.isArray(subjects) ? subjects : []).forEach(subject => {
        ascbEnrollAddSubjectRow(rowsContainerId, subject);
    });

    ascbEnrollCalculateTotalUnits(rowsContainerId);
}



/* =========================================================
   GRADE MANAGEMENT
   ---------------------------------------------------------
   Separate from Enrollment. Enrollment stores the term + subject
   assignment. This module stores/updates the actual grades.
   ========================================================= */
let ascbGradeMgmtRows = [];
let ascbGradeMgmtStudents = [];
let ascbGradeMgmtPage = 1;
let ascbGradeMgmtCurrent = null;

function ascbGradeMgmtEl(id) { return document.getElementById(id); }

async function ascbLoadGradeManagement() {
    const status = ascbGradeMgmtEl('gradeMgmtStatus');
    const wrapper = ascbGradeMgmtEl('gradeMgmtWrapper');
    if (status) { status.style.display = 'block'; status.textContent = 'Loading students…'; }
    if (wrapper) wrapper.style.display = 'none';
    try {
        const response = await fetch('api/grades.php');
        const data = await response.json();
        if (!data || !data.ok) throw new Error(data && data.error ? data.error : 'Load failed');
        ascbGradeMgmtRows = Array.isArray(data.rows) ? data.rows : [];
        const groups = new Map();
        ascbGradeMgmtRows.forEach(row => {
            const key = row.student_id || [row.surname,row.first_name,row.middle_name].map(v => (v||'').trim().toLowerCase()).join('|');
            if (!key) return;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(row);
        });
        ascbGradeMgmtStudents = [...groups.entries()].map(([key, rows]) => {
            rows.sort((a,b) => new Date(b.created_at||0)-new Date(a.created_at||0));
            const latest = rows[0];
            const terms = [];
            const termMap = new Map();
            rows.forEach(r => {
                const tk = String(r.enrollment_id);
                if (!termMap.has(tk)) { termMap.set(tk, { enrollmentId:r.enrollment_id, trimester:r.trimester||'', schoolYear:r.school_year||'', yearLevel:r.year_level||'', course:r.course||'', major:r.major||'', rows:[] }); }
                if (r.enrollment_subject_id) termMap.get(tk).rows.push(r);
            });
            termMap.forEach(t => terms.push(t));
            terms.sort((a,b) => new Date((rows.find(r=>Number(r.enrollment_id)===Number(b.enrollmentId))||{}).created_at||0)-new Date((rows.find(r=>Number(r.enrollment_id)===Number(a.enrollmentId))||{}).created_at||0));
            return { key, fullName: [latest.surname, latest.first_name, latest.middle_name].filter(Boolean).join(', '), studentId:latest.student_id||'', course:latest.course||'', major:latest.major||'', terms };
        }).sort((a,b)=>a.fullName.localeCompare(b.fullName));
        ascbGradeMgmtPage = 1;
        ascbGradeManagementRender();
        if (status) status.style.display='none';
        if (wrapper) wrapper.style.display='block';
    } catch (e) {
        console.error('Grade Management load failed:', e);
        if (status) status.textContent='Hindi ma-load ang Grade Management. Subukan muli.';
    }
}

function ascbGradeManagementFilter() { ascbGradeMgmtPage=1; ascbGradeManagementRender(); }
function ascbGradeManagementGoToPage(page) { ascbGradeMgmtPage=page; ascbGradeManagementRender(); }
function ascbGradeManagementRender() {
    const body=ascbGradeMgmtEl('gradeMgmtBody'); if(!body) return;
    const q=(ascbGradeMgmtEl('gradeMgmtSearchInput')?.value||'').trim().toLowerCase();
    const filtered=ascbGradeMgmtStudents.filter(s => !q || s.fullName.toLowerCase().includes(q) || s.studentId.toLowerCase().includes(q) || s.course.toLowerCase().includes(q));
    if(!filtered.length){ body.innerHTML='<tr><td colspan="7" class="records-empty">Walang nahanap na estudyante.</td></tr>'; return; }
    const per=typeof ASCB_PAGE_SIZE==='number'?ASCB_PAGE_SIZE:10;
    const totalPages=Math.max(1,Math.ceil(filtered.length/per)); ascbGradeMgmtPage=Math.min(ascbGradeMgmtPage,totalPages);
    const rows=filtered.slice((ascbGradeMgmtPage-1)*per,ascbGradeMgmtPage*per);
    body.innerHTML=rows.map(s=>{ const t=s.terms[0]; return `<tr><td data-label="Student ID">${escapeHTML(s.studentId||'—')}</td><td data-label="Name">${escapeHTML(s.fullName)}</td><td data-label="Course">${escapeHTML(s.course||'—')}</td><td data-label="Latest Term">${escapeHTML([t?.trimester,t?.schoolYear].filter(Boolean).join(' / ')||'—')}</td><td data-label="Terms">${s.terms.length}</td><td data-label="Actions"><button type="button" class="btn btn-primary" onclick="ascbGradeManagementOpenByIndex(${ascbGradeMgmtStudents.indexOf(s)})">Enter / Update Grades</button></td></tr>`; }).join('');
    if(typeof ascbRenderPagination==='function') ascbRenderPagination('gradeMgmtPagination',ascbGradeMgmtPage,totalPages,filtered.length,per,'ascbGradeManagementGoToPage');
}

function ascbGradeManagementOpenByIndex(index) { const student=ascbGradeMgmtStudents[Number(index)]; if(student) ascbGradeManagementOpen(student.key); }

function ascbGradeManagementOpen(key) {
    const student=ascbGradeMgmtStudents.find(s=>s.key===key); if(!student) return;
    ascbGradeMgmtCurrent=student;
    ascbGradeMgmtEl('gradeMgmtModalName').textContent=student.fullName;
    ascbGradeMgmtEl('gradeMgmtModalSub').textContent=[student.studentId?'Student ID: '+student.studentId:'',[student.course,student.major].filter(Boolean).join(' — ')].filter(Boolean).join(' | ')||'—';
    const tabs=ascbGradeMgmtEl('gradeMgmtTermTabs');
    tabs.innerHTML=student.terms.map((t,i)=>`<button type="button" class="btn ${i===0?'btn-primary':'btn-outline'} grade-mgmt-term-btn" onclick="ascbGradeManagementShowTerm(${i})">${escapeHTML(t.trimester||'Term')} ${escapeHTML(t.schoolYear||'')}</button>`).join('');
    ascbGradeManagementShowTerm(0);
    ascbGradeMgmtEl('gradeManagementModal').classList.add('active');
}
function ascbGradeManagementShowTerm(index) {
    const s=ascbGradeMgmtCurrent; if(!s||!s.terms[index]) return;
    s.activeTermIndex=index;
    document.querySelectorAll('#gradeMgmtTermTabs .grade-mgmt-term-btn').forEach((b,i)=>b.classList.toggle('btn-primary',i===index));
    document.querySelectorAll('#gradeMgmtTermTabs .grade-mgmt-term-btn').forEach((b,i)=>b.classList.toggle('btn-outline',i!==index));
    const t=s.terms[index];
    const body=ascbGradeMgmtEl('gradeMgmtEditorBody');
    const total=t.rows.reduce((sum,r)=>sum+(parseFloat(r.units)||0),0);
    body.innerHTML=`<div class="grade-mgmt-term-heading"><strong>${escapeHTML(t.trimester||'')}</strong> &nbsp; <strong>AY:</strong> ${escapeHTML(t.schoolYear||'')} &nbsp; <strong>Year:</strong> ${escapeHTML(t.yearLevel||'')}</div><div class="table-wrapper"><table class="subject-input-table grade-management-table"><thead><tr><th>Course Code</th><th>Description</th><th>Units</th><th>Grade</th></tr></thead><tbody>${t.rows.length?t.rows.map(r=>`<tr><td>${escapeHTML(r.course_code||'—')}</td><td>${escapeHTML(r.description||'—')}</td><td>${escapeHTML(String(r.units??0))}</td><td><input class="grade-management-input" data-subject-id="${Number(r.enrollment_subject_id)}" value="${escapeHTML(r.grade||'')}" placeholder="1.75 / INC / DRP" inputmode="decimal"></td></tr>`).join(''):'<tr><td colspan="4" class="records-empty">Walang subjects sa term na ito.</td></tr>'}</tbody><tfoot><tr><td colspan="2" class="total-label">Total Units</td><td>${total}</td><td></td></tr></tfoot></table></div><div style="display:flex;justify-content:flex-end;margin-top:12px;"><button type="button" class="btn btn-primary" onclick="ascbGradeManagementSave()">Save Grades</button></div>`;
}
async function ascbGradeManagementSave() {
    const s=ascbGradeMgmtCurrent; if(!s) return; const t=s.terms[s.activeTermIndex||0]; if(!t) return;
    const status=ascbGradeMgmtEl('gradeMgmtSaveStatus');
    const grades=[...document.querySelectorAll('#gradeMgmtEditorBody .grade-management-input')].map(i=>({subjectId:Number(i.dataset.subjectId),grade:i.value.trim()}));
    if(status){status.style.display='block';status.textContent='Saving grades…';}
    try{
        const response=await fetch('api/grades.php',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action:'save',enrollmentId:Number(t.enrollmentId),grades})});
        const data=await response.json(); if(!data||!data.ok) throw new Error(data?.error||'Hindi na-save.');
        if(status){status.textContent=`Saved. ${data.changed||0} grade(s) updated.`;setTimeout(()=>status.style.display='none',2500);}
        await ascbLoadGradeManagement();
        // Reload the modal's latest student data.
        const refreshed=ascbGradeMgmtStudents.find(x=>x.key===s.key); if(refreshed){ascbGradeMgmtCurrent=refreshed;ascbGradeManagementShowTerm(Math.min(s.activeTermIndex||0,refreshed.terms.length-1));}
    }catch(e){console.error(e);if(status){status.textContent=e.message||'Hindi na-save ang grades.';}}
}
function ascbGradeManagementClose(){ const m=ascbGradeMgmtEl('gradeManagementModal'); if(m)m.classList.remove('active'); ascbGradeMgmtCurrent=null; }

/* =========================================================
   GRADE EVALUATION
   ---------------------------------------------------------
   Read-only report — WALANG sariling database table ito.
   Binabasa lang nito ang existing na `enrollees` records
   (parehong data source ng Enrollment module) at pinagsasama
   ang lahat ng subjects/grades ng isang estudyante mula sa
   bawat naka-log na enrollment (bawat School Year / Year
   Level / Trimester) sa iisang report.

   Ang mga estudyante ay pinagsasama-sama (grouped) base sa
   Surname + Given Name + Middle Name (case-insensitive,
   trimmed) dahil walang hiwalay na "students" table ang
   system na ito — bawat row sa `enrollees` ay isang
   enrollment *event* (isang term), hindi isang permanenteng
   student ID.
   ========================================================= */

let ascbGradeEvalRows = [];
let ascbGradeEvalStudents = [];
let ascbGradeEvalCurrentKey = "";
let ascbGradeEvalCurrentTerms = [];
let ascbGradeEvalPage = 1;

function ascbGradeEvalEl(id) {
    return document.getElementById(id);
}

/* Normalized grouping key para sa isang estudyante. */
function ascbGradeEvalStudentKey(row) {
    return (row.student_id || "").trim() || [row.surname, row.first_name, row.middle_name]
        .map(v => (v || "").trim().toLowerCase())
        .join("|");
}

async function ascbLoadGradeEvaluation() {
    const status = ascbGradeEvalEl("gradeEvalListStatus");
    const wrapper = ascbGradeEvalEl("gradeEvalListWrapper");

    if (status) {
        status.style.display = "block";
        status.textContent = "Loading students…";
    }
    if (wrapper) wrapper.style.display = "none";

    ascbGradeEvalCloseReport();
    ascbGradeEvalCurrentKey = "";
    ascbGradeEvalPage = 1;

    try {
        // scope=active — hindi kasama ang "rejected" na estudyante
        // (dapat mapunta muna sila sa "Rejected Students" bago sila
        // makapasok dito) at hindi rin kasama ang naka-archive na.
        const response = await fetch("api/grades.php");
        const data = await response.json();

        if (!data || !data.ok) {
            if (status) status.textContent = "Hindi ma-load ang mga estudyante. Subukan muli.";
            return;
        }

        const rawGradeRows = Array.isArray(data.rows) ? data.rows : [];
        const termMap = new Map();
        rawGradeRows.forEach(r => {
            const key = String(r.enrollment_id);
            if (!termMap.has(key)) termMap.set(key, { ...r, subjects: [] });
            if (r.enrollment_subject_id) termMap.get(key).subjects.push({ code:r.course_code, description:r.description, units:r.units, grade:r.grade || "" });
        });
        ascbGradeEvalRows = [...termMap.values()];

        // I-group ang mga enrollment rows base sa estudyante, pagkatapos
        // pagbukud-bukurin ang mga term ng bawat estudyante base sa
        // created_at (pagkakasunod-sunod ng pagka-enroll).
        const groups = new Map();
        ascbGradeEvalRows.forEach(row => {
            const key = ascbGradeEvalStudentKey(row);
            if (!key) return;
            if (!groups.has(key)) groups.set(key, []);
            groups.get(key).push(row);
        });

        ascbGradeEvalStudents = [...groups.entries()].map(([key, terms]) => {
            terms.sort((a, b) => new Date(a.created_at || 0) - new Date(b.created_at || 0));
            const latest = terms[terms.length - 1];
            return {
                key,
                fullName: ascbEnrollFullName(latest),
                studentId: latest.student_id || (terms.find(t => t.student_id) || {}).student_id || "",
                course: latest.course || "",
                major: latest.major || "",
                terms,
            };
        }).sort((a, b) => a.fullName.localeCompare(b.fullName));

        ascbGradeEvalRenderStudentList();

        if (status) status.style.display = "none";
        if (wrapper) wrapper.style.display = "block";

    } catch (error) {
        console.error("Grade Evaluation load failed:", error);
        if (status) status.textContent = "Hindi ma-reach ang server. Suriin ang koneksyon o i-refresh ang page.";
    }
}

function ascbGradeEvalFilterStudents() {
    ascbGradeEvalPage = 1;
    ascbGradeEvalRenderStudentList();
}

function ascbGradeEvalGoToPage(page) {
    ascbGradeEvalPage = page;
    ascbGradeEvalRenderStudentList();
}

function ascbGradeEvalRenderStudentList() {
    const body = ascbGradeEvalEl("gradeEvalStudentTableBody");
    if (!body) return;

    const term = (ascbGradeEvalEl("gradeEvalSearchInput") ? ascbGradeEvalEl("gradeEvalSearchInput").value : "").trim().toLowerCase();

    const filtered = ascbGradeEvalStudents.filter(student => {
        if (!term) return true;
        return student.fullName.toLowerCase().includes(term)
            || (student.studentId || "").toLowerCase().includes(term)
            || (student.course || "").toLowerCase().includes(term)
            || (student.major || "").toLowerCase().includes(term);
    });

    if (!filtered.length) {
        body.innerHTML = `<tr><td colspan="6" class="records-empty">Walang nahanap na estudyante.</td></tr>`;
        ascbRenderPagination("gradeEvalPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbGradeEvalGoToPage");
        return;
    }

    const p = ascbPaginate(filtered, ascbGradeEvalPage, ASCB_PAGE_SIZE);
    ascbGradeEvalPage = p.page;

    body.innerHTML = p.pageRows.map(student => `
        <tr>
            <td data-label="Student ID">${escapeHTML(student.studentId || "—")}</td>
            <td data-label="Name">${escapeHTML(student.fullName)}</td>
            <td data-label="Course">${escapeHTML(student.course || "—")}</td>
            <td data-label="Major">${escapeHTML(student.major || "—")}</td>
            <td data-label="Enrollment Records">${student.terms.length}</td>
            <td data-label="Actions">
                <button type="button" class="btn btn-outline approved-so-action-btn action-icon-btn" title="View Grades" aria-label="View Grades" onclick="ascbGradeEvalOpenByIndex(${ascbGradeEvalStudents.indexOf(student)})">${ascbIcon('viewGrades')}</button>
            </td>
        </tr>
    `).join("");

    ascbRenderPagination("gradeEvalPagination", p.page, p.totalPages, p.total, ASCB_PAGE_SIZE, "ascbGradeEvalGoToPage");
}

/* GWA ng isang term (isang enrollment row) — parehong formula
   gaya ng ibang bahagi ng system: weighted average ng
   grade x units, hindi kasama ang blangko/hindi-numeric na grade. */
function ascbGradeEvalTermGWA(subjects) {
    let gradedUnits = 0;
    let weightedSum = 0;

    (subjects || []).forEach(subject => {
        const grade = parseFloat(subject.grade);
        const units = parseFloat(subject.units) || 0;
        if (isNaN(grade) || units <= 0) return;
        weightedSum += grade * units;
        gradedUnits += units;
    });

    return { gwa: gradedUnits > 0 ? (weightedSum / gradedUnits) : null, gradedUnits };
}

function ascbGradeEvalOpenByIndex(index) {
    const student = ascbGradeEvalStudents[Number(index)];
    if (student) ascbGradeEvalOpen(student.key);
}

/* Iisang function na gumagawa ng HTML block (heading + table) ng
   ISANG term — ginagamit pareho ng on-screen preview (lahat ng term)
   at ng print/PDF ng iisang trimester lang, para magkatugma laging
   ang datos/format ng dalawa. */
function ascbGradeEvalBuildTermBlockHtml(student, termRow) {
    const subjects = Array.isArray(termRow.subjects) ? termRow.subjects : [];
    const { gwa, gradedUnits } = ascbGradeEvalTermGWA(subjects);

    let termTotalUnits = 0;
    subjects.forEach(s => { termTotalUnits += parseFloat(s.units) || 0; });

    const academicYear = termRow.school_year || "—";
    const trimester = termRow.trimester || "—";
    const yearLevel = termRow.year_level || "";

    const rowsHtml = subjects.length
        ? subjects.map(s => `
            <tr>
                <td>${escapeHTML(s.code || "—")}</td>
                <td>${escapeHTML(s.description || "—")}</td>
                <td style="text-align:center;">${escapeHTML(s.grade || "—")}</td>
                <td style="text-align:center;">${escapeHTML(String(s.units ?? 0))}</td>
            </tr>
        `).join("")
        : `<tr><td colspan="4" class="records-empty">Walang subjects na naka-record para sa term na ito.</td></tr>`;

    const html = `
        <div class="grade-eval-term">
            <div class="grade-eval-term-heading">
                <strong>Student ID:</strong> ${escapeHTML(student.studentId || "—")} &nbsp;&nbsp;
                <strong>${escapeHTML(trimester)}</strong> &nbsp;&nbsp;
                <strong>Academic Year:</strong> ${escapeHTML(academicYear)}${yearLevel ? ` &nbsp;&nbsp;<strong>Year Level:</strong> ${escapeHTML(yearLevel)}` : ""}
            </div>
            <table class="grade-eval-print-table">
                <thead>
                    <tr><th>Course Code</th><th>Course Description</th><th>Grade</th><th>Units</th></tr>
                </thead>
                <tbody>${rowsHtml}</tbody>
                <tfoot>
                    <tr><td colspan="2" class="total-label">TOTAL UNITS</td><td></td><td style="text-align:center;">${termTotalUnits}</td></tr>
                    <tr><td colspan="2" class="total-label">GWA</td><td style="text-align:center;">${gwa !== null ? gwa.toFixed(2) : "—"}</td><td></td></tr>
                </tfoot>
            </table>
        </div>
    `;

    return { html, gwa, gradedUnits, termTotalUnits };
}

function ascbGradeEvalOpen(key) {
    const student = ascbGradeEvalStudents.find(s => s.key === key);
    if (!student) return;

    ascbGradeEvalCurrentKey = key;

    const modal = ascbGradeEvalEl("gradeEvalReportModal");
    const nameEl = ascbGradeEvalEl("gradeEvalReportName");
    const subEl = ascbGradeEvalEl("gradeEvalReportSub");
    const bodyEl = ascbGradeEvalEl("gradeEvalReportBody");

    nameEl.textContent = student.fullName;
    subEl.textContent = [student.studentId ? `Student ID: ${student.studentId}` : "", [student.course, student.major].filter(Boolean).join(" — ")].filter(Boolean).join(" | ") || "—";

    let overallGradedUnits = 0;
    let overallWeightedSum = 0;
    let overallTotalUnits = 0;

    const trimesterOrder = {"1st Trimester":1,"2nd Trimester":2,"3rd Trimester":3,"1st":1,"2nd":2,"3rd":3,"3rd | Summer":4};
    const sortedTerms = [...student.terms].sort((a,b) => {
        const ay = String(a.school_year || "").localeCompare(String(b.school_year || ""), undefined, {numeric:true});
        if (ay !== 0) return ay;
        const ta = trimesterOrder[String(a.trimester || "")] || 99;
        const tb = trimesterOrder[String(b.trimester || "")] || 99;
        if (ta !== tb) return ta - tb;
        return new Date(a.created_at || 0) - new Date(b.created_at || 0);
    });

    ascbGradeEvalCurrentTerms = sortedTerms;

    const termsHtml = sortedTerms.map(termRow => {
        const block = ascbGradeEvalBuildTermBlockHtml(student, termRow);
        overallTotalUnits += block.termTotalUnits;
        if (block.gwa !== null) {
            overallWeightedSum += block.gwa * block.gradedUnits;
            overallGradedUnits += block.gradedUnits;
        }
        return block.html;
    }).join("");

    const overallGwa = overallGradedUnits > 0 ? (overallWeightedSum / overallGradedUnits) : null;

    bodyEl.innerHTML = `
        ${termsHtml || '<p>No enrollment/grade records found.</p>'}
        <div class="grade-eval-summary">
            <p><strong>Overall Total Units:</strong> ${overallTotalUnits}</p>
            <p><strong>Overall GWA:</strong> ${overallGwa !== null ? overallGwa.toFixed(2) : "—"}</p>
        </div>
    `;

    const termSelect = ascbGradeEvalEl("gradeEvalTermSelect");
    if (termSelect) {
        termSelect.innerHTML = sortedTerms.map((termRow, idx) => {
            const label = `${termRow.school_year || "—"} — ${termRow.trimester || "—"}${termRow.year_level ? ` — ${termRow.year_level}` : ""}`;
            return `<option value="${idx}">${escapeHTML(label)}</option>`;
        }).join("") || `<option value="">Walang term</option>`;
        termSelect.selectedIndex = termSelect.options.length - 1; // default: pinaka-huling term
    }

    if (modal) {
        modal.classList.add("active");
        const scrollArea = modal.querySelector(".grade-eval-report-card");
        if (scrollArea) scrollArea.scrollTop = 0;
    }
}

function ascbGradeEvalCloseReport() {
    const modal = ascbGradeEvalEl("gradeEvalReportModal");
    if (modal) modal.classList.remove("active");
}

/* ---------------------------------------------------------
   PDF/PRINT — GAYANG-GAYA (exact copy) ng layout/format ng
   Certificates > Grade Evaluation: parehong letterhead,
   watermark, title, student details, certificate-table,
   at signature. Ginagamit dito ang MISMONG CSS classes ng
   certificate print-area (certificate-title, student-details,
   certificate-table, signature-area, atbp.) at ang mismong
   stylesheet ng site (style.css) para 100% magkatugma ang
   dalawa — hindi na hiwalay/bespoke na style.

   Nagbubukas ng PREVIEW muna sa bagong tab (hindi agad
   nagpo-print) — may button na "I-print / I-save bilang PDF"
   sa itaas na pipindutin ng user kapag handa na siya.

   - Per-trimester -> SHORT bond paper (8.5in x 11in / Letter),
     eksaktong kagaya ng isang Certificate (may Year Level at
     Semester/Trimester row, isang certificate-table lang).
   - Lahat ng trimester -> LONG bond paper (8.5in x 13in),
     isang certificate-table kada term + overall summary bago
     ang lagda.
   --------------------------------------------------------- */

/* Certificate-table markup (parehong classes/estructura gaya
   ng nasa Certificates modal) para sa ISANG term. */
function ascbGradeEvalBuildCertTableHtml(termRow) {
    const subjects = Array.isArray(termRow.subjects) ? termRow.subjects : [];
    const { gwa, gradedUnits } = ascbGradeEvalTermGWA(subjects);

    let termTotalUnits = 0;
    subjects.forEach(s => { termTotalUnits += parseFloat(s.units) || 0; });

    const rowsHtml = subjects.length
        ? subjects.map(s => `
            <tr>
                <td>${escapeHTML(s.code || "—")}</td>
                <td>${escapeHTML(s.description || "—")}</td>
                <td>${escapeHTML(s.grade || "—")}</td>
                <td>${escapeHTML(String(s.units ?? 0))}</td>
            </tr>
        `).join("")
        : `<tr><td colspan="4">Walang subjects na naka-record para sa term na ito.</td></tr>`;

    const html = `
        <table class="certificate-table">
            <thead>
                <tr>
                    <th class="code-column">Course Code</th>
                    <th>Course Description</th>
                    <th class="grades-column">Grades</th>
                    <th class="units-column">Units</th>
                </tr>
            </thead>
            <tbody>${rowsHtml}</tbody>
            <tfoot>
                <tr>
                    <td colspan="3" class="cert-total-label">TOTAL UNITS</td>
                    <td>${termTotalUnits}</td>
                </tr>
                <tr>
                    <td colspan="3" class="cert-total-label">GENERAL WEIGHTED AVERAGE (GWA)</td>
                    <td>${gwa !== null ? gwa.toFixed(2) : "—"}</td>
                </tr>
            </tfoot>
        </table>
    `;

    return { html, gwa, gradedUnits, termTotalUnits };
}

function ascbGradeEvalTermLabel(termRow) {
    const parts = [];
    if (termRow.year_level) parts.push(termRow.year_level);
    parts.push(termRow.trimester || "—");
    parts.push(`AY ${termRow.school_year || "—"}`);
    return parts.join(" — ");
}

/* Bumubukas ng preview tab gamit ang MISMONG print-area markup
   at stylesheet ng Certificates, para gayang-gaya ang labas. */
function ascbGradeEvalOpenCertificateStylePreview(opts) {
    const {
        name, studentId, course, major,
        singleTerm, terms,
        showOverallSummary, overallTotalUnits, overallGwa,
        paperHeightIn,
        multiPage,
    } = opts;

    const printWindow = window.open("", "_blank", "width=900,height=1000");
    if (!printWindow) {
        alert("Please allow pop-ups for this website to view the Grade Evaluation.");
        return;
    }

    const basePath = window.location.origin + window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);

    // Kinokopya ang mismong stylesheet ng site (kasama ang lahat
    // ng .certificate-title / .student-details / .certificate-table /
    // .signature-area rules) — ito rin mismo ang ginagamit ng
    // printCertificate() para sa totoong Certificates.
    const styles = [...document.querySelectorAll("link[rel='stylesheet'], style")]
        .map(style => {
            if (style.tagName === "STYLE") {
                return `<style>${style.innerHTML}</style>`;
            }
            return `<link rel="stylesheet" href="${style.href}">`;
        })
        .join("");

    const studentDetailRows = [
        `<div class="detail-row"><span class="detail-label">Student Name</span><span class="colon">:</span><span class="detail-value">${escapeHTML(name)}</span></div>`,
        `<div class="detail-row"><span class="detail-label">Student ID</span><span class="colon">:</span><span class="detail-value">${escapeHTML(studentId || "—")}</span></div>`,
        `<div class="detail-row"><span class="detail-label">Course / Program</span><span class="colon">:</span><span class="detail-value">${escapeHTML(course || "—")}${major ? " — " + escapeHTML(major) : ""}</span></div>`,
    ];

    let bodyBlocks;

    if (singleTerm) {
        const termRow = terms[0];
        studentDetailRows.push(
            `<div class="detail-row"><span class="detail-label">Year Level</span><span class="colon">:</span><span class="detail-value">${escapeHTML(termRow.year_level || "—")}</span></div>`,
            `<div class="detail-row"><span class="detail-label">Semester / Trimester</span><span class="colon">:</span><span class="detail-value">${escapeHTML(termRow.trimester || "—")}, AY ${escapeHTML(termRow.school_year || "—")}</span></div>`
        );
        bodyBlocks = ascbGradeEvalBuildCertTableHtml(termRow).html;
    } else {
        bodyBlocks = terms.map(termRow => {
            const block = ascbGradeEvalBuildCertTableHtml(termRow);
            return `<div class="grade-eval-term-block"><p class="summary-title">${escapeHTML(ascbGradeEvalTermLabel(termRow))}</p>${block.html}</div>`;
        }).join("");
    }

    const overallSummaryHtml = showOverallSummary
        ? `<div class="student-details" style="margin-top:0.12in;">
               <div class="detail-row"><span class="detail-label">Overall Total Units</span><span class="colon">:</span><span class="detail-value">${overallTotalUnits}</span></div>
               <div class="detail-row"><span class="detail-label">Overall GWA</span><span class="colon">:</span><span class="detail-value">${overallGwa !== null && overallGwa !== undefined ? overallGwa.toFixed(2) : "—"}</span></div>
           </div>`
        : "";

    const documentHeaderHtml = `
    <div class="document-header">
        <img src="${basePath}Header_ASCB.png" class="letterhead-banner" alt="Andres Soriano Colleges of Bislig, Inc.">
        <div class="header-subtitle">
            <p class="header-office">Office of the Registrar</p>
            <p class="header-email">collegeregistrar.ascb@gmail.com &nbsp;|&nbsp; (086) 853-2306 (PhilCom)</p>
        </div>
    </div>`;

    const watermarkHtml = `
    <div class="watermark-container" aria-hidden="true">
        <img src="${basePath}ASCB_LOGO.png" class="document-watermark" alt="">
    </div>`;

    const mainContentHtml = `
    <div class="document-content">

        <h1 class="certificate-title">GRADE EVALUATION</h1>

        <p class="summary-title"><span>Below is the Summary of the Student's Grades${!singleTerm ? " (All Trimesters)" : ""}:</span></p>

        <div class="student-details">
            ${studentDetailRows.join("")}
        </div>

        ${bodyBlocks}

        ${overallSummaryHtml}

        <div class="signature-area signature-area--grade-eval">
            <div class="signature-box">
                <div class="signature-space">&nbsp;</div>
                <div class="signature-line">REBECCA P. CAPONONG, MAEd</div>
                <div class="signature-position">School Registrar</div>
            </div>
        </div>

    </div>

    <div class="school-seal-warning">
        <strong>NOT VALID WITHOUT</strong>
        <strong><span>SCHOOL SEAL</span></strong>
    </div>`;

    /* ===================================================================
       ONE-PAGE MODE (Print Term) — eksaktong kagaya ng printCertificate():
       fixed na 8.5 x paperHeightIn na sheet, overflow hidden, absolute
       watermark/footer. Palaging kasya sa isang term sa isang pahina.
       =================================================================== */
    const singlePageMarkup = `
<div class="print-area" id="printArea">
    ${documentHeaderHtml}
    ${watermarkHtml}
    ${mainContentHtml}
</div>`;

    const singlePageStyle = `
    @page { size: 8.5in ${paperHeightIn}in; margin: 0; }

    html, body {
        width: 8.5in;
        height: ${paperHeightIn}in;
        margin: 0;
        padding: 0;
        background: #ffffff;
        overflow: hidden;
    }

    .print-area {
        width: 8.5in !important;
        height: ${paperHeightIn}in !important;
        min-height: ${paperHeightIn}in !important;
        max-height: ${paperHeightIn}in !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: hidden !important;
        box-shadow: none !important;
        background: #ffffff !important;
    }

    .watermark-container {
        position: absolute !important;
        left: 0 !important;
        right: 0 !important;
        top: 2.20in !important;
        bottom: 0 !important;
        overflow: hidden !important;
        z-index: 1 !important;
        pointer-events: none !important;
    }`;

    /* ===================================================================
       MULTI-PAGE MODE (Print All) — long bond paper (8.5 x paperHeightIn),
       PERO kung mas mahaba pa sa isang sheet ang laman (maraming
       trimester), DUMADAGDAG na lang ito ng isa pang sheet (parehong
       laki) sa halip na putulin/i-clip ang laman. Ang letterhead
       (repeating table <thead>) at ang watermark (position: fixed, na
       inuulit sa bawat pahina sa print) ay lumalabas sa BAWAT dagdag na
       sheet, kaya pareho pa rin ang tingin kahit ilang pahina na.
       =================================================================== */
    const multiPageMarkup = `
<div class="print-area" id="printArea">
    <table class="grade-eval-page-table">
        <thead>
            <tr><td>${documentHeaderHtml}</td></tr>
        </thead>
        <tbody>
            <tr><td>
                ${watermarkHtml}
                ${mainContentHtml}
            </td></tr>
        </tbody>
    </table>
</div>`;

    const multiPageStyle = `
    @page { size: 8.5in ${paperHeightIn}in; margin: 0; }

    html, body {
        width: 8.5in;
        margin: 0;
        padding: 0;
        background: #ffffff;
        overflow: visible;
    }

    /* Sa print (Ctrl+P / physical printer), pinipilit ng GLOBAL na
       style.css (mismong Certificates print rule) na i-clip ang
       html/body sa eksaktong 11in kahit "!important" pa yun — kaya
       nawawala ang lagda/seal pag mahaba ang laman (maraming
       trimester). Hindi sapat ang pag-asa sa PAGKASUNOD-SUNOD ng
       stylesheets, kaya dito gumagamit tayo ng MAS SPECIFIC na
       class-based selector (".ascb-grade-eval-multipage") — mas
       mataas ang specificity nito kaysa sa plain na "html, body"
       kaya SIGURADONG mananalo ito sa cascade, kahit anong pagkasunod
       pa ang stylesheets. */
    @media print {
        html body.ascb-grade-eval-multipage,
        html body.ascb-grade-eval-multipage #printArea {
            height: auto !important;
            min-height: 0 !important;
            max-height: none !important;
            overflow: visible !important;
        }
    }

    .print-area {
        width: 8.5in !important;
        height: auto !important;
        min-height: 0 !important;
        max-height: none !important;
        margin: 0 !important;
        padding: 0 !important;
        overflow: visible !important;
        box-shadow: none !important;
        background: #ffffff !important;
    }

    .grade-eval-page-table {
        width: 100%;
        border-collapse: collapse;
    }

    .grade-eval-page-table > thead > tr > td,
    .grade-eval-page-table > tbody > tr > td {
        padding: 0;
    }

    /* Inuulit ng browser ang <thead> sa itaas ng BAWAT pahina —
       kaya lumalabas ang letterhead sa bawat karagdagang sheet. */
    .grade-eval-page-table thead {
        display: table-header-group;
    }

    /* Sa on-screen na preview at sa PDF download (html2canvas),
       "absolute" ito para tama ang pagka-center relative sa
       buong .print-area (na sumusukat ayon sa laman — "height:auto").
       "position:fixed" ay nagiging maling laki/posisyon sa
       html2canvas dahil relative ito sa viewport, hindi sa buong
       dokumento — kaya lumilihis sa gilid ang watermark pag PDF. */
    .watermark-container {
        position: absolute !important;
        left: 0 !important;
        right: 0 !important;
        top: 2.20in !important;
        bottom: 0 !important;
        overflow: hidden !important;
        z-index: 1 !important;
        pointer-events: none !important;
    }

    /* Pag totoong nagpi-print (Ctrl+P / physical printer), "fixed"
       ulit para umulit ang watermark sa BAWAT pahina. Hindi ito
       nakakaapekto sa PDF download dahil html2canvas lang, hindi
       @media print, ang gamit doon. */
    @media print {
        .watermark-container {
            position: fixed !important;
        }
    }

    .school-seal-warning,
    .transaction-notes {
        position: static !important;
        left: auto !important;
        bottom: auto !important;
        width: auto !important;
    }

    .school-seal-warning {
        margin: 0.35in 0 0 0.55in !important;
        text-align: left !important;
    }

    .school-seal-warning span {
        text-align: left !important;
    }

    .transaction-notes {
        margin: 0.12in 0 0.3in 0.55in !important;
    }

    .grade-eval-term-block,
    .certificate-table,
    .signature-area {
        page-break-inside: avoid;
    }

    .summary-title {
        page-break-after: avoid;
    }`;

    const sharedStyle = `

    body {
        font-family: "Poppins", Arial, sans-serif;
    }

    /* Direktang absolute + translate(-50%,-50%) ang paggamit dito
       para sa pag-center — mas reliable ito sa html2canvas (PDF
       download) kaysa sa flexbox na align-items/justify-content,
       na madalas hindi tama ang sukat/posisyon pag na-rasterize. */
    .document-watermark {
        position: absolute !important;
        left: 50% !important;
        top: 50% !important;
        width: 4.35in !important;
        height: 4.35in !important;
        max-width: 4.35in !important;
        max-height: 4.35in !important;
        transform: translate(-50%, -50%) !important;
        display: block !important;
        visibility: visible !important;
        object-fit: contain !important;
        opacity: 0.055 !important;
        z-index: 1 !important;
        pointer-events: none !important;
    }

    .document-content {
        position: relative !important;
        z-index: 3 !important;
    }

    .document-header {
        position: relative !important;
        z-index: 5 !important;
    }

    .student-details,
    .certificate-title,
    .summary-title,
    .certificate-table,
    .signature-area {
        position: relative !important;
        z-index: 3 !important;
    }

    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
    }

    /* ===== toolbar ng preview (nawawala pag naka-print na) ===== */

    .preview-toolbar {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        padding: 12px;
        background: #eef5fa;
        border-bottom: 2px solid #17649a;
    }

    .preview-toolbar button {
        padding: 10px 20px;
        font-size: 13px;
        font-weight: 600;
        border: none;
        border-radius: 8px;
        background: #17649a;
        color: #fff;
        cursor: pointer;
    }

    .preview-toolbar button:hover {
        background: #123e67;
    }

    .preview-note {
        text-align: center;
        font-size: 11px;
        color: #667482;
        margin: 10px 0 0;
    }

    @media print {
        .preview-toolbar,
        .preview-note {
            display: none !important;
        }
    }`;

    printWindow.document.open();
    printWindow.document.write(`
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Grade Evaluation — ${escapeHTML(name)}</title>
${styles}
<style>
    /* ===== eksaktong parehong page setup ng printCertificate() ===== */
    ${multiPage ? multiPageStyle : singlePageStyle}
    ${sharedStyle}
</style>
</head>
<body class="ascb-grade-eval-preview${multiPage ? " ascb-grade-eval-multipage" : ""}">

<div class="preview-toolbar">
    <button type="button" onclick="window.print()">🖶 I-print / I-save bilang PDF</button>
</div>

<div class="preview-note">Preview lang ito, kaparehong-kapareho ng format ng Certificates — pindutin ang buton sa itaas kapag handa ka nang mag-print o mag-save bilang PDF (piliin ang "Save as PDF" bilang printer sa print dialog).</div>

${multiPage ? multiPageMarkup : singlePageMarkup}

<script>
window.onload = function () { window.focus(); };

${multiPage ? `
/* Sigurado talagang hindi na ma-clip ang laman sa print (kahit
   ilang trimester/pages pa) — gumagamit ng INLINE style + "important"
   priority (via setProperty), na palaging mas matimbang kaysa sa
   anumang rule mula sa linked stylesheet (style.css), kasama na
   yung mga naunang "@media print" rule doon na nagpi-force ng
   11in / overflow:hidden sa html at body. */
function ascbForceNoClipForPrint() {
    [document.documentElement, document.body].forEach(function (el) {
        el.style.setProperty("height", "auto", "important");
        el.style.setProperty("min-height", "0", "important");
        el.style.setProperty("max-height", "none", "important");
        el.style.setProperty("overflow", "visible", "important");
    });
    var area = document.getElementById("printArea");
    if (area) {
        area.style.setProperty("height", "auto", "important");
        area.style.setProperty("min-height", "0", "important");
        area.style.setProperty("max-height", "none", "important");
        area.style.setProperty("overflow", "visible", "important");
    }
}
ascbForceNoClipForPrint();
window.addEventListener("beforeprint", ascbForceNoClipForPrint);
` : ""}
<\/script>
</body>
</html>`);
    printWindow.document.close();
}

function ascbGradeEvalPrintTerm() {
    const student = ascbGradeEvalStudents.find(s => s.key === ascbGradeEvalCurrentKey);
    const termSelect = ascbGradeEvalEl("gradeEvalTermSelect");

    if (!student || !ascbGradeEvalCurrentTerms.length) {
        alert("Pumili muna ng estudyante para i-view ang Grade Evaluation PDF.");
        return;
    }

    const idx = termSelect ? Number(termSelect.value) : ascbGradeEvalCurrentTerms.length - 1;
    const termRow = ascbGradeEvalCurrentTerms[idx];
    if (!termRow) {
        alert("Pumili muna ng trimester na i-p-print.");
        return;
    }

    ascbGradeEvalOpenCertificateStylePreview({
        name: student.fullName,
        studentId: student.studentId,
        course: student.course,
        major: student.major,
        singleTerm: true,
        terms: [termRow],
        showOverallSummary: false,
        paperHeightIn: 11, // Short bond paper (Letter) — kagaya ng Certificate
        multiPage: false,
    });
}

function ascbGradeEvalPrintAll() {
    const student = ascbGradeEvalStudents.find(s => s.key === ascbGradeEvalCurrentKey);

    if (!student || !ascbGradeEvalCurrentTerms.length) {
        alert("Pumili muna ng estudyante para i-view ang Grade Evaluation PDF.");
        return;
    }

    let overallGradedUnits = 0;
    let overallWeightedSum = 0;
    let overallTotalUnits = 0;

    ascbGradeEvalCurrentTerms.forEach(termRow => {
        const subjects = Array.isArray(termRow.subjects) ? termRow.subjects : [];
        const { gwa, gradedUnits } = ascbGradeEvalTermGWA(subjects);
        subjects.forEach(s => { overallTotalUnits += parseFloat(s.units) || 0; });
        if (gwa !== null) {
            overallWeightedSum += gwa * gradedUnits;
            overallGradedUnits += gradedUnits;
        }
    });

    const overallGwa = overallGradedUnits > 0 ? (overallWeightedSum / overallGradedUnits) : null;

    ascbGradeEvalOpenCertificateStylePreview({
        name: student.fullName,
        studentId: student.studentId,
        course: student.course,
        major: student.major,
        singleTerm: false,
        terms: ascbGradeEvalCurrentTerms,
        showOverallSummary: true,
        overallTotalUnits,
        overallGwa,
        paperHeightIn: 13, // Long bond paper — dadagdag ng sheet (parehong laki) kung kailangan
        multiPage: true,
    });
}



/* =========================================================
   APPROVED SO MODULE
   (restored: dashboard controls previously referenced missing
   JavaScript functions, causing ReferenceError on client use)
   ========================================================= */
let ascbSoRows = [];
let ascbSoPage = 1;

function ascbSoEl(id) { return document.getElementById(id); }
function ascbUiDateTime(value) {
    if (!value) return "—";
    const raw = String(value).replace(" ", "T");
    const d = new Date(raw);
    return Number.isNaN(d.getTime()) ? escapeHTML(value) : d.toLocaleString("en-PH", { year:"numeric", month:"short", day:"numeric", hour:"numeric", minute:"2-digit" });
}

async function ascbLoadApprovedSO() {
    const status = ascbSoEl("soStatus");
    const wrap = ascbSoEl("soTableWrapper");
    if (status) { status.style.display = "block"; status.textContent = "Loading records…"; }
    if (wrap) wrap.style.display = "none";
    try {
        const response = await fetch("api/approved_so.php");
        const data = await response.json();
        if (!response.ok || !data || !data.ok) throw new Error(data && data.error ? data.error : "Hindi makuha ang records.");
        ascbSoRows = Array.isArray(data.rows) ? data.rows : [];
        ascbSoPage = 1;
        ascbSoRender();
    } catch (e) {
        if (status) status.textContent = e.message || "Hindi ma-reach ang server.";
    }
}

function ascbSoFiltered() {
    const q = (ascbSoEl("soSearchInput")?.value || "").trim().toLowerCase();
    if (!q) return ascbSoRows;
    return ascbSoRows.filter(r => [r.name, r.original_filename, r.uploaded_by_name].some(v => String(v || "").toLowerCase().includes(q)));
}
function ascbSoFilter() { ascbSoPage = 1; ascbSoRender(); }
function ascbSoGoToPage(page) { ascbSoPage = page; ascbSoRender(); }
function ascbSoRender() {
    const body = ascbSoEl("soTableBody"), status = ascbSoEl("soStatus"), wrap = ascbSoEl("soTableWrapper");
    if (!body || !status || !wrap) return;
    const rows = ascbSoFiltered();
    if (!rows.length) {
        body.innerHTML = `<tr><td colspan="5" class="records-empty">Walang nahanap na Approved SO.</td></tr>`;
        status.style.display = "none"; wrap.style.display = "block";
        ascbRenderPagination("soPagination", 1, 1, 0, ASCB_PAGE_SIZE, "ascbSoGoToPage");
        return;
    }
    const p = ascbPaginate(rows, ascbSoPage, ASCB_PAGE_SIZE); ascbSoPage = p.page;
    body.innerHTML = p.pageRows.map(r => `
        <tr>
            <td data-label="Name">${escapeHTML(r.name || "—")}</td>
            <td data-label="File"><a class="docs-file-chip" href="api/approved_so_file.php?id=${encodeURIComponent(r.id)}" target="_blank" rel="noopener">📄 ${escapeHTML(r.original_filename || "View PDF")}</a></td>
            <td data-label="Uploaded By">${escapeHTML(r.uploaded_by_name || "—")}</td>
            <td data-label="Date">${ascbUiDateTime(r.created_at)}</td>
            <td data-label="Actions">
                <button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbSoOpenEdit(${Number(r.id)})">${ascbIcon('edit')}</button>
                <button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbSoDelete(${Number(r.id)})">${ascbIcon('delete')}</button>
            </td>
        </tr>`).join("");
    status.style.display = "none"; wrap.style.display = "block";
    ascbRenderPagination("soPagination", p.page, p.totalPages, p.total, ASCB_PAGE_SIZE, "ascbSoGoToPage");
}

async function ascbSoSubmit() {
    const name = (ascbSoEl("so_name")?.value || "").trim();
    const input = ascbSoEl("so_file");
    const file = input && input.files ? input.files[0] : null;
    const status = ascbSoEl("soFormStatus");
    if (!name || !file) { alert("Kailangan ang Name at PDF file."); return; }
    if (!file.name.toLowerCase().endsWith(".pdf")) { alert("PDF file lang ang tinatanggap."); return; }
    const fd = new FormData(); fd.append("action","create"); fd.append("name",name); fd.append("file",file);
    if (status) { status.style.display="block"; status.textContent="Sino-save…"; }
    try {
        const res = await fetch("api/approved_so.php", {method:"POST", body:fd}); const data = await res.json();
        if (!res.ok || !data.ok) throw new Error(data.error || "Hindi na-save.");
        ascbSoEl("so_name").value=""; input.value=""; if(status) status.textContent="Na-save!";
        await ascbLoadApprovedSO();
    } catch(e) { if(status) status.textContent=e.message || "Hindi ma-reach ang server."; }
}
function ascbSoOpenEdit(id) {
    const r = ascbSoRows.find(x => Number(x.id) === Number(id)); if(!r) return;
    ascbSoEl("so_edit_id").value=r.id; ascbSoEl("so_edit_name").value=r.name||""; ascbSoEl("so_edit_file").value="";
    const st=ascbSoEl("soEditStatus"); if(st) st.style.display="none"; ascbSoEl("soEditModal").classList.add("active");
}
function ascbSoCloseEdit() { const m=ascbSoEl("soEditModal"); if(m) m.classList.remove("active"); }
async function ascbSoSubmitEdit() {
    const id=ascbSoEl("so_edit_id")?.value, name=(ascbSoEl("so_edit_name")?.value||"").trim(), input=ascbSoEl("so_edit_file"), file=input?.files?.[0]||null, st=ascbSoEl("soEditStatus");
    if(!id||!name){alert("Kailangan ang Name.");return;} if(file&&!file.name.toLowerCase().endsWith(".pdf")){alert("PDF file lang ang tinatanggap.");return;}
    const fd=new FormData(); fd.append("action","update");fd.append("id",id);fd.append("name",name);if(file)fd.append("file",file);
    if(st){st.style.display="block";st.textContent="Sino-save…";}
    try{const res=await fetch("api/approved_so.php",{method:"POST",body:fd});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||"Hindi na-save.");ascbSoCloseEdit();await ascbLoadApprovedSO();}catch(e){if(st)st.textContent=e.message||"Hindi ma-reach ang server.";}
}
async function ascbSoDelete(id) {
    if(!confirm("I-delete ang Approved SO entry na ito at ang PDF file nito?"))return;
    const fd=new FormData();fd.append("action","delete");fd.append("id",id);
    try{const res=await fetch("api/approved_so.php",{method:"POST",body:fd});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||"Hindi na-delete.");await ascbLoadApprovedSO();}catch(e){alert(e.message||"Hindi ma-reach ang server.");}
}

/* =========================================================
   FORM 9 / COURSE FILES MODULE
   ========================================================= */
let ascbCfRows=[]; let ascbCfPage=1;
function ascbCfEl(id){return document.getElementById(id);}
function ascbCfPopulateCourses(){
    const sel=ascbCfEl("cf_course"); if(!sel)return; const current=sel.value;
    sel.innerHTML='<option value="">Select Course</option>';
    (Array.isArray(ascbCoursesCache)?ascbCoursesCache:[]).forEach(c=>{const o=document.createElement("option");o.value=c;o.textContent=c;sel.appendChild(o);});
    if(current)sel.value=current;
}
async function ascbLoadCourseFiles(){
    ascbCfPopulateCourses(); const st=ascbCfEl("cfStatus"),wrap=ascbCfEl("cfTableWrapper");if(st){st.style.display="block";st.textContent="Loading records…";}if(wrap)wrap.style.display="none";
    try{const res=await fetch("api/course_files.php");const data=await res.json();if(!res.ok||!data||!data.ok)throw new Error(data&&data.error?data.error:"Hindi makuha ang records.");ascbCfRows=Array.isArray(data.rows)?data.rows:[];ascbCfPage=1;ascbCfRender();}catch(e){if(st)st.textContent=e.message||"Hindi ma-reach ang server.";}
}
function ascbCfFiltered(){const q=(ascbCfEl("cfSearchInput")?.value||"").trim().toLowerCase();if(!q)return ascbCfRows;return ascbCfRows.filter(r=>[r.student_name,r.course,r.original_filename,r.uploaded_by_name].some(v=>String(v||"").toLowerCase().includes(q)));}
function ascbCfFilter(){ascbCfPage=1;ascbCfRender();} function ascbCfGoToPage(p){ascbCfPage=p;ascbCfRender();}
function ascbCfRender(){
    const body=ascbCfEl("cfTableBody"),st=ascbCfEl("cfStatus"),wrap=ascbCfEl("cfTableWrapper");if(!body||!st||!wrap)return;const rows=ascbCfFiltered();
    if(!rows.length){body.innerHTML='<tr><td colspan="7" class="records-empty">Walang nahanap na FORM 9 file.</td></tr>';st.style.display="none";wrap.style.display="block";ascbRenderPagination("cfPagination",1,1,0,ASCB_PAGE_SIZE,"ascbCfGoToPage");return;}
    const p=ascbPaginate(rows,ascbCfPage,ASCB_PAGE_SIZE);ascbCfPage=p.page;
    body.innerHTML=p.pageRows.map(r=>`<tr><td data-label="Name">${escapeHTML(r.student_name||"—")}</td><td data-label="Course">${escapeHTML(r.course||"—")}</td><td data-label="File"><a class="docs-file-chip" href="api/course_files_file.php?id=${encodeURIComponent(r.id)}">⬇ ${escapeHTML(r.original_filename||"Download")}</a></td><td data-label="Uploaded By">${escapeHTML(r.uploaded_by_name||"—")}</td><td data-label="Date">${ascbUiDateTime(r.created_at)}</td><td data-label="Actions"><button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbCfDelete(${Number(r.id)})">${ascbIcon('delete')}</button></td></tr>`).join("");
    st.style.display="none";wrap.style.display="block";ascbRenderPagination("cfPagination",p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,"ascbCfGoToPage");
}
async function ascbCfSubmit(){
    const name=(ascbCfEl("cf_name")?.value||"").trim(),course=ascbCfEl("cf_course")?.value||"",input=ascbCfEl("cf_file"),file=input?.files?.[0]||null,st=ascbCfEl("cfFormStatus");
    if(!name||!course||!file){alert("Kumpletuhin ang Name, Course, at Excel file.");return;} const ext=(file.name.split('.').pop()||'').toLowerCase();if(!['xlsx','xls','csv'].includes(ext)){alert(".xlsx, .xls, o .csv lang ang tinatanggap.");return;}
    const fd=new FormData();fd.append("action","create");fd.append("name",name);fd.append("course",course);fd.append("file",file);if(st){st.style.display="block";st.textContent="Sino-save…";}
    try{const res=await fetch("api/course_files.php",{method:"POST",body:fd});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||"Hindi na-save.");ascbCfEl("cf_name").value="";ascbCfEl("cf_course").value="";input.value="";if(st)st.textContent="Na-save!";await ascbLoadCourseFiles();}catch(e){if(st)st.textContent=e.message||"Hindi ma-reach ang server.";}
}
async function ascbCfDelete(id){if(!confirm("Permanenteng i-delete ang FORM 9 entry at file na ito?"))return;const fd=new FormData();fd.append("action","delete");fd.append("id",id);try{const res=await fetch("api/course_files.php",{method:"POST",body:fd});const data=await res.json();if(!res.ok||!data.ok)throw new Error(data.error||"Hindi na-delete.");await ascbLoadCourseFiles();}catch(e){alert(e.message||"Hindi ma-reach ang server.");}}

/* =========================================================
   ADMIN MODULE
   ========================================================= */
let ascbUsersRows=[],ascbUsersPage=1,ascbAdmSchoolsRows=[],ascbAdmSchoolsPage=1,ascbAdmCoursesRows=[],ascbAdmCoursesPage=1,ascbLogRows=[],ascbLogPage=1;
let ascbAdmProgsRows=[],ascbAdmProgsPage=1,ascbAdmProgSubjRows=[],ascbAdmProgSubjCurrentProgram=null;
let ascbDepartmentsRows=[];
function ascbAdminEl(id){return document.getElementById(id);}
function ascbAdminShowPanels(ids){document.querySelectorAll('.admin-tab-panel').forEach(el=>el.style.display='none');ids.forEach(id=>{const el=ascbAdminEl(id);if(el)el.style.display='block';});}
function ascbAdminOpen(){ascbAdminSwitchTab('account');ascbLoadDepartments(true);
    const usersTab=ascbAdminEl('adminTabUsers'),logTab=ascbAdminEl('adminTabLog');
    if(usersTab) usersTab.style.display=(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageUsers)?'':'none';
    if(logTab) logTab.style.display=(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.viewActivityLog)?'':'none';
}
function ascbAdminSwitchTab(tab){
    ['Account','Appearance','Users','Lookups','Departments','Programs','Log'].forEach(k=>{const b=ascbAdminEl('adminTab'+k);if(b)b.classList.remove('active');});
    if(tab==='appearance'){
        ascbAdminEl('adminTabAppearance')?.classList.add('active');ascbAdminShowPanels(['adminPanelAppearance']);ascbSyncThemeControls(ascbGetTheme()==='dark');return;
    }
    if(tab==='users'){
        if(!(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageUsers)){ascbAdminShowPanels(['adminPanelNoAccess']);return;}
        ascbAdminEl('adminTabUsers')?.classList.add('active');ascbAdminShowPanels(['adminPanelUsers','adminPanelUsersList']);ascbLoadUsers();return;
    }
    if(tab==='lookups'){ascbAdminEl('adminTabLookups')?.classList.add('active');ascbAdminShowPanels(['adminPanelLookups','adminPanelLookupsCourses']);ascbAdminLoadSchools();ascbAdminLoadCourses();return;}
    if(tab==='departments'){ascbAdminEl('adminTabDepartments')?.classList.add('active');ascbAdminShowPanels(['adminPanelDepartments']);ascbLoadDepartments();return;}
    if(tab==='programs'){ascbAdminEl('adminTabPrograms')?.classList.add('active');ascbAdminShowPanels(['adminPanelPrograms']);ascbAdminLoadPrograms();return;}
    if(tab==='log'){
        if(!(ASCB_PERMISSIONS&&ASCB_PERMISSIONS.viewActivityLog)){ascbAdminShowPanels(['adminPanelNoAccess']);return;}
        ascbAdminEl('adminTabLog')?.classList.add('active');ascbAdminShowPanels(['adminPanelLog']);ascbLoadActivityLog();return;
    }
    ascbAdminEl('adminTabAccount')?.classList.add('active');ascbAdminShowPanels(['adminPanelAccount']);
}
async function ascbChangeOwnPassword(){
    const cur=ascbAdminEl('acct_currentPassword')?.value||'',nw=ascbAdminEl('acct_newPassword')?.value||'',cf=ascbAdminEl('acct_confirmPassword')?.value||'',st=ascbAdminEl('acctStatus');
    if(!cur||!nw||!cf){alert('Kumpletuhin ang password fields.');return;}if(nw.length<8){alert('Ang bagong password ay dapat hindi bababa sa 8 karakter.');return;}if(nw!==cf){alert('Hindi magkatugma ang New Password at Confirm Password.');return;}
    if(st){st.style.display='block';st.textContent='Sino-save…';}const data=await ascbApiPost('api/users.php',{action:'change_password',currentPassword:cur,newPassword:nw});if(!data.ok){if(st)st.textContent=data.error||'Hindi napalitan ang password.';return;}['acct_currentPassword','acct_newPassword','acct_confirmPassword'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});if(st)st.textContent='Password successfully changed.';
}
async function ascbLoadUsers(){const st=ascbAdminEl('usersStatus'),wrap=ascbAdminEl('usersTableWrapper');if(st){st.style.display='block';st.textContent='Loading accounts…';}if(wrap)wrap.style.display='none';const data=await ascbApiPost('api/users.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang accounts.';return;}ascbUsersRows=Array.isArray(data.users)?data.users:[];ascbUsersPage=1;ascbUsersRender();}
function ascbUsersFiltered(){const q=(ascbAdminEl('userSearchInput')?.value||'').trim().toLowerCase();if(!q)return ascbUsersRows;return ascbUsersRows.filter(r=>[r.display_name,r.role,r.prepared_by_code,r.username].some(v=>String(v||'').toLowerCase().includes(q)));}
function ascbUsersFilter(){ascbUsersPage=1;ascbUsersRender();}function ascbUsersGoToPage(p){ascbUsersPage=p;ascbUsersRender();}
function ascbUsersRender(){const body=ascbAdminEl('usersTableBody'),st=ascbAdminEl('usersStatus'),wrap=ascbAdminEl('usersTableWrapper');if(!body||!st||!wrap)return;const rows=ascbUsersFiltered();if(!rows.length){body.innerHTML='<tr><td colspan="7" class="records-empty">Walang account.</td></tr>';st.style.display='none';wrap.style.display='block';ascbRenderPagination('usersPagination',1,1,0,ASCB_PAGE_SIZE,'ascbUsersGoToPage');return;}const p=ascbPaginate(rows,ascbUsersPage,ASCB_PAGE_SIZE);ascbUsersPage=p.page;body.innerHTML=p.pageRows.map(r=>{const active=Number(r.is_active);const toggleLabel=active?'Deactivate':'Activate';return `<tr><td>${escapeHTML(r.display_name||'—')}</td><td>${escapeHTML(r.role||'—')}</td><td>${escapeHTML(r.department_name||'—')}</td><td>${escapeHTML(r.prepared_by_code||'—')}</td><td>${active?'Active':'Inactive'}</td><td>${ascbUiDateTime(r.created_at)}</td><td><button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbUserOpenEdit(${Number(r.id)})">${ascbIcon('edit')}</button> <button type="button" class="btn btn-outline btn-sm action-icon-btn" title="${toggleLabel}" aria-label="${toggleLabel}" onclick="ascbUserToggle(${Number(r.id)})">${ascbIcon(active?'deactivate':'activate')}</button> <button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbUserDelete(${Number(r.id)})">${ascbIcon('delete')}</button></td></tr>`;}).join('');st.style.display='none';wrap.style.display='block';ascbRenderPagination('usersPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbUsersGoToPage');}
async function ascbUserAdd(){const displayName=(ascbAdminEl('user_displayName')?.value||'').trim(),role=ascbAdminEl('user_role')?.value||'',departmentId=Number(ascbAdminEl('user_departmentId')?.value||0),preparedByCode=(ascbAdminEl('user_preparedByCode')?.value||'').trim(),username=(ascbAdminEl('user_username')?.value||'').trim(),password=ascbAdminEl('user_password')?.value||'',st=ascbAdminEl('userFormStatus');if(!displayName||!password){alert('Kailangan ang Full Name at Password.');return;}if(password.length<8){alert('Password must be at least 8 characters.');return;}if(st){st.style.display='block';st.textContent='Sino-save…';}const data=await ascbApiPost('api/users.php',{action:'add',displayName,role,departmentId,preparedByCode,username,password});if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}['user_displayName','user_preparedByCode','user_password'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});if(st)st.textContent='Account added.';await ascbLoadUsers();}
function ascbUserOpenEdit(id){const r=ascbUsersRows.find(x=>Number(x.id)===Number(id));if(!r)return;ascbAdminEl('user_edit_id').value=r.id;ascbAdminEl('user_edit_displayName').value=r.display_name||'';ascbAdminEl('user_edit_role').value=r.role||'ADMIN STAFF';ascbAdminEl('user_edit_departmentId').value=r.department_id||'';ascbAdminEl('user_edit_preparedByCode').value=r.prepared_by_code||'';ascbAdminEl('user_edit_username').value=r.username||'admin';ascbAdminEl('user_edit_password').value='';const st=ascbAdminEl('userEditStatus');if(st)st.style.display='none';ascbAdminEl('userEditModal').classList.add('active');}
function ascbUserCloseEdit(){ascbAdminEl('userEditModal')?.classList.remove('active');}
async function ascbUserSubmitEdit(){const id=Number(ascbAdminEl('user_edit_id')?.value||0),displayName=(ascbAdminEl('user_edit_displayName')?.value||'').trim(),role=ascbAdminEl('user_edit_role')?.value||'',departmentId=Number(ascbAdminEl('user_edit_departmentId')?.value||0),preparedByCode=(ascbAdminEl('user_edit_preparedByCode')?.value||'').trim(),username=(ascbAdminEl('user_edit_username')?.value||'').trim(),password=ascbAdminEl('user_edit_password')?.value||'',st=ascbAdminEl('userEditStatus');if(!id||!displayName){alert('Kailangan ang Full Name.');return;}if(password&&password.length<8){alert('New password must be at least 8 characters.');return;}if(st){st.style.display='block';st.textContent='Sino-save…';}const data=await ascbApiPost('api/users.php',{action:'update',id,displayName,role,departmentId,preparedByCode,username,password});if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}ascbUserCloseEdit();await ascbLoadUsers();}
async function ascbUserToggle(id){const r=ascbUsersRows.find(x=>Number(x.id)===Number(id));if(!r)return;if(!confirm(`${Number(r.is_active)?'I-deactivate':'I-activate'} ang account ni ${r.display_name}?`))return;const data=await ascbApiPost('api/users.php',{action:'toggle_active',id});if(!data.ok){alert(data.error||'Hindi nabago ang status.');return;}await ascbLoadUsers();}
async function ascbUserDelete(id){const r=ascbUsersRows.find(x=>Number(x.id)===Number(id));if(!r||!confirm(`Permanenteng i-delete ang account ni ${r.display_name}?`))return;const data=await ascbApiPost('api/users.php',{action:'delete',id});if(!data.ok){alert(data.error||'Hindi na-delete.');return;}await ascbLoadUsers();}

async function ascbAdminLoadSchools(){const st=ascbAdminEl('admSchoolsStatus'),wrap=ascbAdminEl('admSchoolsTableWrapper');if(st){st.style.display='block';st.textContent='Loading…';}const data=await ascbApiPost('api/schools.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang schools.';return;}ascbAdmSchoolsRows=Array.isArray(data.schools)?data.schools:[];ascbAdmSchoolsPage=1;ascbAdminSchoolsRender();}
function ascbAdminSchoolsFiltered(){const q=(ascbAdminEl('admSchoolSearchInput')?.value||'').trim().toLowerCase();return q?ascbAdmSchoolsRows.filter(r=>[r.name,r.address].some(v=>String(v||'').toLowerCase().includes(q))):ascbAdmSchoolsRows;}
function ascbAdminSchoolsFilter(){ascbAdmSchoolsPage=1;ascbAdminSchoolsRender();}function ascbAdminSchoolsGoToPage(p){ascbAdmSchoolsPage=p;ascbAdminSchoolsRender();}
function ascbAdminSchoolsRender(){const b=ascbAdminEl('admSchoolsTableBody'),st=ascbAdminEl('admSchoolsStatus'),w=ascbAdminEl('admSchoolsTableWrapper');if(!b||!st||!w)return;const rows=ascbAdminSchoolsFiltered(),p=ascbPaginate(rows,ascbAdmSchoolsPage,ASCB_PAGE_SIZE);ascbAdmSchoolsPage=p.page;b.innerHTML=rows.length?p.pageRows.map(r=>`<tr><td>${escapeHTML(r.name||'—')}</td><td>${escapeHTML(r.address||'—')}</td><td>${ASCB_PERMISSIONS&&ASCB_PERMISSIONS.deleteLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminDeleteSchoolById(${Number(r.id)})">${ascbIcon('delete')}</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="3" class="records-empty">Walang school.</td></tr>';st.style.display='none';w.style.display='block';ascbRenderPagination('admSchoolsPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbAdminSchoolsGoToPage');}
async function ascbAdminAddSchool(){const name=(ascbAdminEl('admLookup_schoolName')?.value||'').trim(),address=(ascbAdminEl('admLookup_schoolAddress')?.value||'').trim(),st=ascbAdminEl('admSchoolFormStatus');if(!name){alert('Enter the school name.');return;}if(st){st.style.display='block';st.textContent='Sino-save…';}const data=await ascbApiPost('api/schools.php',{action:'add',name,address});if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}ascbAdminEl('admLookup_schoolName').value='';ascbAdminEl('admLookup_schoolAddress').value='';ascbSchoolsCache.push({name,address});f137LoadSchools();if(st)st.textContent='School added.';await ascbAdminLoadSchools();}
function ascbAdminDeleteSchoolById(id){const r=ascbAdmSchoolsRows.find(x=>Number(x.id)===Number(id));if(r)ascbAdminDeleteSchool(r.name);}
async function ascbAdminDeleteSchool(name){if(!confirm(`Delete school: ${name}?`))return;const data=await ascbApiPost('api/schools.php',{action:'delete',name});if(!data.ok){alert(data.error||'Hindi na-delete.');return;}ascbSchoolsCache=ascbSchoolsCache.filter(s=>s.name!==name);f137LoadSchools();await ascbAdminLoadSchools();}

async function ascbAdminLoadCourses(){const st=ascbAdminEl('admCoursesStatus');const data=await ascbApiPost('api/courses.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang courses.';return;}ascbAdmCoursesRows=Array.isArray(data.courses)?data.courses:[];ascbAdmCoursesPage=1;ascbAdminCoursesRender();}
function ascbAdminCoursesFiltered(){const q=(ascbAdminEl('admCourseSearchInput')?.value||'').trim().toLowerCase();return q?ascbAdmCoursesRows.filter(r=>String(r.name||'').toLowerCase().includes(q)):ascbAdmCoursesRows;}
function ascbAdminCoursesFilter(){ascbAdmCoursesPage=1;ascbAdminCoursesRender();}function ascbAdminCoursesGoToPage(p){ascbAdmCoursesPage=p;ascbAdminCoursesRender();}
function ascbAdminCoursesRender(){const b=ascbAdminEl('admCoursesTableBody'),st=ascbAdminEl('admCoursesStatus'),w=ascbAdminEl('admCoursesTableWrapper');if(!b||!st||!w)return;const rows=ascbAdminCoursesFiltered(),p=ascbPaginate(rows,ascbAdmCoursesPage,ASCB_PAGE_SIZE);ascbAdmCoursesPage=p.page;b.innerHTML=rows.length?p.pageRows.map(r=>`<tr><td>${escapeHTML(r.name||'—')}</td><td>${ASCB_PERMISSIONS&&ASCB_PERMISSIONS.deleteLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminDeleteCourseById(${Number(r.id)})">${ascbIcon('delete')}</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="2" class="records-empty">Walang course.</td></tr>';st.style.display='none';w.style.display='block';ascbRenderPagination('admCoursesPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbAdminCoursesGoToPage');}
async function ascbAdminAddCourse(){const name=(ascbAdminEl('admLookup_courseName')?.value||'').trim(),st=ascbAdminEl('admCourseFormStatus');if(!name){alert('Enter the course name.');return;}if(st){st.style.display='block';st.textContent='Sino-save…';}const data=await ascbApiPost('api/courses.php',{action:'add',name});if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}ascbAdminEl('admLookup_courseName').value='';if(!ascbCoursesCache.includes(name))ascbCoursesCache.push(name);f137LoadCourses();ascbCfPopulateCourses();if(st)st.textContent='Course added.';await ascbAdminLoadCourses();}
function ascbAdminDeleteCourseById(id){const r=ascbAdmCoursesRows.find(x=>Number(x.id)===Number(id));if(r)ascbAdminDeleteCourse(r.name);}
async function ascbAdminDeleteCourse(name){if(!confirm(`Delete course: ${name}?`))return;const data=await ascbApiPost('api/courses.php',{action:'delete',name});if(!data.ok){alert(data.error||'Hindi na-delete.');return;}ascbCoursesCache=ascbCoursesCache.filter(c=>c!==name);f137LoadCourses();ascbCfPopulateCourses();await ascbAdminLoadCourses();}


/* ---------- DEPARTMENTS / DEAN EXPORT ---------- */
function ascbPopulateDepartmentSelects(){
 const ids=['user_departmentId','user_edit_departmentId','admProg_departmentId','admProg_edit_departmentId','deptExport_department','deptAssign_department'];
 ids.forEach(id=>{const el=ascbAdminEl(id);if(!el)return;const cur=el.value;let options='<option value="">— Select Department —</option>';options+=ascbDepartmentsRows.filter(d=>Number(d.is_active)).map(d=>`<option value="${Number(d.id)}">${escapeHTML(d.code)} — ${escapeHTML(d.name)}</option>`).join('');el.innerHTML=options;if(cur)el.value=cur;});
 if(ASCB_CURRENT_USER&&ASCB_CURRENT_USER.role==='DEAN'){const ex=ascbAdminEl('deptExport_department');if(ex){ex.value=String(ASCB_CURRENT_USER.departmentId||'');ex.disabled=true;}const form=ascbAdminEl('deptManageForm'),btn=ascbAdminEl('deptAddBtn'),bak=ascbAdminEl('fullSqlBackupBtn');if(form)form.style.display='none';if(btn)btn.style.display='none';if(bak)bak.style.display='none';}
}
async function ascbLoadDepartments(silent=false){const st=ascbAdminEl('deptStatus');if(st&&!silent){st.style.display='block';st.textContent='Loading departments…';}const data=await ascbApiPost('api/departments.php',{action:'list'});if(!data.ok){if(st&&!silent)st.textContent=data.error||'Hindi makuha ang departments.';return;}ascbDepartmentsRows=Array.isArray(data.departments)?data.departments:[];ascbPopulateDepartmentSelects();const b=ascbAdminEl('deptTableBody');if(b)b.innerHTML=ascbDepartmentsRows.length?ascbDepartmentsRows.map(d=>`<tr><td>${escapeHTML(d.code)}</td><td>${escapeHTML(d.name)}</td><td>${Number(d.program_count||0)}</td><td>${Number(d.dean_count||0)}</td><td>${Number(d.is_active)?'Active':'Inactive'}</td><td>${ASCB_PERMISSIONS&&ASCB_PERMISSIONS.manageDepartments?`<button type="button" class="btn btn-danger btn-sm" onclick="ascbDepartmentDelete(${Number(d.id)})">Delete</button>`:'—'}</td></tr>`).join(''):'<tr><td colspan="6" class="records-empty">Wala pang Department.</td></tr>';if(st&&!silent)st.style.display='none';}
async function ascbLoadDepartmentAssignablePrograms(){
    const dep=Number(ascbAdminEl('deptAssign_department')?.value||0);
    const st=ascbAdminEl('deptAssignStatus'), wrap=ascbAdminEl('deptAssignTableWrapper');
    if(!dep){ if(wrap)wrap.style.display='none'; ['deptAssignBtn','deptAssignSelectAllBtn','deptAssignClearBtn'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.style.display='none';}); return; }
    if(st){st.style.display='block';st.textContent='Loading existing Programs…';}
    const data=await ascbApiPost('api/programs.php',{action:'list'});
    if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang Programs.';return;}
    ascbAdmProgsRows=Array.isArray(data.programs)?data.programs:[];
    ascbRenderDepartmentAssignablePrograms();
}
function ascbRenderDepartmentAssignablePrograms(){
    const dep=Number(ascbAdminEl('deptAssign_department')?.value||0), b=ascbAdminEl('deptAssignTableBody'), wrap=ascbAdminEl('deptAssignTableWrapper'), st=ascbAdminEl('deptAssignStatus');
    if(!dep||!b||!wrap)return;
    const q=(ascbAdminEl('deptAssign_search')?.value||'').trim().toLowerCase();
    const rows=ascbAdmProgsRows.filter(r=>!q || [r.code,r.course_name,r.major,r.department_name].some(v=>String(v||'').toLowerCase().includes(q)));
    const unassigned=rows.filter(r=>!Number(r.department_id));
    const assignedElsewhere=rows.filter(r=>Number(r.department_id) && Number(r.department_id)!==dep);
    const same=rows.filter(r=>Number(r.department_id)===dep);
    const selectable=rows.filter(r=>Number(r.department_id)!==dep);
    b.innerHTML=rows.length?rows.map(r=>{
        const current=Number(r.department_id)===dep;
        const currentName=r.department_name||'Walang Department';
        return `<tr><td><input type="checkbox" class="dept-assign-program" value="${Number(r.id)}" ${current?'disabled checked':''}></td><td>${escapeHTML(r.code||'—')}</td><td>${escapeHTML(r.course_name||'—')}</td><td>${escapeHTML(r.major||'—')}</td><td>${escapeHTML(currentName)}${(!current&&Number(r.department_id))?' <strong>(will move)</strong>':''}</td></tr>`;
    }).join(''):'<tr><td colspan="5" class="records-empty">Walang matching Program.</td></tr>';
    wrap.style.display='block';
    const btn=ascbAdminEl('deptAssignBtn'), all=ascbAdminEl('deptAssignSelectAllBtn'), clear=ascbAdminEl('deptAssignClearBtn');
    [btn,all,clear].forEach(e=>{if(e)e.style.display=rows.length?'inline-block':'none';});
    if(st){st.style.display='block';st.textContent=`${rows.length} matching program(s). ${unassigned.length} unassigned; ${assignedElsewhere.length} currently under another Department; ${same.length} already assigned here.`;}
}
function ascbToggleDepartmentAssignablePrograms(select){
    document.querySelectorAll('#deptAssignTableBody .dept-assign-program:not(:disabled)').forEach(cb=>cb.checked=!!select);
}
async function ascbAssignSelectedPrograms(){
    const dep=Number(ascbAdminEl('deptAssign_department')?.value||0);
    const selected=Array.from(document.querySelectorAll('#deptAssignTableBody .dept-assign-program:checked:not(:disabled)')).map(cb=>Number(cb.value)).filter(Boolean);
    const st=ascbAdminEl('deptAssignStatus');
    if(!dep){alert('Pumili muna ng Target Department.');return;}
    if(!selected.length){alert('Pumili ng kahit isang existing Program/Course.');return;}
    const moving=selected.map(id=>ascbAdmProgsRows.find(r=>Number(r.id)===id)).filter(r=>r&&Number(r.department_id)&&Number(r.department_id)!==dep);
    if(moving.length && !confirm(`${moving.length} Program(s) ay kasalukuyang naka-assign sa ibang Department. Ililipat sila sa napiling Department. Continue?`))return;
    if(st){st.style.display='block';st.textContent='Sini-save ang Department assignments…';}
    const data=await ascbApiPost('api/programs.php',{action:'assign_department_bulk',departmentId:dep,programIds:selected});
    if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save ang assignments.';return;}
    if(st)st.textContent=`Success: ${Number(data.assigned_count||selected.length)} Program(s) assigned sa ${data.department?.code||'Department'}.`;
    await ascbLoadDepartments(true);
    await ascbLoadDepartmentAssignablePrograms();
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}

async function ascbDepartmentAdd(){const code=(ascbAdminEl('dept_code')?.value||'').trim().toUpperCase(),name=(ascbAdminEl('dept_name')?.value||'').trim(),st=ascbAdminEl('deptStatus');if(!code||!name){alert('Kailangan ang Department Code at Name.');return;}const data=await ascbApiPost('api/departments.php',{action:'add',code,name});if(!data.ok){if(st){st.style.display='block';st.textContent=data.error||'Hindi na-save.';}return;}ascbAdminEl('dept_code').value='';ascbAdminEl('dept_name').value='';await ascbLoadDepartments();}
async function ascbDepartmentDelete(id){if(!confirm('Delete this Department?'))return;const data=await ascbApiPost('api/departments.php',{action:'delete',id});if(!data.ok){alert(data.error||'Hindi na-delete.');return;}await ascbLoadDepartments();}
function ascbDepartmentExport(){const dep=Number(ascbAdminEl('deptExport_department')?.value||ASCB_CURRENT_USER?.departmentId||0),sy=(ascbAdminEl('deptExport_sy')?.value||'').trim(),term=ascbAdminEl('deptExport_term')?.value||'';if(!dep){alert('Pumili ng Department.');return;}const q=new URLSearchParams({department_id:String(dep)});if(sy)q.set('school_year',sy);if(term)q.set('term',term);window.location.href='api/department_export.php?'+q.toString();}
function ascbFullSqlBackup(){window.location.href='api/database_backup.php';}

/* ---------- PROGRAMS & SUBJECTS ---------- */
async function ascbAdminLoadPrograms(){const st=ascbAdminEl('admProgsStatus'),wrap=ascbAdminEl('admProgsTableWrapper');if(st){st.style.display='block';st.textContent='Loading…';}const data=await ascbApiPost('api/programs.php',{action:'list'});if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang programs.';return;}ascbAdmProgsRows=Array.isArray(data.programs)?data.programs:[];ascbAdmProgsPage=1;ascbAdminProgramsRender();}
function ascbAdminProgramsFiltered(){const q=(ascbAdminEl('admProgSearchInput')?.value||'').trim().toLowerCase();return q?ascbAdmProgsRows.filter(r=>[r.code,r.course_name,r.major].some(v=>String(v||'').toLowerCase().includes(q))):ascbAdmProgsRows;}
function ascbAdminProgramsFilter(){ascbAdmProgsPage=1;ascbAdminProgramsRender();}function ascbAdminProgramsGoToPage(p){ascbAdmProgsPage=p;ascbAdminProgramsRender();}
function ascbAdminProgramsRender(){
    const b=ascbAdminEl('admProgsTableBody'),st=ascbAdminEl('admProgsStatus'),w=ascbAdminEl('admProgsTableWrapper');
    if(!b||!st||!w)return;
    const rows=ascbAdminProgramsFiltered(),p=ascbPaginate(rows,ascbAdmProgsPage,ASCB_PAGE_SIZE);
    ascbAdmProgsPage=p.page;
    b.innerHTML=rows.length?p.pageRows.map(r=>{
        const active=Number(r.is_active);
        const delBtn=ASCB_PERMISSIONS&&ASCB_PERMISSIONS.deleteLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminDeleteProgram(${Number(r.id)})">${ascbIcon('delete')}</button>`:'';
        return `<tr>
            <td>${escapeHTML(r.department_name||'—')}</td>
            <td>${escapeHTML(r.code||'—')}</td>
            <td>${escapeHTML(r.course_name||'—')}</td>
            <td>${escapeHTML(r.major||'—')}</td>
            <td>${escapeHTML(r.term_type||'Trimester')}</td>
            <td>${Number(r.subject_count||0)}</td>
            <td>${active?'Active':'Inactive'}</td>
            <td>
                <button type="button" class="btn btn-outline btn-sm" onclick="ascbAdminProgManageSubjects(${Number(r.id)})">Manage Subjects</button>
                <button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbAdminProgOpenEdit(${Number(r.id)})">${ascbIcon('edit')}</button>
                ${delBtn}
            </td>
        </tr>`;
    }).join(''):'<tr><td colspan="8" class="records-empty">Wala pang idinagdag na program.</td></tr>';
    st.style.display='none';w.style.display='block';
    ascbRenderPagination('admProgsPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbAdminProgramsGoToPage');
}
async function ascbAdminAddProgram(){
    const departmentId=Number(ascbAdminEl('admProg_departmentId')?.value||0);
    const code=(ascbAdminEl('admProg_code')?.value||'').trim().toUpperCase();
    const courseName=(ascbAdminEl('admProg_courseName')?.value||'').trim();
    const major=(ascbAdminEl('admProg_major')?.value||'').trim();
    const termType=ascbAdminEl('admProg_termType')?.value||'Trimester';
    const st=ascbAdminEl('admProgFormStatus');
    if(!code||!courseName){alert('Kailangan ang Course Code at Course Name.');return;}
    if(st){st.style.display='block';st.textContent='Sino-save…';}
    const data=await ascbApiPost('api/programs.php',{action:'add',departmentId,code,courseName,major,termType});
    if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}
    ['admProg_code','admProg_courseName','admProg_major'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});
    if(st)st.textContent='Program added. Available na sa Enrollment Course dropdown.';
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}
function ascbAdminProgOpenEdit(id){
    const r=ascbAdmProgsRows.find(x=>Number(x.id)===Number(id));
    if(!r)return;
    ascbAdminEl('admProg_edit_id').value=r.id;
    ascbAdminEl('admProg_edit_departmentId').value=r.department_id||'';
    ascbAdminEl('admProg_edit_code').value=r.code||'';
    ascbAdminEl('admProg_edit_courseName').value=r.course_name||'';
    ascbAdminEl('admProg_edit_major').value=r.major||'';
    ascbAdminEl('admProg_edit_termType').value=r.term_type||'Trimester';
    ascbAdminEl('admProg_edit_isActive').checked=!!Number(r.is_active);
    const st=ascbAdminEl('admProgEditStatus');if(st)st.style.display='none';
    ascbAdminEl('progEditModal')?.classList.add('active');
}
function ascbAdminProgCloseEdit(){ascbAdminEl('progEditModal')?.classList.remove('active');}
async function ascbAdminProgSubmitEdit(){
    const id=Number(ascbAdminEl('admProg_edit_id')?.value||0);
    const departmentId=Number(ascbAdminEl('admProg_edit_departmentId')?.value||0);
    const code=(ascbAdminEl('admProg_edit_code')?.value||'').trim().toUpperCase();
    const courseName=(ascbAdminEl('admProg_edit_courseName')?.value||'').trim();
    const major=(ascbAdminEl('admProg_edit_major')?.value||'').trim();
    const termType=ascbAdminEl('admProg_edit_termType')?.value||'Trimester';
    const isActive=ascbAdminEl('admProg_edit_isActive')?.checked?1:0;
    const st=ascbAdminEl('admProgEditStatus');
    if(!id||!code||!courseName){alert('Kailangan ang Course Code at Course Name.');return;}
    if(st){st.style.display='block';st.textContent='Sino-save…';}
    const data=await ascbApiPost('api/programs.php',{action:'update',id,departmentId,code,courseName,major,termType,isActive});
    if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}
    ascbAdminProgCloseEdit();
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}
async function ascbAdminDeleteProgram(id){
    const r=ascbAdmProgsRows.find(x=>Number(x.id)===Number(id));
    if(!r||!confirm(`Delete program: ${r.code} — ${r.course_name}? Mabubura rin lahat ng subjects nito.`))return;
    const data=await ascbApiPost('api/programs.php',{action:'delete',id});
    if(!data.ok){alert(data.error||'Hindi na-delete.');return;}
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}

/* ---- Manage Subjects modal (isang program) ---- */
function ascbAdminProgManageSubjects(programId){
    const r=ascbAdmProgsRows.find(x=>Number(x.id)===Number(programId));
    if(!r)return;
    ascbAdmProgSubjCurrentProgram=r;
    ascbAdminEl('progSubjModalTitle').textContent=`Manage Subjects — ${r.code}`;
    ascbAdminEl('progSubjModalSubtitle').textContent=`${r.course_name}${r.major?(' Major in '+r.major):''} · ${r.term_type||'Trimester'} system`;
    ascbAdminEl('admProgSubj_termLabelLabel').textContent=r.term_type==='Semester'?'Semester':'Trimester';
    const termSelect=ascbAdminEl('admProgSubj_termLabel');
    if(termSelect){
        const opts=r.term_type==='Semester'?['1st Semester','2nd Semester','3rd Semester | Summer']:['1st Trimester','2nd Trimester','3rd Trimester'];
        termSelect.innerHTML=`<option value="">Select ${r.term_type==='Semester'?'Semester':'Trimester'}</option>`+opts.map(o=>`<option>${o}</option>`).join('');
    }
    ascbAdminProgSubjectCancelEdit();
    ascbAdminEl('progSubjectsModal')?.classList.add('active');
    ascbAdminProgSubjLoad(r.id);
}
function ascbAdminProgSubjClose(){ascbAdminEl('progSubjectsModal')?.classList.remove('active');}
async function ascbAdminProgSubjLoad(programId){
    const st=ascbAdminEl('admProgSubjListStatus');
    if(st){st.style.display='block';st.textContent='Loading…';}
    const data=await ascbApiPost('api/programs.php',{action:'list_subjects',programId});
    if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang subjects.';return;}
    ascbAdmProgSubjRows=Array.isArray(data.subjects)?data.subjects:[];
    ascbAdminProgSubjRender();
}
function ascbAdminProgSubjRender(){
    const b=ascbAdminEl('admProgSubjTableBody'),st=ascbAdminEl('admProgSubjListStatus');
    if(!b)return;
    b.innerHTML=ascbAdmProgSubjRows.length?ascbAdmProgSubjRows.map(s=>{
        const delBtn=ASCB_PERMISSIONS&&ASCB_PERMISSIONS.deleteLookups?`<button type="button" class="btn btn-danger btn-sm action-icon-btn" title="Delete" aria-label="Delete" onclick="ascbAdminProgSubjectDelete(${Number(s.id)})">${ascbIcon('delete')}</button>`:'';
        return `<tr>
            <td>${escapeHTML(s.year_level||'—')}</td>
            <td>${escapeHTML(s.term_label||'—')}</td>
            <td>${escapeHTML(s.subject_code||'—')}</td>
            <td>${escapeHTML(s.description||'—')}</td>
            <td>${Number(s.units||0)}</td>
            <td>
                <button type="button" class="btn btn-outline btn-sm action-icon-btn" title="Edit" aria-label="Edit" onclick="ascbAdminProgSubjectEdit(${Number(s.id)})">${ascbIcon('edit')}</button>
                ${delBtn}
            </td>
        </tr>`;
    }).join(''):'<tr><td colspan="7" class="records-empty">Wala pang subject.</td></tr>';
    if(st)st.style.display='none';
}
async function ascbAdminProgSubjectSave(){
    if(!ascbAdmProgSubjCurrentProgram)return;
    const editId=Number(ascbAdminEl('admProgSubj_editId')?.value||0);
    const yearLevel=ascbAdminEl('admProgSubj_yearLevel')?.value||'';
    const termLabel=ascbAdminEl('admProgSubj_termLabel')?.value||'';
    const subjectCode=(ascbAdminEl('admProgSubj_code')?.value||'').trim();
    const description=(ascbAdminEl('admProgSubj_description')?.value||'').trim();
    const units=Number(ascbAdminEl('admProgSubj_units')?.value||0);
    const st=ascbAdminEl('admProgSubjFormStatus');
    if(!yearLevel||!termLabel||!subjectCode||!description){alert('Kumpletuhin ang Year Level, Term, Subject Code at Description.');return;}
    if(st){st.style.display='block';st.textContent='Sino-save…';}
    const payload=editId
        ?{action:'update_subject',id:editId,yearLevel,termLabel,subjectCode,description,units}
        :{action:'add_subject',programId:ascbAdmProgSubjCurrentProgram.id,yearLevel,termLabel,subjectCode,description,units};
    const data=await ascbApiPost('api/programs.php',payload);
    if(!data.ok){if(st)st.textContent=data.error||'Hindi na-save.';return;}
    ascbAdminProgSubjectCancelEdit();
    ['admProgSubj_code','admProgSubj_description','admProgSubj_units'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});
    if(st)st.textContent='Subject saved.';
    await ascbAdminProgSubjLoad(ascbAdmProgSubjCurrentProgram.id);
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}
function ascbAdminProgSubjectEdit(id){
    const s=ascbAdmProgSubjRows.find(x=>Number(x.id)===Number(id));
    if(!s)return;
    ascbAdminEl('admProgSubj_editId').value=s.id;
    ascbAdminEl('admProgSubj_yearLevel').value=s.year_level||'';
    ascbAdminEl('admProgSubj_termLabel').value=s.term_label||'';
    ascbAdminEl('admProgSubj_code').value=s.subject_code||'';
    ascbAdminEl('admProgSubj_description').value=s.description||'';
    ascbAdminEl('admProgSubj_units').value=s.units||'';
    ascbAdminEl('admProgSubjAddBtn').innerHTML='<span class="btn-icon">✔</span> Save Changes';
    const cancelBtn=ascbAdminEl('admProgSubjCancelEditBtn');if(cancelBtn)cancelBtn.style.display='';
}
function ascbAdminProgSubjectCancelEdit(){
    const idField=ascbAdminEl('admProgSubj_editId');if(idField)idField.value='';
    ['admProgSubj_yearLevel','admProgSubj_termLabel','admProgSubj_code','admProgSubj_description','admProgSubj_units'].forEach(id=>{const e=ascbAdminEl(id);if(e)e.value='';});
    const addBtn=ascbAdminEl('admProgSubjAddBtn');if(addBtn)addBtn.innerHTML='<span class="btn-icon">+</span> Add Subject';
    const cancelBtn=ascbAdminEl('admProgSubjCancelEditBtn');if(cancelBtn)cancelBtn.style.display='none';
    const st=ascbAdminEl('admProgSubjFormStatus');if(st)st.style.display='none';
}
async function ascbAdminProgSubjectDelete(id){
    const s=ascbAdmProgSubjRows.find(x=>Number(x.id)===Number(id));
    if(!s||!confirm(`Delete subject: ${s.subject_code} — ${s.description}?`))return;
    const data=await ascbApiPost('api/programs.php',{action:'delete_subject',id});
    if(!data.ok){alert(data.error||'Hindi na-delete.');return;}
    await ascbAdminProgSubjLoad(ascbAdmProgSubjCurrentProgram.id);
    await ascbAdminLoadPrograms();
    await ascbRefreshCustomPrograms();
}

async function ascbLoadActivityLog(){const st=ascbAdminEl('logStatus'),wrap=ascbAdminEl('logTableWrapper');if(st){st.style.display='block';st.textContent='Loading…';}if(wrap)wrap.style.display='none';const data=await ascbApiPost('api/activity_log.php',{action:'list',limit:1000});if(!data.ok){if(st)st.textContent=data.error||'Hindi makuha ang Activity Log.';return;}ascbLogRows=Array.isArray(data.rows)?data.rows:[];ascbLogPage=1;ascbActivityLogRender();}
function ascbActivityLogFiltered(){const q=(ascbAdminEl('logSearchInput')?.value||'').trim().toLowerCase();return q?ascbLogRows.filter(r=>[r.display_name,r.role,r.action,r.entity_label,r.details].some(v=>String(v||'').toLowerCase().includes(q))):ascbLogRows;}
function ascbActivityLogFilter(){ascbLogPage=1;ascbActivityLogRender();}function ascbActivityLogGoToPage(p){ascbLogPage=p;ascbActivityLogRender();}
function ascbActivityLogRender(){const b=ascbAdminEl('logTableBody'),st=ascbAdminEl('logStatus'),w=ascbAdminEl('logTableWrapper');if(!b||!st||!w)return;const rows=ascbActivityLogFiltered(),p=ascbPaginate(rows,ascbLogPage,ASCB_PAGE_SIZE);ascbLogPage=p.page;b.innerHTML=rows.length?p.pageRows.map(r=>`<tr><td>${ascbUiDateTime(r.created_at)}</td><td>${escapeHTML(r.display_name||'—')}</td><td>${escapeHTML(r.role||'—')}</td><td>${escapeHTML(r.action||'—')}</td><td>${escapeHTML([r.entity_label,r.details].filter(Boolean).join(' — ')||'—')}</td></tr>`).join(''):'<tr><td colspan="5" class="records-empty">Walang activity record.</td></tr>';st.style.display='none';w.style.display='block';ascbRenderPagination('logPagination',p.page,p.totalPages,p.total,ASCB_PAGE_SIZE,'ascbActivityLogGoToPage');}
