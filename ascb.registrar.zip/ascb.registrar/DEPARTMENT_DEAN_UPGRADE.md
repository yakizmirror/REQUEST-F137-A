# ASCB Registrar — Department / Dean / Backup Upgrade

## Implemented workflow

Department -> Program -> Student Enrollment -> Subjects -> Grades -> Department Excel Export

- Programs are assigned to Departments.
- DEAN accounts must be assigned to one Department.
- DEAN enrollment/grade list access is read-only and limited to the assigned Department.
- Dashboard enrollment statistics are also Department-scoped for DEAN accounts.
- UNIT HEAD / SCHOOL REGISTRAR can manage Departments and assign Department to Programs/Dean users.
- Department Excel export produces an Excel-compatible `.xls` file containing student, enrollment, subject and grade data.
- Full SQL database backup is available to UNIT HEAD / SCHOOL REGISTRAR.
- Exports/backups are recorded in `backup_history` and activity logging.

## Existing installation

The upgraded `config/db.php` runs an idempotent lightweight schema check and creates the Department/Dean/Backup structures automatically when the database user has ALTER/CREATE privileges (normal XAMPP root setup).

A manual migration is also included:

`database/migrate_departments_dean_backup_module.php`

Use this if automatic schema creation is disabled by database permissions.

## Setup order in the dashboard

1. Admin -> Departments & Backup -> create Departments.
2. Admin -> Programs & Subjects -> edit each Program and assign its Department.
3. Admin -> Users -> create/edit a user with role DEAN and select the Department.
4. Dean logs in. Student/enrollment/grade lists and dashboard totals are restricted to the assigned Department.
5. Admin -> Departments & Backup -> choose School Year/Term and Export Excel.
6. UNIT HEAD / SCHOOL REGISTRAR can also click Full SQL Backup.

## Backup policy

Department Excel files are distribution/report copies for Deans. The SQL backup remains the recovery backup/source-of-truth backup for the Registrar database.
