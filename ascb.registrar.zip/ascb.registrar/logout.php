<?php
/* ASCB REGISTRAR SYSTEM — LOGOUT */
require_once __DIR__ . '/includes/helpers.php';
require_once __DIR__ . '/includes/security.php';
ascb_start_session();
ascb_send_security_headers();

$userForLog = !empty($_SESSION['ascb_user']) ? $_SESSION['ascb_user'] : null;

/* Destroy authentication first. Logout must still work even if
   the database happens to be offline. */
$_SESSION = array();
if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $params['path'], $params['domain'], $params['secure'], $params['httponly']);
}
session_destroy();

if ($userForLog) {
    define('ASCB_DB_OPTIONAL', true);
    require_once __DIR__ . '/config/db.php';
    if ($pdo) {
        require_once __DIR__ . '/includes/activity_log.php';
        ascb_log_activity($pdo, $userForLog, 'LOGOUT', 'session', ascb_get($userForLog, 'displayName', ''));
    }
}

header('Location: index.php');
exit;
