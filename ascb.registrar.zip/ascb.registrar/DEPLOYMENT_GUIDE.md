# ASCB Registrar System — Client Deployment Guide

## Recommended environment
- Apache 2.4+ (XAMPP is okay) with PHP 7.4+ or PHP 8.x recommended.
- Required PHP extension: `pdo_mysql`.
- Recommended extensions: `fileinfo`, `mbstring`.
- MySQL/MariaDB with `utf8mb4` support.
- HTTPS when the system is reachable beyond one trusted local computer/LAN.

## Database configuration
The system still works with local XAMPP defaults (`localhost`, `root`, blank password), but a deployed client should create a dedicated database user and password. For a normal XAMPP client install, copy `config/local.php.example` to `config/local.php` and enter the client database credentials there. Alternatively configure these environment variables on the server: `ASCB_DB_HOST`, `ASCB_DB_PORT`, `ASCB_DB_NAME`, `ASCB_DB_USER`, `ASCB_DB_PASS`.

Do not expose database credentials in screenshots, public repositories, or shared ZIP files.

## Upload limits
The application now defaults to **25 MB per file**, configurable with `ASCB_MAX_UPLOAD_MB` (maximum safety ceiling: 250 MB). PHP/web-server limits must be high enough too. For example, if the client needs 25 MB files, set `upload_max_filesize` to at least `25M`. Because Releasing/Receiving supports multiple attachments, `post_max_size` must be larger than the total request size.

## Setup scripts
Everything under `/database/` is blocked from normal web access. Run migrations/seed scripts through PHP CLI, or temporarily set `ASCB_ALLOW_WEB_SETUP=1` only during a controlled installation, then disable it immediately.

Run the pre-deployment check from the project directory:

`php database/deployment_check.php`

## Apache / Nginx
The included `.htaccess` files protect `/config`, `/includes`, `/database`, and `/uploads` on Apache. **Nginx ignores `.htaccess`**, so equivalent deny rules must be added to the Nginx site configuration for those directories. Uploaded files should only be served through the authenticated `/api/*_file.php` endpoints.

## Before handing to the client
1. Import `database/ascb_registrar.sql` into the intended database.
2. Create/verify user accounts and change all temporary/default passwords.
3. Do not ship sample/student upload files from another installation.
4. Run `php database/deployment_check.php`.
5. Test login, add/edit/delete permissions, enrollment, grade evaluation, printing, PDF upload/view, FORM 9 upload/download, logout, and re-login.
6. Back up both the database and `/uploads` folder; one without the other is incomplete.


## Grade Management redesign

Enrollment no longer accepts or updates grades. Run `database/migrate_grade_management_module.php` once on an existing database (the old `migrate_enrollment_grade_module.php` filename remains as a compatibility entry point). The migration creates `enrollment_subjects` and `grades`, and copies existing grades from `enrollees.subjects_json`.

New flow: **Enrollment → subjects/units only → Grade Management → grades → Grade Evaluation (read-only/print)**. Updating a grade does not change enrollment approval status.
